-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Servidor: localhost:3306
-- Tempo de Geração: 05/08/2016 às 14:12
-- Versão do servidor: 5.6.31
-- Versão do PHP: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `radiolin_root`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `administradores`
--

CREATE TABLE IF NOT EXISTS `administradores` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `usuario` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Fazendo dump de dados para tabela `administradores`
--

INSERT INTO `administradores` (`codigo`, `nome`, `usuario`, `senha`) VALUES
(1, 'cianetbr', 'admin', '123');

-- --------------------------------------------------------

--
-- Estrutura para tabela `avisos`
--

CREATE TABLE IF NOT EXISTS `avisos` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `mensagem` varchar(255) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Fazendo dump de dados para tabela `avisos`
--

INSERT INTO `avisos` (`codigo`, `mensagem`) VALUES
(7, 'Sistema com hora certa intercalada');

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE IF NOT EXISTS `configuracoes` (
  `ip_painel` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `chave_api_google_maps` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `codigo_servidor_atual` int(10) NOT NULL,
  `codigo_servidor_atual_aacp` int(10) NOT NULL,
  `codigo_servidor_aacplus_atual` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ip_painel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Fazendo dump de dados para tabela `configuracoes`
--

INSERT INTO `configuracoes` (`ip_painel`, `chave_api_google_maps`, `codigo_servidor_atual`, `codigo_servidor_atual_aacp`, `codigo_servidor_aacplus_atual`) VALUES
('198.15.105.155', 'ABQIAAAAevJfOKmlECj9_fxY1TUMkxQ2aoy2sPL3ITgZ0z6Ck544MFo-iRSjWxi-lYzj--CShgCYv8XB7ujY7g', 3, 0, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `djs`
--

CREATE TABLE IF NOT EXISTS `djs` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `login` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Fazendo dump de dados para tabela `djs`
--

INSERT INTO `djs` (`codigo`, `codigo_stm`, `login`, `senha`) VALUES
(1, 1, 'aovivo', '1234');

-- --------------------------------------------------------

--
-- Estrutura para tabela `estatisticas`
--

CREATE TABLE IF NOT EXISTS `estatisticas` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `data` date NOT NULL,
  `ip` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '000.000.000.000',
  `pais` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tempo_conectado` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `estatisticas_players`
--

CREATE TABLE IF NOT EXISTS `estatisticas_players` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `player` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `data` datetime NOT NULL,
  `ip` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `origem` longtext CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `multpoints`
--

CREATE TABLE IF NOT EXISTS `multpoints` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `codigo_playlist` int(10) NOT NULL,
  `frequencia` int(1) NOT NULL,
  `data` date NOT NULL,
  `hora` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `minuto` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `duracao_hora` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '00',
  `duracao_minuto` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '00',
  `dias` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `repetir` int(1) NOT NULL DEFAULT '0',
  `shuffle` int(1) NOT NULL DEFAULT '0',
  `ponto` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bitrate` int(1) NOT NULL DEFAULT '0',
  `url` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `encoder` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'o',
  PRIMARY KEY (`codigo`),
  KEY `indice_data` (`data`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1265 ;

--
-- Fazendo dump de dados para tabela `multpoints`
--

INSERT INTO `multpoints` (`codigo`, `codigo_stm`, `codigo_playlist`, `frequencia`, `data`, `hora`, `minuto`, `duracao_hora`, `duracao_minuto`, `dias`, `repetir`, `shuffle`, `ponto`, `bitrate`, `url`, `encoder`) VALUES
(1264, 1, 0, 1, '0000-00-00', '', '', '00', '00', '', 0, 0, '', 128, 'www', 'aacp');

-- --------------------------------------------------------

--
-- Estrutura para tabela `playlists`
--

CREATE TABLE IF NOT EXISTS `playlists` (
  `codigo` int(50) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `nome` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `arquivo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `data` datetime NOT NULL,
  `funcao` int(10) NOT NULL DEFAULT '0',
  `cota` int(11) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22902268 ;

--
-- Fazendo dump de dados para tabela `playlists`
--

INSERT INTO `playlists` (`codigo`, `codigo_stm`, `nome`, `arquivo`, `data`, `funcao`, `cota`) VALUES
(908232, 8000, 'Masculina', 'Masculina-23h48m.pls', '2016-06-02 00:08:16', 1, 0),
(800048, 8, 'teste', '8000-teste.pls', '2016-08-05 13:47:46', 0, 0),
(19949236, 8000, 'Feminina', 'Feminina-19h55m.pls', '2016-06-01 19:49:25', 1, 0),
(800014, 1, 'teste', '8000-teste.pls', '2016-04-04 09:23:12', 0, 0),
(16902229, 8000, 'Feminina', 'Feminina-13h11m.pls', '2016-05-23 16:03:00', 1, 0),
(22902267, 8000, 'Masculina', 'Masculina-22h02m.pls', '2016-05-02 22:02:55', 1, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `playlists_agendamentos`
--

CREATE TABLE IF NOT EXISTS `playlists_agendamentos` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_stm` int(10) NOT NULL,
  `codigo_playlist` int(10) NOT NULL,
  `frequencia` int(1) NOT NULL,
  `data` date NOT NULL,
  `hora` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `minuto` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `duracao_hora` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '00',
  `duracao_minuto` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '00',
  `dias` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `repetir` int(1) NOT NULL DEFAULT '0',
  `shuffle` int(1) NOT NULL DEFAULT '0',
  `funcao` int(1) NOT NULL DEFAULT '1',
  `url` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`codigo`),
  KEY `indice_data` (`data`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1297 ;

--
-- Fazendo dump de dados para tabela `playlists_agendamentos`
--

INSERT INTO `playlists_agendamentos` (`codigo`, `codigo_stm`, `codigo_playlist`, `frequencia`, `data`, `hora`, `minuto`, `duracao_hora`, `duracao_minuto`, `dias`, `repetir`, `shuffle`, `funcao`, `url`) VALUES
(1296, 1, 908232, 5, '2016-06-02', '23', '45', '23', '45', '', 0, 0, 1, ''),
(1295, 1, 19949236, 5, '2016-06-01', '19', '52', '19', '52', '', 0, 0, 1, ''),
(1294, 1, 16902229, 5, '2016-05-23', '13', '08', '13', '08', '', 0, 0, 1, ''),
(1293, 1, 22902267, 5, '2016-05-02', '21', '59', '21', '59', '', 0, 0, 1, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `playlists_musicas`
--

CREATE TABLE IF NOT EXISTS `playlists_musicas` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_playlist` int(10) NOT NULL,
  `path_musica` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `musica` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ordem` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=191 ;

--
-- Fazendo dump de dados para tabela `playlists_musicas`
--

INSERT INTO `playlists_musicas` (`codigo`, `codigo_playlist`, `path_musica`, `musica`, `ordem`) VALUES
(12, 800036, '/SPOT NATAL LBV 2015_Adriane Galisteu.mp3', 'SPOT NATAL LBV 2015_Adriane Galisteu.mp3', 2),
(11, 800036, '/DICAS DE SAUDE.mp3', 'DICAS DE SAUDE.mp3', 1),
(10, 800036, '/02-IdentificaÃ§Ã£o Nossa FM 87,9 mhz.mp3', '02-IdentificaÃ§Ã£o Nossa FM 87,9 mhz.mp3', 0),
(149, 800014, '/AndrÃ© da Carruagem   Me Criticaram.mp3', 'AndrÃ© da Carruagem   Me Criticaram.mp3', 26),
(147, 800014, '/AndrÃ© ValadÃ£o  AbraÃ§a me.mp3', 'AndrÃ© ValadÃ£o  AbraÃ§a me.mp3', 24),
(148, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 25),
(145, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 22),
(146, 800014, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 23),
(143, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 20),
(144, 800014, '/AndrÃ© Oliveira-A Tua VitÃ³ria.mp3', 'AndrÃ© Oliveira-A Tua VitÃ³ria.mp3', 21),
(140, 800014, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 17),
(141, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 18),
(139, 800014, '/Amante Da MinhÂ´ Alma-AndrÃ© Oliveira.mp3', 'Amante Da MinhÂ´ Alma-AndrÃ© Oliveira.mp3', 16),
(142, 800014, '/Anderson Freire e Wilian Nascimento   Promessa (Clipe Oficial MK Music em HD).mp3', 'Anderson Freire e Wilian Nascimento   Promessa (Clipe Oficial MK Music em HD).mp3', 19),
(136, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 13),
(137, 800014, '/Amanda Ferrari   Vai Ter Virada   CD Eu Vejo Deus (2011)  Loja Evangelicacom.mp3', 'Amanda Ferrari   Vai Ter Virada   CD Eu Vejo Deus (2011)  Loja Evangelicacom.mp3', 14),
(138, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 15),
(135, 800014, '/Advogado Fiel   Bruna Karla   Advogado Fiel.mp3', 'Advogado Fiel   Bruna Karla   Advogado Fiel.mp3', 12),
(134, 800014, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 11),
(131, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 8),
(132, 800014, '/Adriana Aguiar-Paulo e Silas.mp3', 'Adriana Aguiar-Paulo e Silas.mp3', 9),
(133, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 10),
(129, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 6),
(130, 800014, '/Adorarei   Fabiana AnastÃ¡cio legendado.mp3', 'Adorarei   Fabiana AnastÃ¡cio legendado.mp3', 7),
(128, 800014, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 5),
(127, 800014, '/Adorador de Verdade - Michelle Nascimento.mp3', 'Adorador de Verdade - Michelle Nascimento.mp3', 4),
(126, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 3),
(125, 800014, '/Aceito o teu chamado   Bruna Karla.mp3', 'Aceito o teu chamado   Bruna Karla.mp3', 2),
(124, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 1),
(123, 800014, '/02 Tic-tac.mp3', '02 Tic-tac.mp3', 0),
(150, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 27),
(151, 800014, '/DICAS DE SAUDE.mp3', 'DICAS DE SAUDE.mp3', 28),
(152, 800014, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 29),
(153, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 30),
(154, 800014, '/andrea fontes   permissÃ£o de Deus.mp3', 'andrea fontes   permissÃ£o de Deus.mp3', 31),
(155, 800014, '../Hora-certa/hora-masculina.mp3', 'hora-masculina.mp3', 32),
(182, 800048, '/Anderson Freire e Wilian Nascimento   Promessa (Clipe Oficial MK Music em HD).mp3', 'Anderson Freire e Wilian Nascimento   Promessa (Clipe Oficial MK Music em HD).mp3', 12),
(181, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 11),
(180, 800048, '/Amante Da MinhÂ´ Alma-AndrÃ© Oliveira.mp3', 'Amante Da MinhÂ´ Alma-AndrÃ© Oliveira.mp3', 10),
(178, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 8),
(179, 800048, '/Amanda Ferrari   Vai Ter Virada   CD Eu Vejo Deus (2011)  Loja Evangelicacom.mp3', 'Amanda Ferrari   Vai Ter Virada   CD Eu Vejo Deus (2011)  Loja Evangelicacom.mp3', 9),
(177, 800048, '/Advogado Fiel   Bruna Karla   Advogado Fiel.mp3', 'Advogado Fiel   Bruna Karla   Advogado Fiel.mp3', 7),
(176, 800048, '/Adriana Aguiar-Paulo e Silas.mp3', 'Adriana Aguiar-Paulo e Silas.mp3', 6),
(174, 800048, '/Adorarei   Fabiana AnastÃ¡cio legendado.mp3', 'Adorarei   Fabiana AnastÃ¡cio legendado.mp3', 4),
(175, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 5),
(173, 800048, '/Adorador de Verdade - Michelle Nascimento.mp3', 'Adorador de Verdade - Michelle Nascimento.mp3', 3),
(172, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 2),
(170, 800048, '/02 Tic-tac.mp3', '02 Tic-tac.mp3', 0),
(171, 800048, '/Aceito o teu chamado   Bruna Karla.mp3', 'Aceito o teu chamado   Bruna Karla.mp3', 1),
(183, 800048, '/AndrÃ© Oliveira-A Tua VitÃ³ria.mp3', 'AndrÃ© Oliveira-A Tua VitÃ³ria.mp3', 13),
(184, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 14),
(185, 800048, '/AndrÃ© ValadÃ£o  AbraÃ§a me.mp3', 'AndrÃ© ValadÃ£o  AbraÃ§a me.mp3', 15),
(186, 800048, '/AndrÃ© da Carruagem   Me Criticaram.mp3', 'AndrÃ© da Carruagem   Me Criticaram.mp3', 16),
(187, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 17),
(188, 800048, '/DICAS DE SAUDE.mp3', 'DICAS DE SAUDE.mp3', 18),
(189, 800048, '/andrea fontes   permissÃ£o de Deus.mp3', 'andrea fontes   permissÃ£o de Deus.mp3', 19),
(190, 800048, '../Hora-certa/hora-feminina.mp3', 'hora-feminina.mp3', 20);

-- --------------------------------------------------------

--
-- Estrutura para tabela `revendas`
--

CREATE TABLE IF NOT EXISTS `revendas` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_cliente` int(10) NOT NULL,
  `nome` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `streamings` int(10) NOT NULL,
  `ouvintes` int(10) NOT NULL,
  `bitrate` int(10) NOT NULL,
  `espaco` int(10) NOT NULL,
  `url_logo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `chave_api` longtext CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `RTMP` longtext CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `chave_api_google_maps` longtext CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `servidor` int(10) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  `avisos` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `aacp` char(3) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'nao',
  `aacplus` varchar(255) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Fazendo dump de dados para tabela `revendas`
--

INSERT INTO `revendas` (`codigo`, `codigo_cliente`, `nome`, `email`, `senha`, `streamings`, `ouvintes`, `bitrate`, `espaco`, `url_logo`, `chave_api`, `RTMP`, `chave_api_google_maps`, `servidor`, `status`, `avisos`, `aacp`, `aacplus`) VALUES
(11, 0, 'Jarlino Alves', 'linkbit@hotmail.com.br', '123', 25, 1000, 128, 60000, '', 'bGlua2JpdEBob3RtYWlsLmNvbS5icitZ', '', '', 0, 1, '', 'nao', 'sim');

-- --------------------------------------------------------

--
-- Estrutura para tabela `servidores`
--

CREATE TABLE IF NOT EXISTS `servidores` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Stm',
  `ip` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `porta_ssh` int(6) NOT NULL DEFAULT '6985',
  `status` char(3) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'on',
  `limite_streamings` int(10) NOT NULL DEFAULT '50',
  `tipo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'streaming',
  `codigo_servidor_aacplus` varchar(10) NOT NULL,
  `loadserver` varchar(250) NOT NULL DEFAULT 'sim',
  `codigo_servidor_aacplus_atual` varchar(20) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Fazendo dump de dados para tabela `servidores`
--

INSERT INTO `servidores` (`codigo`, `nome`, `ip`, `senha`, `porta_ssh`, `status`, `limite_streamings`, `tipo`, `codigo_servidor_aacplus`, `loadserver`, `codigo_servidor_aacplus_atual`) VALUES
(3, '69.30.217.218', '69.30.217.218', 'V25wR2FXTnFSWGhpUkVWNFQxUm5NMHg1YjNRPStV', 22, 'on', 200, 'streaming', '', 'sim', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `streamings`
--

CREATE TABLE IF NOT EXISTS `streamings` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT,
  `codigo_cliente` int(10) NOT NULL,
  `codigo_servidor` int(10) NOT NULL,
  `codigo_servidor_aacplus` int(10) NOT NULL,
  `porta` int(10) NOT NULL,
  `porta_dj` int(10) NOT NULL,
  `ouvintes` int(10) NOT NULL,
  `bitrate` int(10) NOT NULL,
  `bitrate_autodj` int(10) NOT NULL,
  `encoder` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'mp3',
  `espaco` int(10) NOT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `streamtitle` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Web Rádio',
  `streamurl` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'http://',
  `genre` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Gênero',
  `xfade` int(10) NOT NULL DEFAULT '0',
  `ftp_dir` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `identificacao` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Não cadastrada',
  `data_cadastro` date NOT NULL,
  `pid` int(10) NOT NULL,
  `pid_autodj` int(10) NOT NULL DEFAULT '0',
  `protecao` int(1) NOT NULL DEFAULT '0',
  `ultima_playlist` int(10) NOT NULL DEFAULT '0',
  `aacplus` char(3) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'nao',
  `shoutcast_info` int(10) NOT NULL,
  `relay_ip` varchar(200) NOT NULL,
  `relay_porta` int(50) NOT NULL,
  `shoutcast` varchar(255) NOT NULL DEFAULT 'v1',
  `espaco_usado` varchar(255) NOT NULL DEFAULT '0',
  `quota` varchar(255) NOT NULL,
  `quota_total` varchar(255) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Fazendo dump de dados para tabela `streamings`
--

INSERT INTO `streamings` (`codigo`, `codigo_cliente`, `codigo_servidor`, `codigo_servidor_aacplus`, `porta`, `porta_dj`, `ouvintes`, `bitrate`, `bitrate_autodj`, `encoder`, `espaco`, `senha`, `streamtitle`, `streamurl`, `genre`, `xfade`, `ftp_dir`, `status`, `identificacao`, `data_cadastro`, `pid`, `pid_autodj`, `protecao`, `ultima_playlist`, `aacplus`, `shoutcast_info`, `relay_ip`, `relay_porta`, `shoutcast`, `espaco_usado`, `quota`, `quota_total`) VALUES
(9, 11, 3, 0, 8002, 35002, 1000, 48, 48, 'mp3', 50000, '158yj58oi1oi', 'Web Rádio', 'http://', 'Gênero', 0, '/home/streaming/8002', 1, '000100092850', '2016-08-05', 0, 0, 0, 0, 'nao', 0, '', 0, 'v1', '4.0K\n', '4.0K\n', '50000'),
(8, 11, 3, 0, 8000, 35000, 40, 24, 24, 'mp3', 100, '123', 'Web Rádio', 'http://', 'Gênero', 0, '/home/streaming/8000', 1, 'teste', '2016-08-05', 3511, 0, 0, 800048, 'nao', 0, '', 0, 'mp3', '69M\n6', '69M\n6', '100');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
