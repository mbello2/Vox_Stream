<?php
require_once("admin/inc/protecao-final.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$total_pontos = mysql_num_rows(mysql_query("SELECT * FROM multpoints where codigo_stm = '".$dados_stm["codigo"]."'"));


$qtd_multpoint = 3+$qtd_multpoint++;
if($_POST["cadastrar"]) {

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));

list($dia,$mes,$ano) = explode("/",$_POST["data"]);
$data = $ano."-".$mes."-".$dia;

if(count($_POST["dias"]) > 0){
	$dias = implode(",",$_POST["dias"]);
}

mysql_query("INSERT INTO multpoints (codigo_stm,frequencia,ponto,bitrate,url,encoder) VALUES ('".$dados_stm["codigo"]."','".$_POST["frequencia"]."','".$_POST["ponto"]."','".$_POST["bitrate"]."','".$_POST["url"]."','".$_POST["encoder"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Multpoint adicionado com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Multpoint adicionado com sucesso,agora reinicie o auto dj.","alerta");

}
header("Location: ../multpoint/".$porta_code."");
?>
