<?php
require_once("admin/inc/protecao-final.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];

if($_POST["cadastrar"]) {

if(!empty($_POST["dj_login"]) or !empty($_POST["dj_senha"])) {

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));

mysql_query("INSERT INTO djs (codigo_stm,login,senha) VALUES ('".$dados_stm["codigo"]."','".$_POST["dj_login"]."','".$_POST["dj_senha"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("DJ ".$_POST["dj_login"]." adicionado com sucesso.","ok");

} else {

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Voc� deve preencher o campo Login e Senha para o DJ.","ok");

}

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>

<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <form method="post" action="/gerenciar-djs" style="padding:0px; margin:0px">
  <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;; border-bottom:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Login</td>
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Senha</td>
      <td width="200" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Senha Conex�o</td>
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;A�&atilde;o</td>
    </tr>
<?php
$total_djs = mysql_num_rows(mysql_query("SELECT * FROM djs where codigo_stm = '".$dados_stm["codigo"]."' ORDER by login"));

if($total_djs > 0) {

$sql = mysql_query("SELECT * FROM djs where codigo_stm = '".$dados_stm["codigo"]."' ORDER by login");
while ($dados_dj = mysql_fetch_array($sql)) {

$dj_code = code_decode($dados_dj["codigo"],"E");

echo "<tr>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_dj["login"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_dj["senha"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_dj["login"].":".$dados_dj["senha"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>";

echo "<select style='width:100%' id='".$dj_code."' onchange='executar_acao_streaming(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <option value='remover-dj'>Remover</option>
</select>";

echo "</td>
</tr>";
}

} else {

echo "<tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'>Nenhum DJ cadastrado.</td>
  </tr>";

}
?>
  </table>
    <table width="500" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; background-color:#FFFF66; border:#DFDF00 1px solid">
      <tr>
        <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="430" align="left" class="texto_padrao_pequeno" scope="col">Ap&oacute;s cadastrar/remover o DJ voc&ecirc; dever&aacute; desligar e ligar novamente o AutoDJ para aplic&aacute;-los.</td>
      </tr>
    </table>
    <table width="500" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:20px;">
      <tr>
        <td width="120" height="45" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Login</td>
        <td width="380" align="left"><input name="dj_login" type="text" class="input" id="dj_login" style="width:250px;" onkeyup="bloquear_acentos(this);" />
          <br />
          <span class="texto_padrao_pequeno">N&atilde;o use espa&ccedil;os, acentos ou qualquer outro car�cter especial</span></td>
      </tr>
      <tr>
        <td height="45" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Senha</td>
        <td align="left"><input name="dj_senha" type="text" class="input" id="dj_senha" style="width:250px;" onkeyup="bloquear_acentos(this);" />
        <br />
        <span class="texto_padrao_pequeno">N&atilde;o use espa&ccedil;os, acentos ou qualquer outro caracter especial</span></td>
      </tr>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="submit" class="botao" value="Adicionar DJ" />
          <input type="button" class="botao" value="Voltar" onclick="window.location = '/informacoes';" />
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />
          </td>
      </tr>
    </table>
    <table width="500" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; background-color:#FFFF66; border:#DFDF00 1px solid">
      <tr>
        <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/dica.png" width="16" height="16" /></td>
        <td width="430" align="left" class="texto_padrao_pequeno" scope="col">Para se conectar ao streaming voc&ecirc; deve usar este formato como senha: login:senha</td>
      </tr>
    </table>
    <br />
    <img src="/admin/img/img-plugin-djport.jpg" alt="Dj Port" width="350" height="200" />
  </form>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
</body>
</html>
