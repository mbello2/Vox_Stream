<?php
require_once("admin/inc/conecta.php");
require_once("admin/inc/funcoes.php");

$porta = code_decode($_GET["porta"],"D");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));

// Standard inclusions 
include("admin/inc/pchart/pChart/pData.class");
include("admin/inc/pchart/pChart/pChart.class");

// Dataset definition 
$DataSet = new pData;

if($_GET["periodo"] == "diario") {

$titulo = "Média de Tempo de Conexão dos Ouvintes Diários do Streaming ".$dados_stm["porta"]."";

$array_dias_meses = array("01" => "31", "02" => "28", "03" => "31", "04" => "30", "05" => "31", "06" => "30", "07" => "31", "08" => "31", "09" => "30", "10" => "31", "11" => "30", "12" => "31");

for($i=1;$i<=$array_dias_meses["".$_GET["mes"].""];$i++){

$dia = sprintf("%02s",$i);

$soma = 0;
$contador = 0;

$query = mysql_query("SELECT * FROM estatisticas where codigo_stm = '".$dados_stm["codigo"]."' AND YEAR(data) = '".$_GET["ano"]."' AND MONTH(data) = '".$_GET["mes"]."' AND DAY(data) = '".$dia."'");
while ($dados_estatistica = mysql_fetch_array($query)) {

$soma += $dados_estatistica["tempo_conectado"];
$contador++;

}

$media = ($contador > 0) ? $soma / $contador : '0';

$DataSet->AddPoint(round($media),"total");  
$DataSet->AddPoint($dia."/".$_GET["mes"]."/".$_GET["ano"],"data");

}

$DataSet->SetYAxisName("Média de Tempo de Conexão em Minutos");
$DataSet->SetYAxisUnit(" min.");
$DataSet->AddAllSeries();
$DataSet->SetAbsciseLabelSerie("data");

} else { // else -> diário/mensal

$titulo = "Média de Tempo de Conexão dos Ouvintes Mensais do Streaming ".$dados_stm["porta"]."";

$array_meses = array(1 => 01, 2 => 02, 3 => 03, 4 => 04, 5 => 05, 6 => 06, 7 => 07, 8 => 08, 9 => 09, 10 => 10, 11 => 11, 12 => 12);
$array_meses_nomes = array(1 => "Janeiro", 2 => "Fevereiro", 3 => "Março", 4 => "Abril", 5 => "Maio", 6 => "Junho", 7 => "Julho", 8 => "Agosto", 9 => "Setembro", 10 => "Outubro", 11 => "Novembro", 12 => "Dezembro");

for($i=1;$i<=count($array_meses);$i++){

$mes = $i;

$soma = 0;
$contador = 0;

$query = mysql_query("SELECT * FROM estatisticas where codigo_stm = '".$dados_stm["codigo"]."' AND YEAR(data) = '".$_GET["ano"]."' AND MONTH(data) = '".$mes."'");
while ($dados_estatistica = mysql_fetch_array($query)) {

$soma += $dados_estatistica["tempo_conectado"];
$contador++;

}

$media = ($contador > 0) ? $soma / $contador : '0';

$DataSet->AddPoint(round($media),"total");  
$DataSet->AddPoint($array_meses_nomes[$mes]." de ".$_GET["ano"],"data");

}

}

$DataSet->SetYAxisName("Média de Tempo de Conexão em Minutos");
$DataSet->SetYAxisUnit(" min.");  
$DataSet->AddAllSeries();
$DataSet->SetAbsciseLabelSerie("data");

// Initialise the graph
$Test = new pChart(700,300);
$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",8);
$Test->setGraphArea(100,40,680,200);  
$Test->drawFilledRoundedRectangle(7,7,700,280,10,240,240,240);  
$Test->drawRoundedRectangle(5,5,700,280,10,270,270,270);  
$Test->drawGraphArea(255,255,255,TRUE);
$Test->drawScale($DataSet->GetData(),$DataSet->GetDataDescription(),SCALE_NORMAL,150,150,150,TRUE,45,2,TRUE);  
$Test->drawGrid(4,TRUE,230,230,230,50);  

// Draw the 0 line
$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",6);
$Test->drawTreshold(0,143,55,72,TRUE,TRUE);

// Draw the bar graph
$Test->drawBarGraph($DataSet->GetData(),$DataSet->GetDataDescription(),TRUE);

$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",8);
$Test->setColorPalette(0,0,0,0);
$Test->writeValues($DataSet->GetData(),$DataSet->GetDataDescription(),"total");

// Finish the graph
$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",10);
$Test->setColorPalette(0,0,0,0);
$Test->drawTitle(0,30,$titulo,50,50,50,705);
$Test->Stroke();
?>