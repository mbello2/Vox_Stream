<?php
//Pegando URL
 $dominio = $_SERVER['HTTP_HOST'];
//Tabela: MYSQL WOWZA
	$resultado = mysql_query("SELECT*FROM servidorwowza");
	$linhas = mysql_num_rows($resultado);
	while ($linha = mysql_fetch_array($resultado)){
	$ipwowza 				= $linha["ipwowza"];
	$userwowza 				= $linha["userwowza"];
	$senhawowza 			= $linha["senhawowza"];
	$portawowza				= $linha["portawowza"];
	$versaowowza			= $linha["versaowowza"];
	$portwowza 				= $linha["portwowza"];
	$pontowowza 			= $linha["pontowowza"];
;}
$rtmp = "rtmp://$ipwowza:$portwowza/$pontowowza";

require_once("admin/inc/protecao-final.php");

$porta_code = code_decode($dados_stm["porta"],"E");
$porta = code_decode(query_string('3'),"D");

$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_play = mysql_fetch_array(mysql_query("SELECT * FROM playlists where nome = '".$dados_stm["codigo_play"]."'"));
$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
$porta_code = code_decode($dados_stm["porta"],"E");
$porta = code_decode(query_string('3'),"D");
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/encrementos.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/painel.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/modal.css" />
<!--Titulo da Página-->
<title>Player AACPlus :: <?php echo $titulo_pag = ($dados_revenda["titulo_pag"] == "") ? "Streaming" : $dados_revenda["titulo_pag"]; ?></title>
<!--JS-->
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/ajax-streaming.js"></script>
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/javascript.js"></script>
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/sorttable.js"></script>
<?php
//arrais necessarias
$ipservidorstream = $dados_servidor["ip"];
$portastreaming = $dados_stm["porta"];

?>
</head>

<body>
<!--Bar-->
<div id="bar"></div>
<!--Estrutural-->
<div id="estrutura">
	<!--Logomarca-->
    <div class="logomarca">
    <center>
    <img src="<?php echo $url_logo; ?>" />
    </center>
    </div>
<!--Divisão-->
<div class="box2">
<div class="one_half">
 <div class="pagina2">
    			<!--Titulo-->
        		<div class="pagina2titulo">
                Estatística
                </div>
            <!--Conteudo-->
            <div class="pagin2texto">
            <table class="table table-bordered">
							  <tbody>
								<tr>
									<td class="center">Status</td>
									<td class="center">
                                 <!--
                                 <span class="badge badge-important">Desligado</span>
                                  -->
                                  <span id="<?php echo $dados_stm["porta"]; ?>" style="cursor:pointer" onclick="status_streaming('<?php echo $dados_stm["porta"]; ?>')"></span>
                                    </td>
								</tr>
								<tr>
									<td class="center">Ouvintes</td>
									<td class="center">
                                    <?php
									if ($status_streaming == "desligado"){
										echo '<span class="badge badge-important">!</span>';
									}
									else {
									include("ouvinte.php");
									}
									?>
                                    </td>
								</tr>
								<tr>
									<td class="center">Playlist</td>
									<td class="center">Músicas Selecionadas</td>
								</tr>
								   
                                <tr>
									<td class="center">Shoutcast</td>
									<td class="center"><a href="http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>" target="_blank">Abrir Shoutcast</a></td>
								</tr>  
                                <tr>
									<td class="center">Música</td>
									<td class="center">
                                    <?php
									if ($status_streaming == "desligado"){
										echo '<span class="badge badge-important">!</span>';
									}
									else {
										include("tocando.php");
									}
									?>
                                    </td>
								</tr>                               
							  </tbody>
						 </table>  
            </div>
    		</div>
</div>
<div class="one_half column-last">
<div class="pagina">
                <!--Titulo-->
        		<div class="paginatitulo">
                Player AACPLUS
                <div class="botao3"><a href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/streaming" class="btn btn-inverse">Home</a></div>
                </div>
        			
                    <!--Conteudo-->
            		<div class="paginatexto">
                    <center>
                    <b>Player Padrão:</b><br />
                    <embed src='http://<?=$dominio; ?>/elementos/players/acc.swf' allowscriptaccess='always' allowfullscreen='true' flashvars='height=20&width=260&file=<?=$rtmp?>&id=http://<?=$dados_servidor["ip"]; ?>:<?=$dados_stm["porta"]; ?>/;type=rmtp&volume=100&bufferlength=10&autostart=true' height='20' width='260'><br />
                    
<textarea name="textarea" id="textarea" cols="60" rows="6" style="width:400px;height:100px;">
<embed src='http://<?=$dominio; ?>/elementos/players/acc.swf' allowscriptaccess='always' allowfullscreen='true' flashvars='height=20&width=260&file=<?=$rtmp?>&id=http://<?=$dados_servidor["ip"]; ?>:<?=$dados_stm["porta"]; ?>/;type=rmtp&volume=100&bufferlength=10&autostart=true' height='20' width='260'></textarea>
             <br/>
             <br />
             <b>Player 01:</b><br />
             <object data="http://<?=$dominio?>/elementos/players/player01.swf" type="application/x-shockwave-flash" height="38" width="390"><param value="true" name="allowfullscreen"><param value="always" name="allowscriptaccess"><param value="stream=mob-<?=$dados_stm["porta"]; ?>.stream&rtmp=<?=$rtmp ?>" name="flashvars"></object>
             <br />
<textarea name="textarea" id="textarea" cols="60" rows="6" style="width:400px;height:100px;">
<object data="http://<?=$dominio?>/elementos/players/player01.swf" type="application/x-shockwave-flash" height="38" width="390"><param value="true" name="allowfullscreen"><param value="always" name="allowscriptaccess"><param value="stream=mob-<?=$dados_stm["porta"]; ?>.stream&rtmp=<?=$rtmp ?>" name="flashvars"></object>
</textarea>
<br /><br />
<b>Player HTML5:</b><br />
<iframe src="http://<?=$dominio; ?>/playerhtml5.php?url=http://<?=$ipservidorstream; ?>:<?=$portastreaming; ?>&url_rtmp=<?=$rtmp; ?>" frameborder="0" height="35" scrolling="no" width="485"></iframe>
<br />
<textarea name="textarea" id="textarea" cols="60" rows="6" style="width:400px;height:100px;">
<iframe src="http://<?=$dominio; ?>/playerhtml5.php?url=http://<?=$ipservidorstream; ?>:<?=$portastreaming; ?>&url_rtmp=<?=$rtmp; ?>" frameborder="0" height="35" scrolling="no" width="485"></iframe>
</textarea>
<br /><br />
<b>Player Topo:</b><br />
<iframe src="http://<?=$dominio; ?>/player-topo.php?ip=<?=$ipservidorstream; ?>&porta=<?=$portastreaming; ?>&rtmp=<?=$rtmp; ?>" frameborder="0" height="36" scrolling="no" width="100%"></iframe>
<br />
<textarea name="textarea" id="textarea" cols="60" rows="6" style="width:400px;height:100px;">
<iframe src="http://<?=$dominio; ?>/player-topo.php?ip=<?=$ipservidorstream; ?>&porta=<?=$portastreaming; ?>&rtmp=<?=$rtmp; ?>" frameborder="0" height="36" scrolling="no" width="100%"></iframe>
</textarea>
             
             
                    </center>
                	<br />
                    </div>
    		</div>
</div>
<div class="tsc_clear"></div>
<!--Fim da Divisão-->
</div>
</div>
<!--Rodape-->
<div id="rodape">
	<div id="estrutura">
    	<div class="dadosrod">
        © Copyright 2013-2014. <a href="http://<?php echo $site = ($dados_revenda["site"] == "") ? "http://ungservidores.net" : $dados_revenda["site"]; ?>" target="_blank"><strong><?php echo $empresa = ($dados_revenda["titulo_pag"] == "") ? "NGB" : $dados_revenda["empresa"]; ?></strong></a> - Todos Direitos Reservados.
        </div>
    </div>
</div>
<!-- Início div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="admin/img/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
status_streaming('<?php echo $dados_stm["porta"]; ?>');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp');
</script>
</body>
</html>