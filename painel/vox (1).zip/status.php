<?php
require_once("admin/inc/protecao-final.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_stm["ultima_playlist"]."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);

 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, "http://".$dados_servidor["ip"].":".$dados_stm["porta"]."/admin.cgi?sid=1&pass=dj".$dados_stm["senha"]."&mode=viewxml");
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
 curl_setopt($ch, CURLOPT_TIMEOUT, 5);
 $resultado = curl_exec($ch);
 curl_close($ch);
 $xml = @simplexml_load_string(utf8_encode($resultado));
 $musica_atual = $xml->SONGTITLE;
 $segundos = $xml->WEBHITS;


 //$segundos = 8933;
 $horas = (int) ($segundos/3600);
 $segundos = $segundos % 3600;
 $minutos = (int) ($segundos/60);
 $segundos = $segundos % 60;

if($dados_stm["aacplus"] == 'sim') {
$formato = "AAC+ sem Plugin(rtmp)";
} elseif($dados_stm["aacplus"] == 'nao' && $dados_stm["encoder"] == 'aacp') {
$formato = "AAC+ simples";
} else {
$formato = "MP3";
}

$porta_code = code_decode($dados_stm["porta"],"E");

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $dados_stm["porta"]; ?> Gerenciamento de Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon" />
<link href="inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="./index.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="./wwb10.min.js"></script>
<script type="text/javascript" src="admin/inc/ajax-stm.js"></script>
<script type="text/javascript" src="admin/inc/javascript.js"></script>
<script type="text/javascript" src="admin/inc/sorttable.js"></script>
<style>
<div id="topo-status" class="texto_padrao">
<span style="font-size:30px;"id="<?php echo $dados_stm["porta"]; ?>" style="cursor:pointer" onclick="status_streaming('<?php echo $dados_stm["porta"]; ?>')"></span></span>
</div>