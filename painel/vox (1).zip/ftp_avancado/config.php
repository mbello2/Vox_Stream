<?php

# Open README file for descriptions and help.

$ftpHost = "";
$ftpPort = "21";
$ftpMode = "1";
$ftpSSL  = "0";
$ftpDir  = "";
$serverTmp = "/tmp";
$editableExts = "mp3";
$dateFormatUsa = 0;
$lockOutTime = 5;
$versionCheck = 1;
$showAdvOption = 1;
$showLockSess = 1;
$showHostInfo = 1;

?>