<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php
//Pegando URL
 $dominio= $_SERVER['HTTP_HOST'];
//Tabela: MYSQL WOWZA
	$resultado = mysql_query("SELECT*FROM servidorwowza");
	$linhas = mysql_num_rows($resultado);
	while ($linha = mysql_fetch_array($resultado)){
	$ipwowza 				= $linha["ipwowza"];
	$userwowza 				= $linha["userwowza"];
	$senhawowza 			= $linha["senhawowza"];
	$portawowza				= $linha["portawowza"];
	$versaowowza				= $linha["versaowowza"];
	$portwowza 				= $linha["portwowza"];
	$pontowowza 			= $linha["pontowowza"];
;}
//Geração de nome personalizado
$tamanho = mt_rand(5,9);
$all_str = "abcdefghijlkmnopqrstuvxyzwABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
$nomearquivo = "";
for ($i = 0;$i <= $tamanho;$i++){
   $nomearquivo .= $all_str[mt_rand(0,61)];
}
 
require_once("admin/inc/protecao-final.php");

$porta_code = code_decode($dados_stm["porta"],"E");
$porta = code_decode(query_string('3'),"D");

$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_play = mysql_fetch_array(mysql_query("SELECT * FROM playlists where nome = '".$dados_stm["codigo_play"]."'"));
$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
$porta_code = code_decode($dados_stm["porta"],"E");
$porta = code_decode(query_string('3'),"D");
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/encrementos.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/painel.css" />
<link rel="stylesheet" type="text/css" href="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/css/modal.css" />
<style type="text/css">
#estrutura .box2 .one_half.column-last .pagina .paginatexto center center b h3 font {
	color: #0C0;
}
</style>
<!--Titulo da Página-->
<title>[<?php echo $dados_stm["porta"]; ?>] Gerenciamento de Streaming <?php echo $titulo_pag = ($dados_revenda["titulo_pag"] == "") ? "Streaming" : $dados_revenda["titulo_pag"]; ?></title>
<!--JS-->
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/ajax-streaming.js"></script>
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/javascript.js"></script>
<script type="text/javascript" src="<?php echo 'http://'.$_SERVER['HTTP_HOST']; ?>/elementos/js/sorttable.js"></script>

</head>

<body>
<!--Bar-->
<div id="bar"></div>
<!--Estrutural-->
<div id="estrutura">
	<!--Logomarca-->
    <div class="logomarca">
    <center>
    </center>
    </div>
    <div class="box2">
  <div class="one_half column-last">
    <div class="pagina">
      <div class="paginatitulo">
        <div class="botao3"></div>
              </div>
        			
                    <!--Conteudo-->
            		<div class="paginatexto">
                    <center>
                    <?php
$ip		 	= $dados_servidor["ip"];
$porta		= $dados_stm["porta"];
$nomeradio	= $dados_stm["streamtitle"];
$rtmp 		= 'rtmp://'.$ipwowza.':'.$portwowza.'/shoutcast';

# Colocando nome no arquivo
$pagename = "elementos/fb/$porta.html";

# Texto a ser salvo no arquivo
$texto = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#" lang="en-US">
<meta property="og:site_name" content="Estou ouvindo: '.$nomeradio.'" />
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta property="fb:app_id" content="1535720696641727" />
<meta property="og:title" content="Estou ouvindo: '.$nomeradio.'" />
<meta property="og:description" content="Curta comigo tambem! Clique no Play ao lado para ouvir!">
<meta property="og:type" content="movie" />
<meta property="og:url" content="http://'.$ip.':'.$porta.'" />
<meta property="og:image" content="http://'.$dominio.'/elementos/imagens/img-icone-play-facebook.jpg" />
<meta property="og:video" content="https://www.hoost.com.br/player/facebook/player.swf?file=http://'.$ip.':'.$porta.'&streamer='.$rtmp.'&autostart=true" />
<meta property="og:video:secure_url" content="https://www.hoost.com.br/player/facebook/player.swf?file=http://'.$ip.':'.$porta.'&streamer='.$rtmp.'&autostart=true" />
<meta property="og:video:type" content="application/x-shockwave-flash" />
<meta property="og:video:height" content="30" />
<meta property="og:video:width" content="388" />
<meta http-equiv="refresh" content="50; url=http://'.$dominio.'/streaming">

<title>radio teste</title>
<head> 
<link rel="shortcut icon" href="http://'.$dominio.'/elementos/imagens/img-icone-play-facebook.jpg" type="image/x-icon"/>

	  </head>
	  
<body oncontextmenu="return false" onkeydown="return false">
</body>
</html>
';

#Criar o arquivo
$fp = fopen($pagename , "w");
$fw = fwrite($fp, $texto);
?>

<!--Mensagem Sucesso-->
<center><b><h3><font color="#99FF33">Seu player NGB foi Gerado com Sucesso!</font></h3></b></center>

<!--Código do Player-->
<center>
<a class="quick-button span2" align="center" href="javascript: void(0);" onClick="window.open('http://www.facebook.com/sharer.php?u=http://<?php echo"$dominio"; ?>/elementos/fb/<?php echo"$porta"; ?>.html','ventanacompartir', 'toolbar=0, status=0, width=650, height=450');">
<button class="btn btn-danger" style="margin-left:2px;">Compartilhar</button>
</a>
</center>

<br />
<br />
                    </center>
                	<br />
                    </div>
    		</div>
</div>
<div class="tsc_clear"></div>
<!--Fim da Divisão-->
</div>
</div>
<!--Rodape-->
<div id="rodape">
	<div id="estrutura">
    	<div class="dadosrod"></div>
    </div>
</div>
<!-- Início div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="admin/img/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
status_streaming('<?php echo $dados_stm["porta"]; ?>');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp');
</script>
</body>
</html>
<body>
</body>
</html>