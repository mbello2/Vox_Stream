<?php

$porta = code_decode(query_string('1'),"D");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));

$xml = new XMLWriter;
$xml->openMemory();
$xml->startDocument('1.0','iso-8859-1');

$xml->startElement("info");

if($dados_stm["status"] == 1) {

$info = shoutcast_info($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);

############################ Status do Streaming ############################

$status_conexao = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
$status_conexao_autodj = status_autodj($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);
$status_conexao_relay = status_relay($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);

if($status_conexao_relay == "ligado") {
$status_streaming = "Relay";
}

if($status_conexao_autodj == "ligado") {
$status_streaming = "AutoDJ";
}

if($status_conexao == "ligado") {
$status_streaming = "Ligado";
}

############################ Ouvintes Conectados ############################


if($dados_stm["aacplus"] == 'sim' && $dados_servidor_aacplus["ip"] != '') {

$stats_shoutcast = stats_ouvintes_shoutcast($dados_stm["porta"],$dados_servidor["ip"],$dados_stm["senha"]);
$stats_aacplus = stats_ouvintes_aacplus($dados_stm["porta"],$dados_servidor_aacplus["ip"],$dados_servidor_aacplus["senha"]);
$ouvintes_conectados = $stats_shoutcast["ouvintes"]+$stats_aacplus["ouvintes"];

if($ouvintes_conectados == 0) {
$ouvintes_conectados = $ouvintes_conectados;
} else {
$ouvintes_conectados = $ouvintes_conectados-1;
}

} else {

$stats_shoutcast = stats_ouvintes_shoutcast($dados_stm["porta"],$dados_servidor["ip"],$dados_stm["senha"]);
$ouvintes_conectados = $stats_shoutcast["ouvintes"];

}

#############################################################################
$xml->writeElement("status", $status_streaming);
$xml->writeElement("porta", $dados_stm["porta"]);
$xml->writeElement("porta_dj", $dados_stm["porta_dj"]);
$xml->writeElement("ip", $dados_servidor["ip"]);
$xml->writeElement("ouvintes_conectados", $ouvintes_conectados);
$xml->writeElement("titulo", $info["titulo"]);
$xml->writeElement("plano_ouvintes", $dados_stm["ouvintes"]);
$xml->writeElement("plano_ftp", tamanho($dados_stm["espaco"]));
$xml->writeElement("plano_bitrate", $dados_stm["bitrate"]."Kbps");
$xml->writeElement("musica_atual", $info["musica"]);
$xml->writeElement("shoutcast", "http://".$dados_servidor["ip"].":".$dados_stm["porta"]."");

if($dados_stm["aacplus"] == 'sim') {
$xml->writeElement("rtmp", "rtmp://".$dados_servidor_aacplus["ip"]."/".$dados_stm["porta"]."/&id=".$dados_stm["porta"].".stream");
$xml->writeElement("rtsp", "rtsp://".$dados_servidor_aacplus["ip"]."/".$dados_stm["porta"]."/".$dados_stm["porta"].".stream");
}

} else {

$xml->writeElement("status", "Desligado");

}

$xml->endElement();

header('Content-type: text/xml');

print $xml->outputMemory(true);

?>