<?php
require_once("admin/inc/protecao-final.php");
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$porta = code_decode(query_string('1'),"D");
$porta_code = query_string('1');
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));

// Verifica se o streaming � do cliente
if($dados_stm["porta"] != $_SESSION["porta_logada"]) {


}

if($_POST["cadastrar"]) {

if(!empty($_POST["dj_login"]) or !empty($_POST["dj_senha"])) {

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));

mysql_query("INSERT INTO djs (codigo_stm,login,senha) VALUES ('".$dados_stm["codigo"]."','".$_POST["dj_login"]."','".$_POST["dj_senha"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("DJ ".$_POST["dj_login"]." adicionado com sucesso.","ok");

} else {

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Voc� deve preencher o campo Login e Senha para o DJ.","ok");

}

}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo "$Locutor2";?></title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/relay/ajax.js"></script>
<script type="text/javascript" src="/admin/inc/relay/javascript.js"></script>
</head>
        <form method="post" action="/fechar/<?php echo $porta_code; ?>" style="padding:0px; margin:0px" name="agendamentos">
        <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:20px;">
        <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Crie um Login</td>
        <td align="left" valign="middle" class="texto_padrao_pequeno"><input name="dj_login" type="text" class="input" id="dj_login" style="width:250px;" required> N�o caracteres especiais
        </td>
      
        <tr><br />&nbsp;<div id="quadro-topo"> <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <?php echo "$Locutor1";?></strong></div>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Crie uma Senha</td>
        <td align="left" valign="middle" class="texto_padrao_pequeno"><input name="dj_senha" type="text" class="input" id="dj_senha" style="width:250px;" required> N�o caracteres especiais
        </td>
        </tr>
        <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Hor�rio:</td>
        <td align="left" class="texto_padrao_pequeno">
        <select name="inicio_hora" id="inicio_hora" style="width:85px;">
          
<option value="00"<?php if($hora_rl == "00") { echo ' selected="selected"'; } ?>>00</option>         
<option value="23"<?php if($hora_rl == "23") { echo ' selected="selected"'; } ?>>23</option>
<option value="22"<?php if($hora_rl == "22") { echo ' selected="selected"'; } ?>>22</option>
<option value="21"<?php if($hora_rl == "21") { echo ' selected="selected"'; } ?>>21</option>
<option value="20"<?php if($hora_rl == "20") { echo ' selected="selected"'; } ?>>20</option>
<option value="19"<?php if($hora_rl == "19") { echo ' selected="selected"'; } ?>>19</option>
<option value="18"<?php if($hora_rl == "18") { echo ' selected="selected"'; } ?>>18</option>
<option value="17"<?php if($hora_rl == "17") { echo ' selected="selected"'; } ?>>17</option>
<option value="16"<?php if($hora_rl == "16") { echo ' selected="selected"'; } ?>>16</option>
<option value="15"<?php if($hora_rl == "15") { echo ' selected="selected"'; } ?>>15</option>
<option value="14"<?php if($hora_rl == "14") { echo ' selected="selected"'; } ?>>14</option>
<option value="13"<?php if($hora_rl == "13") { echo ' selected="selected"'; } ?>>13</option>
<option value="12"<?php if($hora_rl == "12") { echo ' selected="selected"'; } ?>>12</option>
<option value="11"<?php if($hora_rl == "11") { echo ' selected="selected"'; } ?>>11</option>
<option value="10"<?php if($hora_rl == "10") { echo ' selected="selected"'; } ?>>10</option>
<option value="09"<?php if($hora_rl == "09") { echo ' selected="selected"'; } ?>>09</option>
<option value="08"<?php if($hora_rl == "08") { echo ' selected="selected"'; } ?>>08</option>
<option value="07"<?php if($hora_rl == "07") { echo ' selected="selected"'; } ?>>07</option>
<option value="06"<?php if($hora_rl == "06") { echo ' selected="selected"'; } ?>>06</option>
<option value="05"<?php if($hora_rl == "05") { echo ' selected="selected"'; } ?>>05</option>
<option value="04"<?php if($hora_rl == "04") { echo ' selected="selected"'; } ?>>04</option>
<option value="03"<?php if($hora_rl == "03") { echo ' selected="selected"'; } ?>>03</option>
<option value="02"<?php if($hora_rl == "02") { echo ' selected="selected"'; } ?>>02</option>
<option value="01"<?php if($hora_rl == "01") { echo ' selected="selected"'; } ?>>01</option>
        </select>
          
     
          <span class="texto_padrao_titulo">:</span>&nbsp;
          <select name="inicio_minu" id="inicio_minu" style="width:50px;">
             
                       
<option value="00"<?php if($I_rl == "00") { echo ' selected="selected"'; } ?>>00</option>
<option value="59"<?php if($I_rl == "59") { echo ' selected="selected"'; } ?>>59</option>
<option value="58"<?php if($I_rl == "58") { echo ' selected="selected"'; } ?>>58</option>
<option value="57"<?php if($I_rl == "57") { echo ' selected="selected"'; } ?>>57</option>
<option value="56"<?php if($I_rl == "56") { echo ' selected="selected"'; } ?>>56</option>
<option value="55"<?php if($I_rl == "55") { echo ' selected="selected"'; } ?>>55</option>
<option value="54"<?php if($I_rl == "54") { echo ' selected="selected"'; } ?>>54</option>
<option value="53"<?php if($I_rl == "53") { echo ' selected="selected"'; } ?>>53</option>
<option value="52"<?php if($I_rl == "52") { echo ' selected="selected"'; } ?>>52</option>
<option value="51"<?php if($I_rl == "51") { echo ' selected="selected"'; } ?>>51</option>
<option value="50"<?php if($I_rl == "50") { echo ' selected="selected"'; } ?>>50</option>
<option value="49"<?php if($I_rl == "49") { echo ' selected="selected"'; } ?>>49</option>
<option value="48"<?php if($I_rl == "48") { echo ' selected="selected"'; } ?>>48</option>
<option value="47"<?php if($I_rl == "47") { echo ' selected="selected"'; } ?>>47</option>
<option value="46"<?php if($I_rl == "46") { echo ' selected="selected"'; } ?>>46</option> 
<option value="45"<?php if($I_rl == "45") { echo ' selected="selected"'; } ?>>45</option>
<option value="44"<?php if($I_rl == "44") { echo ' selected="selected"'; } ?>>44</option>
<option value="43"<?php if($I_rl == "43") { echo ' selected="selected"'; } ?>>43</option>
<option value="42"<?php if($I_rl == "42") { echo ' selected="selected"'; } ?>>42</option>
<option value="41"<?php if($I_rl == "41") { echo ' selected="selected"'; } ?>>41</option>
<option value="40"<?php if($I_rl == "40") { echo ' selected="selected"'; } ?>>40</option>
<option value="39"<?php if($I_rl == "39") { echo ' selected="selected"'; } ?>>39</option>
<option value="38"<?php if($I_rl == "38") { echo ' selected="selected"'; } ?>>38</option>
<option value="37"<?php if($I_rl == "37") { echo ' selected="selected"'; } ?>>37</option>
<option value="36"<?php if($I_rl == "36") { echo ' selected="selected"'; } ?>>36</option>
<option value="35"<?php if($I_rl == "35") { echo ' selected="selected"'; } ?>>35</option>
<option value="34"<?php if($I_rl == "34") { echo ' selected="selected"'; } ?>>34</option>
<option value="33"<?php if($I_rl == "33") { echo ' selected="selected"'; } ?>>33</option>
<option value="32"<?php if($I_rl == "32") { echo ' selected="selected"'; } ?>>32</option>
<option value="31"<?php if($I_rl == "31") { echo ' selected="selected"'; } ?>>31</option>
<option value="30"<?php if($I_rl == "30") { echo ' selected="selected"'; } ?>>30</option>
<option value="29"<?php if($I_rl == "29") { echo ' selected="selected"'; } ?>>29</option>
<option value="28"<?php if($I_rl == "28") { echo ' selected="selected"'; } ?>>28</option>
<option value="24"<?php if($I_rl == "27") { echo ' selected="selected"'; } ?>>27</option>
<option value="26"<?php if($I_rl == "26") { echo ' selected="selected"'; } ?>>26</option> 
<option value="25"<?php if($I_rl == "25") { echo ' selected="selected"'; } ?>>25</option>
<option value="24"<?php if($I_rl == "24") { echo ' selected="selected"'; } ?>>24</option>
<option value="23"<?php if($I_rl == "23") { echo ' selected="selected"'; } ?>>23</option> 
<option value="22"<?php if($I_rl == "22") { echo ' selected="selected"'; } ?>>22</option>
<option value="21"<?php if($I_rl == "21") { echo ' selected="selected"'; } ?>>21</option>
<option value="20"<?php if($I_rl == "20") { echo ' selected="selected"'; } ?>>20</option>
<option value="19"<?php if($I_rl == "19") { echo ' selected="selected"'; } ?>>19</option>
<option value="18"<?php if($I_rl == "18") { echo ' selected="selected"'; } ?>>18</option>
<option value="17"<?php if($I_rl == "17") { echo ' selected="selected"'; } ?>>17</option>
<option value="16"<?php if($I_rl == "16") { echo ' selected="selected"'; } ?>>16</option>
<option value="15"<?php if($I_rl == "15") { echo ' selected="selected"'; } ?>>15</option>
<option value="14"<?php if($I_rl == "14") { echo ' selected="selected"'; } ?>>14</option>
<option value="13"<?php if($I_rl == "13") { echo ' selected="selected"'; } ?>>13</option>
<option value="12"<?php if($I_rl == "12") { echo ' selected="selected"'; } ?>>12</option>
<option value="11"<?php if($I_rl == "11") { echo ' selected="selected"'; } ?>>11</option>
<option value="10"<?php if($I_rl == "10") { echo ' selected="selected"'; } ?>>10</option>
<option value="09"<?php if($I_rl == "09") { echo ' selected="selected"'; } ?>>09</option>
<option value="08"<?php if($I_rl == "08") { echo ' selected="selected"'; } ?>>08</option>
<option value="07"<?php if($I_rl == "07") { echo ' selected="selected"'; } ?>>07</option>
<option value="06"<?php if($I_rl == "06") { echo ' selected="selected"'; } ?>>06</option>
<option value="05"<?php if($I_rl == "05") { echo ' selected="selected"'; } ?>>05</option>
<option value="04"<?php if($I_rl == "04") { echo ' selected="selected"'; } ?>>04</option>
<option value="03"<?php if($I_rl == "03") { echo ' selected="selected"'; } ?>>03</option>
<option value="02"<?php if($I_rl == "02") { echo ' selected="selected"'; } ?>>02</option>
<option value="01"<?php if($I_rl == "01") { echo ' selected="selected"'; } ?>>01</option>
          </select>
          
     
          <span class="texto_padrao_destaque">At�</span>&nbsp;
        <select name="final_hora" id="final_hora" style="width:85px;">
          
<option value="00"<?php if($hora_rl1 == "00") { echo ' selected="selected"'; } ?>>00</option>          
<option value="23"<?php if($hora_rl1 == "23") { echo ' selected="selected"'; } ?>>23</option>
<option value="22"<?php if($hora_rl1 == "22") { echo ' selected="selected"'; } ?>>22</option>
<option value="21"<?php if($hora_rl1 == "21") { echo ' selected="selected"'; } ?>>21</option>
<option value="20"<?php if($hora_rl1 == "20") { echo ' selected="selected"'; } ?>>20</option>
<option value="19"<?php if($hora_rl1 == "19") { echo ' selected="selected"'; } ?>>19</option>
<option value="18"<?php if($hora_rl1 == "18") { echo ' selected="selected"'; } ?>>18</option>
<option value="17"<?php if($hora_rl1 == "17") { echo ' selected="selected"'; } ?>>17</option>
<option value="16"<?php if($hora_rl1 == "16") { echo ' selected="selected"'; } ?>>16</option>
<option value="15"<?php if($hora_rl1 == "15") { echo ' selected="selected"'; } ?>>15</option>
<option value="14"<?php if($hora_rl1 == "14") { echo ' selected="selected"'; } ?>>14</option>
<option value="13"<?php if($hora_rl1 == "13") { echo ' selected="selected"'; } ?>>13</option>
<option value="12"<?php if($hora_rl1 == "12") { echo ' selected="selected"'; } ?>>12</option>
<option value="11"<?php if($hora_rl1 == "11") { echo ' selected="selected"'; } ?>>11</option>
<option value="10"<?php if($hora_rl1 == "10") { echo ' selected="selected"'; } ?>>10</option>
<option value="09"<?php if($hora_rl1 == "09") { echo ' selected="selected"'; } ?>>09</option>
<option value="08"<?php if($hora_rl1 == "08") { echo ' selected="selected"'; } ?>>08</option>
<option value="07"<?php if($hora_rl1 == "07") { echo ' selected="selected"'; } ?>>07</option>
<option value="06"<?php if($hora_rl1 == "06") { echo ' selected="selected"'; } ?>>06</option>
<option value="05"<?php if($hora_rl1 == "05") { echo ' selected="selected"'; } ?>>05</option>
<option value="04"<?php if($hora_rl1 == "04") { echo ' selected="selected"'; } ?>>04</option>
<option value="03"<?php if($hora_rl1 == "03") { echo ' selected="selected"'; } ?>>03</option>
<option value="02"<?php if($hora_rl1 == "02") { echo ' selected="selected"'; } ?>>02</option>
<option value="01"<?php if($hora_rl1 == "01") { echo ' selected="selected"'; } ?>>01</option>
        </select>
          
     
          <span class="texto_padrao_titulo">:</span>&nbsp;
          <select name="final_minu" id="final_minu" style="width:50px;">
             
                       
                      <option value="00"<?php if($I_rl == "00") { echo ' selected="selected"'; } ?>>00</option>
<option value="59"<?php if($I_rl == "59") { echo ' selected="selected"'; } ?>>59</option>
<option value="58"<?php if($I_rl == "58") { echo ' selected="selected"'; } ?>>58</option>
<option value="57"<?php if($I_rl == "57") { echo ' selected="selected"'; } ?>>57</option>
<option value="56"<?php if($I_rl == "56") { echo ' selected="selected"'; } ?>>56</option>
<option value="55"<?php if($I_rl == "55") { echo ' selected="selected"'; } ?>>55</option>
<option value="54"<?php if($I_rl == "54") { echo ' selected="selected"'; } ?>>54</option>
<option value="53"<?php if($I_rl == "53") { echo ' selected="selected"'; } ?>>53</option>
<option value="52"<?php if($I_rl == "52") { echo ' selected="selected"'; } ?>>52</option>
<option value="51"<?php if($I_rl == "51") { echo ' selected="selected"'; } ?>>51</option>
<option value="50"<?php if($I_rl == "50") { echo ' selected="selected"'; } ?>>50</option>
<option value="49"<?php if($I_rl == "49") { echo ' selected="selected"'; } ?>>49</option>
<option value="48"<?php if($I_rl == "48") { echo ' selected="selected"'; } ?>>48</option>
<option value="47"<?php if($I_rl == "47") { echo ' selected="selected"'; } ?>>47</option>
<option value="46"<?php if($I_rl == "46") { echo ' selected="selected"'; } ?>>46</option> 
<option value="45"<?php if($I_rl == "45") { echo ' selected="selected"'; } ?>>45</option>
<option value="44"<?php if($I_rl == "44") { echo ' selected="selected"'; } ?>>44</option>
<option value="43"<?php if($I_rl == "43") { echo ' selected="selected"'; } ?>>43</option>
<option value="42"<?php if($I_rl == "42") { echo ' selected="selected"'; } ?>>42</option>
<option value="41"<?php if($I_rl == "41") { echo ' selected="selected"'; } ?>>41</option>
<option value="40"<?php if($I_rl == "40") { echo ' selected="selected"'; } ?>>40</option>
<option value="39"<?php if($I_rl == "39") { echo ' selected="selected"'; } ?>>39</option>
<option value="38"<?php if($I_rl == "38") { echo ' selected="selected"'; } ?>>38</option>
<option value="37"<?php if($I_rl == "37") { echo ' selected="selected"'; } ?>>37</option>
<option value="36"<?php if($I_rl == "36") { echo ' selected="selected"'; } ?>>36</option>
<option value="35"<?php if($I_rl == "35") { echo ' selected="selected"'; } ?>>35</option>
<option value="34"<?php if($I_rl == "34") { echo ' selected="selected"'; } ?>>34</option>
<option value="33"<?php if($I_rl == "33") { echo ' selected="selected"'; } ?>>33</option>
<option value="32"<?php if($I_rl == "32") { echo ' selected="selected"'; } ?>>32</option>
<option value="31"<?php if($I_rl == "31") { echo ' selected="selected"'; } ?>>31</option>
<option value="30"<?php if($I_rl == "30") { echo ' selected="selected"'; } ?>>30</option>
<option value="29"<?php if($I_rl == "29") { echo ' selected="selected"'; } ?>>29</option>
<option value="28"<?php if($I_rl == "28") { echo ' selected="selected"'; } ?>>28</option>
<option value="24"<?php if($I_rl == "27") { echo ' selected="selected"'; } ?>>27</option>
<option value="26"<?php if($I_rl == "26") { echo ' selected="selected"'; } ?>>26</option> 
<option value="25"<?php if($I_rl == "25") { echo ' selected="selected"'; } ?>>25</option>
<option value="24"<?php if($I_rl == "24") { echo ' selected="selected"'; } ?>>24</option>
<option value="23"<?php if($I_rl == "23") { echo ' selected="selected"'; } ?>>23</option> 
<option value="22"<?php if($I_rl == "22") { echo ' selected="selected"'; } ?>>22</option>
<option value="21"<?php if($I_rl == "21") { echo ' selected="selected"'; } ?>>21</option>
<option value="20"<?php if($I_rl == "20") { echo ' selected="selected"'; } ?>>20</option>
<option value="19"<?php if($I_rl == "19") { echo ' selected="selected"'; } ?>>19</option>
<option value="18"<?php if($I_rl == "18") { echo ' selected="selected"'; } ?>>18</option>
<option value="17"<?php if($I_rl == "17") { echo ' selected="selected"'; } ?>>17</option>
<option value="16"<?php if($I_rl == "16") { echo ' selected="selected"'; } ?>>16</option>
<option value="15"<?php if($I_rl == "15") { echo ' selected="selected"'; } ?>>15</option>
<option value="14"<?php if($I_rl == "14") { echo ' selected="selected"'; } ?>>14</option>
<option value="13"<?php if($I_rl == "13") { echo ' selected="selected"'; } ?>>13</option>
<option value="12"<?php if($I_rl == "12") { echo ' selected="selected"'; } ?>>12</option>
<option value="11"<?php if($I_rl == "11") { echo ' selected="selected"'; } ?>>11</option>
<option value="10"<?php if($I_rl == "10") { echo ' selected="selected"'; } ?>>10</option>
<option value="09"<?php if($I_rl == "09") { echo ' selected="selected"'; } ?>>09</option>
<option value="08"<?php if($I_rl == "08") { echo ' selected="selected"'; } ?>>08</option>
<option value="07"<?php if($I_rl == "07") { echo ' selected="selected"'; } ?>>07</option>
<option value="06"<?php if($I_rl == "06") { echo ' selected="selected"'; } ?>>06</option>
<option value="05"<?php if($I_rl == "05") { echo ' selected="selected"'; } ?>>05</option>
<option value="04"<?php if($I_rl == "04") { echo ' selected="selected"'; } ?>>04</option>
<option value="03"<?php if($I_rl == "03") { echo ' selected="selected"'; } ?>>03</option>
<option value="02"<?php if($I_rl == "02") { echo ' selected="selected"'; } ?>>02</option>
<option value="01"<?php if($I_rl == "01") { echo ' selected="selected"'; } ?>>01</option>
          </select></td>
      </tr>
 <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Restri��o de Hor�rio</td>
        <td align="left" valign="middle" class="texto_padrao_pequeno"><input name="restricao" type="checkbox" value="1" />
&nbsp;Marque esta op��o para restringir este usu�rio a transmitir apenas no hor�rio programado.</td>
      </tr>

<tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque"><?php echo "$AutoDJ_agendament17";?></td>
        <td align="left" valign="middle" class="texto_padrao">
        <input name="dias[]" type="checkbox" value="1" id="dias"  checked="checked">Domingo&nbsp;
        <input name="dias[]" type="checkbox" value="2" id="dias"  checked="checked">Segunda&nbsp;
        <input name="dias[]" type="checkbox" value="4" id="dias"  checked="checked">Ter�a&nbsp;
        <input name="dias[]" type="checkbox" value="8" id="dias"  checked="checked">Quarta&nbsp;
        <input name="dias[]" type="checkbox" value="16" id="dias" checked="checked">Quinta&nbsp;
        <input name="dias[]" type="checkbox" value="32" id="dias" checked="checked">Sexta&nbsp;
        <input name="dias[]" type="checkbox" value="64" id="dias" checked="checked">S�bado&nbsp;
        </td>
      </tr>
     
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="hidden" name="data" value="<?php echo "$data_dia/$data_mes/$data_ano";?>">
          
          <input type="hidden" name="funcao" value="<?=$dados_stm["codigo"];?>7">
          <input type="hidden" name="novo_codigo" value="<?=$novo_codigo;?>">
          <input type="hidden" name="repetir" value="0">
          <input type="submit" class="botao" value="Adicionar DJ/Locutor" />
          <input type="button" class="botao" value="Fechar" onclick="window.close();return false;">
          <?php
           if($dados_stm["shoutcast"] == 'aacp') { ?>
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />         </td>
          <?php
           } else { ?>
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />         </td>
          <?php
           } ?>
      </tr>
  </form>

<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="../Streaming_files/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
</table>
    <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px;">
      <tbody><tr>
        <td height="30" align="left" class="texto_padrao_destaque">
        <div id="quadro">
        <div id="quadro-topo"> <strong><?php echo "$AutoDJ_agendament31";?></strong></div>
        <div class="texto_medio" id="quadro-conteudo">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td height="25" class="texto_padrao_pequeno">
    </p>Ap�s adicionar o dj, reinicie o Auto DJ.</p>
    
    </span></td>
    </tr>
</tbody></table>
    </div>
      </div>
        </td>
      </tr>
    </tbody></table>
    <br>
  </form>
</div>
</html>



