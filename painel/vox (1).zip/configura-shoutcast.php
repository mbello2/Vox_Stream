<?php
require_once("admin/inc/protecao-final.php");
require_once('admin/inc/classe.ssh.php');
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));

$porta_code = code_decode($dados_stm["porta"],"E");

// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"].";/home/streaming/desligar_streaming ".$dados_stm["porta"]."");
        }


mysql_query("Update streamings set shoutcast = '".$_POST["shoutcast"]."' where porta = '".$_SESSION["porta_logada"]."'");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Configura��es do streaming ".$_SESSION["porta_logada"]." alteradas com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Agora voc� precisa desligar e ligar novamente o streaming para aplicar as altera��es.","alerta");

header("Location: /configurar-shoutcast/$porta_code");
?>