<?php
require_once("admin/inc/protecao-final.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));

$porta_code = code_decode($dados_stm["porta"],"E");

if(empty($_POST["senha"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

mysql_query("Update streamings set senha = '".$_POST["senha"]."', streamtitle = '".addslashes($_POST["streamtitle"])."', streamurl = '".$_POST["streamurl"]."', genre = '".addslashes($_POST["genre"])."', xfade = '".$_POST["xfade"]."', bitrate_autodj = '".$_POST["bitrate_autodj"]."', encoder = '".$_POST["encoder"]."' where porta = '".$_SESSION["porta_logada"]."'");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Configura��es do streaming ".$_SESSION["porta_logada"]." alteradas com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Agora voc� precisa desligar e ligar novamente o streaming para aplicar as altera��es.","alerta");

header("Location: /configurar-streaming/$porta_code");
?>