<?php
$dominio 	= $_SERVER['HTTP_HOST'];
$ip			= $_GET['ip'];
$porta		= $_GET['porta'];
$rtmp		= $_GET['rtmp'];
require_once('../../admin/inc/conecta.php');

//SHOUTCAST DADOS
$open = fsockopen($ip, $porta); if ($open) { fputs($open,"GET /7.html HTTP/1.1\nUser-Agent:Mozilla\n\n"); $read = fread($open,1000); $text = explode("content-type:text/html",$read); $text = explode(",",$text[1]); } else { $er="Connection Refused!"; }

//Tabela: MYSQL WOWZA
	$resultado = mysql_query("SELECT*FROM servidorwowza");
	$linhas = mysql_num_rows($resultado);
	while ($linha = mysql_fetch_array($resultado)){
	$ipwowza 				= $linha["ipwowza"];
	$userwowza 				= $linha["userwowza"];
	$senhawowza 			= $linha["senhawowza"];
	$portawowza				= $linha["portawowza"];
	$versaowowza			= $linha["versaowowza"];
	$portwowza 				= $linha["portwowza"];
	$pontowowza 			= $linha["pontowowza"];
;}
$rtsp = "rtsp://$ipwowza:$portwowza/$pontowowza/mob-$porta.stream";
$iphone = "http://$ipwowza:$portwowza/$pontowowza/mob-$porta.stream/playlist.m3u8";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Player Barra[<?=$porta?>]</title>
<script type="text/javascript" src="http://<?=$dominio?>/admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="http://<?=$dominio?>/admin/inc/javascript.js"></script>
<style>
body {
	background: #000000;
	margin: 0px auto;
	overflow: auto;
}
.texto_padrao {
	color: #FFFFFF;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size:11px;
	font-weight:normal;
}
#tocandoagora{
	position:relative;
	top:-25px;
	left:350px;
	width:500px;
}
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%" height="36" align="left"><embed src="http://<?=$dominio?>/elementos/players/player-topo.swf" width="100%" height="36" allowscriptaccess="always" allowfullscreen="true" flashvars="stream=http://<?=$ip?>:<?=$porta?>&rtmp=<?=$rtmp?>&autostart=true" type="application/x-shockwave-flash" /></embed></td>
    <td width="50%" height="36" align="right" background="http://<?=$dominio?>/elementos/imagens/img-icone-fundo-player-barra.jpg" class="texto_padrao" style="background:url(http://<?=$dominio?>/elementos/imagens/players/img-icone-fundo-player-barra.jpg) repeat-x; padding-right:px"><a href="http://<?=$dominio?>/elementos/radio-play/<?=$porta?>-winamp.pls" target="_blank"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-winamp.png" width="16" height="16" border="0" align="absmiddle" /></a>&nbsp;<a href="http://<?=$dominio?>/elementos/radio-play/<?=$porta?>-mediaplayer.asx"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-mediaplayer.png" width="16" height="16" border="0" align="absmiddle" /></a>&nbsp;<a href="http://<?=$dominio?>/elementos/radio-play/<?=$porta?>-realplayer.rm"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-realplayer.png" width="16" height="16" border="0" align="absmiddle" /></a>&nbsp;<a href="<?=$iphone?>"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-iphone.png" width="16" height="16" border="0" align="absmiddle" /></a>&nbsp;<a href="<?=$rtsp?>"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-android.png" width="16" height="16" border="0" align="absmiddle" /></a><a href="javascript: void(0);" onClick="window.open('http://www.facebook.com/sharer.php?u=http://<?php echo"$dominio"; ?>/elementos/fb/<?php echo"$porta"; ?>.html','ventanacompartir', 'toolbar=0, status=0, width=650, height=450');"><img src="http://<?=$dominio?>/elementos/imagens/players/img-icone-player-facebook.png" width="16" height="16" border="0" align="absmiddle" /></a></td>
  </tr>
</table>
<div id="tocandoagora">
<font class="texto_padrao">
<strong>Tocando agora: </strong><span id="musica_atual"><?=$text[6]?></span>
</font>
</div>
<script type="text/javascript">
function get_host() {

var url = location.href;
url = url.split("/");

return url[2];

}
// Atualizar informaÃ§Ãµes do streaming
musica_atual( <?=$porta?>,'musica_atual','70');
setInterval("musica_atual( <?=$porta?>,'musica_atual','70')",10000);
</script>
</body>
</html>
