<?php
//Pegando URL
 $dominio = $_SERVER['HTTP_HOST'];
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Streaming</title>
<meta name="robots" content="noindex, nofollow" />
<link rel="stylesheet" type="text/css" href="http://<?=$dominio?>/elementos/css/reset.css">
<link rel="stylesheet" type="text/css" href="http://<?=$dominio?>/elementos/css/style.css">
<script type='text/javascript' src='http://<?=$dominio?>/elementos/js/jquery.min.js'>// --- http://code.jquery.com/jquery.min.js</script>
<script type="text/javascript">
	$(document).ready(function() {
		calcHeight();
		$('.fx_fade').append('<SPAN class=hover></SPAN>').each(function () {
			var $span = $('> span.hover', this).css('opacity', 0);
			$(this).hover(function () {
				$span.stop().fadeTo(500, 1);
			}, function () {
				$span.stop().fadeTo(500, 0);
			});
		});
	});
	//function to fix height of iframe!
	var calcHeight = function() {var headerDimensions = $('#header-bar').height(); $('#preview-frame').height($(window).height() - headerDimensions);}
	$(window).resize(function() {calcHeight();}).load(function() {calcHeight();});
</script>

</script>

</head>
<body>
<script type='text/javascript' src='http://<?=$dominio?>/elementos/js/jwplayer.js'></script>
  <div id="centercolumn">
	  <div id="audio"><font size="1">É necessário atualizar o seu <a href="http://get.adobe.com/br/flashplayer/">Adobe Flash Player</a> para ouvir esta rádio.</font></div>
	</div>
<script type="text/javascript">
	
	var _file = '<?=$_GET['url'];?>';
	var _streamer = '<?=$_GET['url_rtmp'];?>';
	var _screencolor = '';

	var config = {
		'screencolor': _screencolor,
		'controlbar': 'none',
		'width': '480',
		'height': '35',
		//'volume':'100',
		'plugins': {
			'audiolivestream-1': {
				format: 'Tocando: %track',
				buffer: 'Carregando: %perc%',
				backgroundCss: 'gradient',
				trackCss: 'color: #fff; font-size: 11px;'
			}
		},
		'file': _file,
		'streamer': _streamer, 
		'autostart': 'true',
		'modes': [
			{
				type: 'flash',
				src: 'playerhtml5.swf'
			},
			{
				type: 'html5',
				config: {
					'file': _file,
					'provider': 'audio'
				}
			},
			{
				type: 'download',
				config: {
					'file': _file,
					'provider': 'audio'
				}
			}
		],
		events: {
		}
	}

	jwplayer('audio').setup(config);
</script>
</body>
</html>
<embed flashvars="file=http://<?=$_GET['url'];?>/;type=mp3&volume=0&bufferlength=10&autostart=true" allowscriptaccess="always" quality="high" src="http://<?=$dominio?>/elementos/players/player.swf" type="application/x-shockwave-flash" width="0" height="0">