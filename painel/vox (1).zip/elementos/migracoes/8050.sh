
ftp -in << EOF
open 50.30.35.23;
user revista_petropolis mpo6954;
binary;
cd 50.30.35.23:8382/media;
mget *mp3;
mget *MP3;
bye;
EOF;