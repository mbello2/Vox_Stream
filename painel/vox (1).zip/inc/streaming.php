<?php
require_once("admin/inc/protecao-final.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_stm["ultima_playlist"]."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));

if($dados_stm["status"] == 1 && $dados_servidor["status"] == "on") {
$info = shoutcast_info($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);
}

if($dados_stm["aacplus"] == 'sim') {
$formato = "AAC+ sem Plugin(rtmp)";
} elseif($dados_stm["aacplus"] == 'nao' && $dados_stm["encoder"] == 'aacp') {
$formato = "AAC+ simples";
} else {
$formato = "MP3";
}

$porta_code = code_decode($dados_stm["porta"],"E");

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="admin/inc/javascript.js"></script>
<script type="text/javascript" src="admin/inc/sorttable.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="conteudo">
<?php if($dados_servidor["status"] == "on") { ?>
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="580" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>

<?php 
$total_dicas_rapidas = mysql_num_rows(mysql_query("SELECT * FROM dicas_rapidas where exibir = 'sim'"));

if($total_dicas_rapidas > 0) {

$dados_dica_rapida = mysql_fetch_array(mysql_query("SELECT * FROM dicas_rapidas where exibir = 'sim' ORDER BY RAND() LIMIT 1"));

$dados_dicas_rapidas_acesso = mysql_fetch_array(mysql_query("SELECT * FROM dicas_rapidas_acessos where codigo_stm = '".$dados_stm["codigo"]."' AND codigo_dica = '".$dados_dica_rapida["codigo"]."'"));

if($dados_dicas_rapidas_acesso["total"] < 10) {

if($dados_dicas_rapidas_acesso["total"] == 0) {
mysql_query("INSERT INTO dicas_rapidas_acessos (codigo_stm,codigo_dica,total) VALUES (".$dados_stm["codigo"].",'".$dados_dica_rapida["codigo"]."','1')");
} else {
mysql_query("Update dicas_rapidas_acessos set total = total+1 where codigo = '".$dados_dicas_rapidas_acesso["codigo"]."'");
}

$dica_rapida = str_replace("PAINEL","http://".$_SERVER['HTTP_HOST']."",$dados_dica_rapida["mensagem"]);
$dica_rapida = str_replace("PORTA","".$dados_stm["porta"]."",$dica_rapida);
?>
<table width="844" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px; margin-bottom:10px; margin-left:0 auto; margin-right:0 auto; background-color: #C1E0FF; border: #006699 1px solid">
<tr>
            <td width="30" height="25" align="center" scope="col"><img src="admin/img/icones/ajuda.gif" width="16" height="16" /></td>
            <td width="814" align="left" class="texto_padrao_destaque" scope="col"><?php echo $dica_rapida; ?></td>
    </tr>
</table>
<?php
}
}
?>
<?php
//CALCULA ESPA�O USADO NO STREAMING PELO CLIENTE
require_once("admin/inc/classe.ssh.php");
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
$espaco_usado = $ssh->executar("du -csh /home/streaming/$dados_stm[porta] | awk {'print $1'}");
if (stristr($espaco_usado,"M")) {
	$quota1 = explode("M",$espaco_usado);
	$quota = "$quota1[0]";
}
if (stristr($espaco_usado,"G")) {
	$quota1 = explode("G",$espaco_usado);
	$quota = "$quota1[0]";
	$quota = $quota * 1024;
}
?>
<?php
						
//AQUI PEGA O ESPA�O USADO DO STREAMING E DIVIDE PELO ESPA�O TOTAL E MUTIPLICA POR 100.
$espaco_total = $dados_stm[espaco];
$resultado = ($quota / $espaco_total) * 100;

?>


<?php if($dados_stm["status"] == 1) { ?>
  <table width="850" border="0" cellpadding="0" cellspacing="0" align="center">
    <tr>
      <td width="425" height="50" align="center" valign="top" style="padding-left:10px; padding-right:10px">
		<div id="quadro">
       	  <div id="quadro-topo"> <strong>Informa&ccedil;&otilde;es do Streaming</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
					  <table width="400" border="0" cellpadding="0" cellspacing="0">
   						<tr>
						  <td width="100" height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Porta</td>
      							<td width="310" align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $dados_stm["porta"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Porta DJ</td>
      							<td align="left" class="texto_padrao"><?php echo $dados_stm["porta_dj"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;IP</td>
      							<td align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $dados_servidor["ip"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Configura&ccedil;&atilde;o</td>
      							<td align="left" class="texto_padrao"><?php echo $dados_stm["ouvintes"]; ?> <span class="texto_padrao_pequeno">ouvintes</span> / <?php echo $dados_stm["bitrate"]; ?>&nbsp;<span class="texto_padrao_pequeno">Kbps</span> / <?php echo tamanho($dados_stm["espaco"]); ?></td>
   						</tr>
                            <tr>
      							<td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;ShoutCast</td>
   							  <td align="left" bgcolor="#F8F8F8" class="texto_padrao"><a href="javascript:abrir_janela('http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>',720,500);">http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?></a></td>
   						</tr>
                            <?php if($dados_stm["aacplus"] == 'sim') { ?>
                            <tr>
      							<td height="25" align="left" class="texto_padrao_destaque">&nbsp;RTMP(AAC+)</td>
      							<td align="left" class="texto_padrao">rtmp://<?php echo $dados_servidor_aacplus["ip"]; ?>:1935/<?php echo $dados_stm["porta"]; ?></td>
    						</tr>
                            <?php } else { ?>
                        <?php } ?>
					  </table>
		  </div>
      </div>      </td>
      <td width="425" align="center" valign="top" style="padding-left:10px; padding-right:10px">
<div id="quadro">
            	<div id="quadro-topo"> <strong>Informa&ccedil;&otilde;es de Uso</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
					  <table width="400" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="100" height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Status</td>
      				<td width="310" height="25" align="left" bgcolor="#F8F8F8" scope="col" class="texto_padrao"><span id="<?php echo $dados_stm["porta"]; ?>" style="cursor:pointer" onclick="status_streaming('<?php echo $dados_stm["porta"]; ?>')"></span></td>
   						</tr>
    						<tr>
                              <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Ouvintes</td>
    						  <td align="left" class="texto_padrao"><span id="estatistica_uso_plano_ouvintes" style="cursor:pointer" onclick="estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes','sim','nao');"></span></td>
  						  </tr>
    						<tr>
                              <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Espa&ccedil;o FTP</td>
                              <td align="left" bgcolor="#F8F8F8" class="texto_padrao"><span id="estatistica_uso_plano_ftp" style="cursor:pointer" onclick="estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','sim','nao');"></span></td>
  						  </tr>
    						<tr>
                              <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Playlists</td>
    						  <td align="left" class="texto_padrao"><?php echo $total_playlists; ?></td>
  						  </tr>
    						<tr>
    						  <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Formato</td>
    						  <td align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $formato; ?></td>
  						  </tr>
                          <tr>
    						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;M�sica Atual</td>
    						  <td align="left" class="texto_padrao"><?php echo (strlen($info["musica"]) > 48) ? substr($info["musica"], 0, 43)."..." : $info["musica"]; ?></td>
  						  </tr>
					  </table>
		  </div>
      </div>      </td>
    </tr>
    <tr>
      <td height="5" colspan="2" align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td width="425" height="50" align="center" valign="top" style="padding-left:10px; padding-right:10px">
      <div id="quadro">
            	<div id="quadro-topo"> <strong>Gerenciamento do Streaming</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
					  <table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="ligar_streaming('<?php echo $porta_code;?>');">
                <img src="admin/img/icones/img-icone-play.png" alt="Ligar" width="48" height="48" />
                <br />
			    Ligar                </td>
    				<td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="desligar_streaming('<?php echo $porta_code;?>');">
                         <img src="admin/img/icones/img-icone-stop.png" alt="Desligar" width="48" height="48" />
                          <br />
   						  Desligar</td>
    				<td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="desligar_streaming('<?php echo $porta_code;?>');ligar_streaming('<?php echo $porta_code;?>');">
                            <img src="admin/img/icones/img-icone-recarregar.png" alt="Reiniciar" width="48" height="48" />
                            <br />
   						    Reiniciar</td>
			  </tr>
    				<tr>
      					<td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="carregar_configuracoes_streaming('<?php echo $porta_code;?>');">
                                <img src="admin/img/icones/img-icone-configuracoes.png" alt="Configura&ccedil;&otilde;es" width="48" height="48" />
                                <br />
   							    Configura&ccedil;&otilde;es</td>
    					<td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="carregar_configuracoes_relay('<?php echo $porta_code;?>');"><img src="admin/img/icones/img-icone-relay.png" alt="Configurar Relay" width="48" height="48" /> <br />
    					  Configurar Relay</td>
    					<td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="carregar_lista_players_streaming('<?php echo $porta_code;?>');"><img src="admin/img/icones/img-icone-player.png" alt="Players" width="48" height="48" /> <br />
    					  Players</td>
    				</tr>
    					<tr>
    					  <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="abrir_janela('/ouvintes-conectados/<?php echo $porta_code;?>',850,600);"><img src="admin/img/icones/img-icone-ouvintes.png" alt="Ouvintes Conectados" width="48" height="48" /> <br />
    					    Ouvintes Conectados</td>
      						<td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="carregar_estatisticas_streaming('<?php echo $porta_code;?>');"><img src="admin/img/icones/img-icone-estatistica.png" alt="Estat&iacute;sticas" width="48" height="48" /> <br />
   						      Estat&iacute;sticas</td>
    						 <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="kick_streaming('<?php echo $porta_code;?>');"><img src="admin/img/icones/img-icone-desconectar-source.png" alt="Desconectar Source" width="48" height="48" /> <br />
    						   Desconectar Source</td>
    					</tr>
    					<tr>
    					  <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="ativar_protecao('<?php echo $porta_code;?>');"><img src="admin/img/icones/img-icone-cadeado.png" alt="Ativa&ccedil;&atilde;o Prote&ccedil;&atilde;o" width="48" height="48" /> <br />
    					    Ativar/Desat. Prote&ccedil;&atilde;o</td>
    					  <td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="window.location = '/streaming-api';"><img src="admin/img/icones/img-icone-api.png" alt="API" width="48" height="48" /> <br />
    					    API</td>
    					  <td height="70" align="center" class="texto_padrao_destaque">&nbsp;</td>
    					</tr>
					  </table>
		  </div>
      </div>      </td>
      <td width="425" align="center" valign="top" style="padding-left:10px; padding-right:10px">
      <div id="quadro">
            	<div id="quadro-topo"> <strong>Gerenciamento do AutoDJ</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
            		  <table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="carregar_playlists('<?php echo $porta_code;?>');">
                          <img src="admin/img/icones/img-icone-play.png" alt="Ligar" width="48" height="48" />
                          <br />
                            Ligar                            </td>
                          <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="desligar_autodj('<?php echo $porta_code;?>');">
                          <img src="admin/img/icones/img-icone-stop.png" alt="Desligar" width="48" height="48" />
                          <br />
                            Desligar                            </td>
                          <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="recarregar_playlist('<?php echo $porta_code;?>');">
                          <img src="admin/img/icones/img-icone-recarregar.png" alt="Recarregar Playlist" width="48" height="48" />
                          <br />
                            Recarregar Playlist                            </td>
                        </tr>
                        <tr>
                          <td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="pular_musica('<?php echo $porta_code;?>');">
                          <img src="admin/img/icones/img-icone-pular-musica.png" alt="Pular M&uacute;sica" width="48" height="48" />
                          <br />
                          Pular M&uacute;sica                          </td>
                          <td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="window.location = '/gerenciar-musicas';">
                          <img src="admin/img/icones/img-icone-musicas.png" alt="Gerenciar M&uacute;sicas" width="48" height="48" />
                          <br />
                          Gerenciar M&uacute;sicas                          </td>
                          <td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="window.location = '/gerenciar-playlists';">
                          <img src="admin/img/icones/img-icone-playlists.png" alt="Gerenciar Playlists" width="48" height="48" />
                          <br />
                          Gerenciar Playlists</td>
                        </tr>
                        <tr>
                          <td width="133" height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="window.location = '/gerenciar-djs';"><img src="admin/img/icones/img-icone-dj.png" alt="Gerenciar DJs" width="48" height="48" />
                          <br />
                          Gerenciar DJs                          </td>
                          <td height="70" align="center" class="texto_padrao_destaque" style="cursor:pointer" onclick="window.location = '/gerenciar-agendamento-playlists';"><img src="admin/img/icones/img-icone-agendamento.png" alt="Gerenciar DJs" width="48" height="48" /><br />
                          Agendar Playlist </td>







                        </tr>
                      </table>
   		  </div>
      </div>      </td>
    </tr>
    <tr>
      <td height="5" colspan="2" align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td height="50" colspan="2" align="center" valign="top" style="padding-left:10px; padding-right:10px">
      <div id="quadro">
            	<div id="quadro-topo"> <strong>Atualiza&ccedil;&otilde;es do Painel de Controle &amp; Streaming</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td height="25" class="texto_padrao">Sem informa&ccedil;&otilde;es.</td>
    </tr>
</table>
    </div>
      </div>
      </td>
    </tr>
  </table>
  <?php } else { ?>
  <table width="850" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; background-color:#FFFF66; border:#DFDF00 4px dashed">
  <tr>
        <td width="30" height="50" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="820" align="left" class="texto_status_erro" scope="col">Streaming <?php echo $dados_stm["porta"];?> bloqueado! Contate nosso atendimento para maiores informa&ccedil;&otilde;es!</td>
    </tr>
    </table>
  <?php } ?>
  <?php } else { ?>
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; background-color:#FFFF66; border:#DFDF00 4px dashed">
  <tr>
        <td width="30" height="30" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="820" align="left" class="texto_status_erro_pequeno" scope="col"><?php echo $dados_servidor["mensagem_manutencao"];?></td>
    </tr>
    </table>
  <?php } ?>
  <br />
  <br />
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
status_streaming('<?php echo $dados_stm["porta"]; ?>');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes','sim','nao');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','sim','nao');
</script>
</body>
</html>