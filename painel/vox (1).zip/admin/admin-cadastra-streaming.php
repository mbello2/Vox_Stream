<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 600);

// Inclus�o de classes
require_once("inc/classe.ssh.php");

// Prote��o contra acesso direto
if(!preg_match("/".str_replace("http://","",str_replace("www.","",$_SERVER['HTTP_HOST']))."/i",$_SERVER['HTTP_REFERER'])) {
die("<span class='texto_status_erro'>Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
}

if(empty($_POST["porta"]) or empty($_POST["porta_dj"]) or empty($_POST["ouvintes"]) or empty($_POST["bitrate"]) or empty($_POST["espaco"]) or empty($_POST["senha"]) or empty($_POST["identificacao"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

// Verifica se a porta j� esta em uso
$total_streamings = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta = '".$_POST["porta"]."'"));

if($total_streamings > 0) {
die ("<script> alert(\"A porta ".$_POST["porta"]." j� esta em uso\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = '/admin/admin-cadastrar-streaming'; </script>");
}

$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));

if($_POST["aacplus"] == 'sim' && $_POST["servidor_aacplus"] == 0) {
die ("<script> alert(\"Voc� n�o selecionou o servidor AAC+\\n \\nPor favor volte e selecione.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

mysql_query("INSERT INTO streamings (codigo_servidor,codigo_servidor_aacplus,porta,porta_dj,ouvintes,bitrate,bitrate_autodj,encoder,espaco,senha,ftp_dir,identificacao,aacplus,data_cadastro) VALUES ('".$_POST["servidor"]."','".$_POST["servidor_aacplus"]."','".$_POST["porta"]."','".$_POST["porta_dj"]."','".$_POST["ouvintes"]."','".$_POST["bitrate"]."','".$_POST["bitrate"]."','".$_POST["encoder"]."','".$_POST["espaco"]."','".$_POST["senha"]."','/home/streaming/".$_POST["porta"]."','".$_POST["identificacao"]."','".$_POST["aacplus"]."',NOW())") or die("Erro ao processar query.<br>Mensagem do servidor: ".mysql_error());
$codigo_streaming = mysql_insert_id();

// Ativa o relay no servidor aacplus
if($_POST["aacplus"] == 'sim') {

$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$_POST["servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$_POST["servidor_aacplus"]."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

$ssh->executar("/usr/local/WowzaMediaServer/ativar-aacplus ".$_POST["porta"]." ".$dados_servidor["ip"]." ".$_POST["ouvintes"]."");
}

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Streaming ".$_POST["porta"]." cadastrado com sucesso.","ok");

header("Location: /admin/admin-streamings/resultado/".$_POST["porta"]."");
?>