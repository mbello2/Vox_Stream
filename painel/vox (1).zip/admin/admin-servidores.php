<?php
require_once("inc/protecao-admin.php");
require_once("inc/classe.ssh.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax.js"></script>
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo" style="background:url(/admin/img/img-logo-painel.gif) no-repeat center;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li>&nbsp;&nbsp;&nbsp;</li>
        <li><a href="/admin/admin-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/admin-streamings" class="texto_menu">Streamings</a></li>
  		<li><em></em><a href="/admin/admin-cadastrar-revenda" class="texto_menu">Cadastrar Revenda</a></li>
  		<li><em></em><a href="/admin/admin-revendas" class="texto_menu">Revendas</a></li>
        <li><em></em><a href="/admin/admin-cadastrar-servidor" class="texto_menu">Cadastrar Servidor</a></li>
        <li><em></em><a href="/admin/admin-servidores" class="texto_menu">Servidores</a></li>
        <li><em></em><a href="/admin/admin-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="100" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Nome</td>
      <td width="120" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;IP Conex�o</td>
      <td width="80" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Porta SSH</td>
      <td width="90" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Streamings</td>
      <td width="70" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Load</td>
      <td width="110" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Tr�fego do M�s</td>
      <td width="200" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;A��es</td>
    </tr>
<?php
$pagina_atual = query_string('2');

$sql = mysql_query("SELECT * FROM servidores");
$lpp = 100; // total de registros por p&aacute;gina
$total = mysql_num_rows($sql);
$paginas = ceil($total / $lpp); 
if(!isset($pagina_atual)) { $pagina_atual = 0; }
$inicio = $pagina_atual * $lpp;
$sql = mysql_query("SELECT * FROM servidores ORDER by codigo ASC LIMIT $inicio, $lpp");

while ($dados_servidor = mysql_fetch_array($sql)) {

$total_stm = mysql_num_rows(mysql_query("SELECT * FROM streamings where codigo_servidor = '".$dados_servidor["codigo"]."'"));

if($dados_servidor["status"] == "on") {

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));

$total_trafego = $ssh->executar("date;vnstat -m | grep ".date("M")." | awk {'print $6\" \"$7'}");
$load = $ssh->executar("cat /proc/loadavg | awk {'print $1'}");

}

$servidor_code = code_decode($dados_servidor["codigo"],"E");

if($load > 400.0) {
$cor_status_load = '#FF5357';
} else {
$cor_status_load = '#FFFFFF';
}

echo "<tr style='background-color:".$cor_status_load.";'>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_servidor["nome"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_servidor["ip"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_servidor["porta_ssh"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$total_stm."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$load."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".str_replace("i","",ucwords(strtolower($total_trafego)))."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>
<select style='width:100%' id='".$servidor_code."' onchange='executar_acao_servidor(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <optgroup label='Streamings'>
  <option value='ligar'>Ligar Streamings</option>
  <option value='ligar-autodjs'>Ligar AutoDJs</option>
  <option value='desligar'>Desligar Streamings</option>
  <option value='listar-streamings'>Listar Streamings</option>
  <option value='alterar-servidor'>Alterar Servidor</option>
  <option value='exportar-lista-streamings'>Exportar Lista de Streamings</option>
  </optgroup>
  <optgroup label='Administra��o'>
  <option value='configurar'>Alterar Configura��es</option>
  <option value='remover'>Remover</option>
  </optgroup>
</select>
</td>
</tr>";

}
?>
  </table>
  <table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style=" border:#D5D5D5 1px solid;">
    <tr>
      <td height="20" align="center"><?php
$total_registros = mysql_num_rows(mysql_query("SELECT * FROM servidores"));

if($total_registros == 0) {
echo "<span class=\"texto_padrao_destaque\">Nenhum servidor encontrado.</span>";
} else {

$pagina_atual = query_string('2');
	
	for($i = 0; $i < $paginas; $i++) {
      $linksp = $i + 1;
      if ($pagina_atual == $i) {
              echo " <span class=\"texto_padrao_destaque\" title=\"P&aacute;gina $linksp\">$linksp</span>";
      } else {
              $url = "/admin/admin-servidores/$i";
              echo " <a href=\"$url\" class=\"texto_padrao\" title=\"Ir para p&aacute;gina $linksp\">$linksp</a></span>";
      }
	}

}
?>      </td>
    </tr>
  </table>
</div>

<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';"></div>
<div id="log-sistema">
<table width="600" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td scope="col" style="border-bottom: #D5D5D5 1px solid">
        <table width="600" height="20" border="0" align="left" cellpadding="0" cellspacing="0">
          <tr style="background:url(img/img-fundo-titulo-tabela.png) repeat-x;">
            <td width="570" height="23" align="left" class="texto_padrao_destaque" scope="col">&nbsp;<span id="log-sistema-titulo"></span></td>
            <td width="30" align="center" scope="col" style="cursor:pointer"><img src="img/icones/fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" title="Fechar janela" /></td>
          </tr>
        </table>
        </td>
    </tr>
      <tr>
        <td class="texto_padrao" align="center"><div id="log-sistema-conteudo"></div></td>
    </tr>
</table>
</div>
<!-- Fim div log do sistema -->
</body>
</html>
