<?php

if($_SERVER['HTTP_REFERER']) {

if(!preg_match('/login/i',$_SERVER['HTTP_REFERER'])) {
$url = $_SERVER['HTTP_REFERER'];
} else {
$url = "";
}

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form method="post" action="/admin/login-autentica" style="margin:0px; padding:0px;">
  <table width="550" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="margin-top:20%; border:#CCCCCC 1px solid;">
    <tr>
      <td width="326" rowspan="5" align="center" class="texto_titulo2">Gerenciamento de Streaming<br />
          <span class="texto_padrao_destaque">Painel Administrativo</span></td>
      <td width="224" height="25" align="left" bgcolor="#FFFFFF" class="texto_padrao_destaque" scope="col">E-mail</td>
    </tr>
    <tr>
      <td height="25" align="left" bgcolor="#FFFFFF" class="texto_padrao2" scope="col"><input name="email" type="text" id="email" size="30" />
          <input type="hidden" name="url" id="url" value="<?php echo $url; ?>" /></td>
    </tr>
    <tr>
      <td height="25" align="left" bgcolor="#FFFFFF" class="texto_padrao_destaque" scope="col">Senha</td>
    </tr>
    <tr>
      <td height="25" align="left" bgcolor="#FFFFFF" class="texto_padrao2"><input name="senha" type="password" id="senha" size="30" />
      </td>
    </tr>
    <tr>
      <td height="40" align="left" bgcolor="#FFFFFF"><input name="submit" type="submit" class="botao" style="width:100px" value="Acessar" />      </td>
    </tr>
    <tr>
      <td height="0" colspan="2"><?php echo $_SESSION[status_login]; unset($_SESSION[status_login]); ?></td>
    </tr>
  </table>
</form>
</body>
</html>
