<?php
require_once("inc/protecao-revenda.php");

$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_SESSION["code_user_logged"]."'"));

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax.js"></script>
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
        <li style="width:250px">&nbsp;</li>
        <li><a href="/admin/revenda-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/revenda-streamings" class="texto_menu">Streamings</a></li>
        <li><em></em><a href="/admin/revenda-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="790" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>

<form style="padding:0; margin:0" onsubmit="buscar_streaming(document.getElementById('porta').value,'admin');return false;">
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px;">
    <tr>
      <td align="right" class="texto_padrao_destaque" scope="col"> 
        Porta
        <input name="porta" type="text" id="porta" />
        <input type="button" class="botao_padrao" value="Buscar" onclick="buscar_streaming(document.getElementById('porta').value,'revenda');" />
      </td>
     </tr>
  </table>
</form>
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="80" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Porta</td>
      <td width="80" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Porta DJ</td>
      <td width="100" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;IP Conex�o</td>
      <td width="170" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Configura��o</td>
      <td width="80" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;FTP</td>
      <td width="80" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Status</td>
      <td width="130" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Identifica��o</td>
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;A��es</td>
    </tr>
<?php
if(query_string('2') == 'resultado') {
$query = "SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."' AND porta = '".query_string('3')."'";
} else {
$query = "SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'";
}

$pagina_atual = query_string('2');

$sql = mysql_query("".$query."");
$lpp = 30; // total de registros por p&aacute;gina
$total = mysql_num_rows($sql);
$paginas = ceil($total / $lpp); 
if(!isset($pagina_atual)) { $pagina_atual = 0; }
$inicio = $pagina_atual * $lpp;
$sql = mysql_query("".$query." ORDER by porta ASC LIMIT $inicio, $lpp");

while ($dados_stm = mysql_fetch_array($sql)) {

$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

$identificacao = (strlen($dados_stm["identificacao"]) > 20) ? substr($dados_stm["identificacao"], 0, 20)."..." : $dados_stm["identificacao"];

$porcentagem_uso_espaco = ($dados_stm["espaco_usado"] == 0 || $dados_stm["espaco"] == 0) ? "0" : $dados_stm["espaco_usado"]*100/$dados_stm["espaco"];
$porcentagem_uso_espaco_barra = ($porcentagem_uso_espaco > 100) ? "100" : $porcentagem_uso_espaco;

$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";

$status_inicial = ($dados_stm["status"] != 1) ? "Bloqueado" : "<img src=/admin/img/spinner.gif' />";

$porta_code = code_decode($dados_stm["porta"],"E");

echo "<tr style='background-color:".$cor_status.";' onmouseover='this.style.backgroundColor=\"#F3F3F3\"' onmouseout='this.style.backgroundColor=\"".$cor_status."\"'>
<td height='25' align='left' scope='col' class='texto_padrao_pequeno'>&nbsp;".$dados_stm["porta"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao_pequeno'>&nbsp;".$dados_stm["porta_dj"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao_pequeno'>&nbsp;".$dados_servidor["ip"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao_pequeno'>&nbsp;".$dados_stm["ouvintes"]." ouvin. | ".$dados_stm["bitrate"]." Kbps | ".tamanho($dados_stm["espaco"])."</td>
<td height='25' align='center' scope='col' class='texto_padrao_pequeno'><div class='meter-wrap'><div class='meter-value' style='background-color: red; width: ".round($porcentagem_uso_espaco_barra)."%;'><div class='meter-text'>".round($porcentagem_uso_espaco)."%</div></div></div></td>
<td height='25' align='center' scope='col' class='texto_padrao_pequeno' style='cursor:pointer' onClick='status_streaming(\"".$dados_stm["porta"]."\")' id='".$dados_stm["porta"]."'>".$status_inicial."</td>
<td height='25' align='left' scope='col' class='texto_padrao_pequeno'>&nbsp;".$identificacao."</td>
<td height='25' align='left' scope='col'>";

/*
Legenda Status
1 -> ativo
2 -> bloqueado adminitra��o
3 -> bloqueado cliente
4 -> bloqueado abuso
*/

if($dados_stm["status"] == '1') {

echo "<select style='width:100%' id='".$porta_code."' onchange='executar_acao_streaming_revenda(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <optgroup label='Streaming'>
  <option value='ligar'>Ligar</option>
  <option value='desligar'>Desligar</option>
  <option value='configurar'>Alterar Configura��es</option>
  <option value='player'>Player</option>
  <option value='ouvintes-conectados'>Ouvintes Conectados</option>
  <option value='kick'>Desconectar DJ(source)</option>
  <option value='http://".$dados_servidor["ip"].":".$dados_stm["porta"]."'>Abrir Painel ShoutCast</option>
  <option value='ativar-protecao'>Ativar Prote��o contra Ataques</option>";
  if($dados_stm["aacplus"] == 'sim') {
  echo "<option value='sincronizar-aacplus'>Sincronizar AAC+</option>";
  }
echo"</optgroup>
  <optgroup label='AutoDJ'>
  <option value='ligar-autodj'>Ligar</option>
  <option value='pular-musica'>Pular M�sica Atual</option>
  <option value='recarregar-playlist'>Recarregar Playlist</option>
  <option value='desligar-autodj'>Desligar</option>
  </optgroup>
  <optgroup label='Administra��o'>
  <option value='bloquear'>Bloquear</option>
  <option value='desbloquear'>Desbloquear</option>
  <option value='remover'>Remover</option>
  </optgroup>
</select>";

} else if($dados_stm["status"] == '3') {

echo "<select style='width:100%' id='".$porta_code."' onchange='executar_acao_streaming_revenda(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <optgroup label='Administra��o'>
  <option value='desbloquear'>Desbloquear</option>
  <option value='remover'>Remover</option>
  </optgroup>
</select>";

} else {
echo "<select style='width:100%' disabled='disabled'>
  <option value='' selected='selected'>Streaming bloqueado</option>
</select>";
}

echo "</td>
</tr>";

// Adiciona na lista de checagem do status apenas se estiver ativo
if($dados_stm["status"] == 1) {
$array_streamings .= "".$dados_stm["porta"]."|";
}

}
?>
  </table>
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style="border:#D5D5D5 1px solid;">
    <tr>
      <td height="20" align="center"><?php
$total_registros = mysql_num_rows(mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'"));

if($total_registros == 0) {
echo "<span class=\"texto_padrao_destaque\">Nenhum streaming encontrado.</span>";
} else {

$pagina_atual = query_string('2');
	
	for($i = 0; $i < $paginas; $i++) {
      $linksp = $i + 1;
      if ($pagina_atual == $i) {
              echo " <span class=\"texto_padrao_destaque\" title=\"P&aacute;gina $linksp\">$linksp</span>";
      } else {
              $url = "/admin/revenda-streamings/$i";
              echo " <a href=\"$url\" class=\"texto_padrao\" title=\"Ir para p&aacute;gina $linksp\">$linksp</a></span>";
      }
	}

}
?>      </td>
    </tr>
  </table>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"><img src="/admin/img/ajax-loader.gif" /></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
checar_status_streamings('<?php echo $array_streamings; ?>');
</script>
</body>
</html>
