<?php
require_once("inc/protecao-revenda.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".code_decode(query_string('2'),"D")."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));

// Verifica se o streaming � do cliente
if($dados_stm["codigo_cliente"] != $_SESSION["code_user_logged"]) {

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Oops! O streaming ".$dados_stm["porta"]." n�o pertence a voc�.","erro");

header("Location: /admin/revenda-streamings");
exit;
}

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li style="width:250px">&nbsp;</li>
        <li><a href="/admin/revenda-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/revenda-streamings" class="texto_menu">Streamings</a></li>
        <li><em></em><a href="/admin/revenda-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
  <form method="post" action="/admin/revenda-configura-streaming" style="padding:0px; margin:0px">
    <table width="500" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td width="140" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Porta</td>
        <td width="360" align="left" class="texto_padrao_destaque"><input type="text" class="input" style="width:250px;" value="<?php echo $dados_stm["porta"]; ?>" disabled="disabled" /></td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">M&aacute;ximo Ouvintes</td>
        <td align="left"><input name="ouvintes" type="text" class="input" id="ouvintes" style="width:250px;" value="<?php echo $dados_stm["ouvintes"]; ?>" /></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">M&aacute;ximo Bitrate</td>
        <td align="left">
        <select name="bitrate" class="input" id="bitrate" style="width:255px;">
          <?php
		   foreach(array("24","32","48","64","96","128") as $bitrate){
		   
		   if($bitrate <= $dados_revenda["bitrate"]) {
		   
		   if($bitrate == $dados_revenda["bitrate"]) {
		   
		   if($bitrate == $dados_stm["bitrate"]) {
		    echo "<option value=\"".$bitrate."\" selected=\"selected\">".$bitrate." Kbps(m�ximo)</option>";
		   } else {
		    echo "<option value=\"".$bitrate."\">".$bitrate." Kbps(m�ximo)</option>";
		   }
		   
		   } else {
		   
		   if($bitrate == $dados_stm["bitrate"]) {
		    echo "<option value=\"".$bitrate."\" selected=\"selected\">".$bitrate." Kbps</option>";
		   } else {
		    echo "<option value=\"".$bitrate."\">".$bitrate." Kbps</option>";
		   }
		   
		   }
		   
		   }
		   
		   }
		  ?>
         </select>         </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Espa�o AutoDJ</td>
        <td align="left" class="texto_padrao_pequeno">
        <input name="espaco" type="text" class="input" id="espaco" style="width:250px;" value="<?php echo $dados_stm["espaco"]; ?>" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('O valor deve ser em megabytes ex.: 1GB = 1000');" style="cursor:pointer" />        </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Senha</td>
        <td align="left">
        <input name="senha" type="text" class="input" id="senha" style="width:250px;" value="<?php echo $dados_stm["senha"]; ?>" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Use apenas lestras e/ou n�meros.\n\nCaracteres como !@#$%�& n�o ir�o funcionar corretamente.');" style="cursor:pointer" />        </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Identifica��o</td>
        <td align="left"><input name="identificacao" type="text" class="input" id="identificacao" style="width:250px;" value="<?php echo $dados_stm["identificacao"]; ?>" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Um nome personalizado para facilitar a indentifica��o deste streaming no painel de controle.\n\nN�o tem rela��o com o funcionamento do ');" style="cursor:pointer" />        </td>
      </tr>
      <?php if($dados_revenda["aacplus"] == 'sim') { ?>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Ativar AAC+ RTMP</td>
        <td align="left" class="texto_padrao">
          <input type="radio" name="aacplus" id="aacplus" value="sim"<?php if($dados_stm["aacplus"] == "sim") { echo ' checked="checked"'; } ?> onclick="configurar_aacplus_revenda(this.value);" />&nbsp;Sim
          <input type="radio" name="aacplus" id="aacplus" value="nao"<?php if($dados_stm["aacplus"] == "nao") { echo ' checked="checked"'; } ?> onclick="configurar_aacplus_revenda(this.value);" />&nbsp;N�o        </td>
      </tr>
      <?php } else { ?>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Ativar AAC+ RTMP</td>
        <td align="left" class="texto_log_sistema_erro">Seu plano n�o possui o AAC+ com RTMP somente o AAC+!
        <input name="aacplus" id="aacplus" type="hidden" value="nao" />
        </td>
      </tr>
      <?php } ?>
      <tr>
        <td height="40">
          <input name="porta" type="hidden" id="porta" value="<?php echo $dados_stm["porta"]; ?>" />        </td>
        <td align="left">
          <input type="submit" class="botao" value="Alterar Dados" />
          <input type="button" class="botao" value="Cancelar" onclick="window.location = '/admin/revenda-streamings';" />        </td>
      </tr>
    </table>
  </form>
</div>

</body>
</html>
