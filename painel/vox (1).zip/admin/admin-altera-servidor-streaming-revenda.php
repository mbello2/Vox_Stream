<?php
// Prote��o Login
require_once("inc/protecao-admin.php");


if(empty($_POST["codigo_cliente"]) or empty($_POST["servidor_novo"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

foreach($_POST["servidor_novo"] as $porta => $servidor){


$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$servidor."'"));
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings WHERE porta = '".$porta."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_POST["codigo_cliente"]."'"));

mysql_query("UPDATE streamings set codigo_servidor = '".$dados_servidor["codigo"]."' WHERE porta = '".$dados_stm["porta"]."'");

}

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Servidor dos streamings da revenda ".$dados_revenda["nome"]." alterado com sucesso para ".$dados_servidor["nome"]."","ok");

header("Location: /admin/admin-streamings/resultado-revenda/".code_decode($_POST["codigo_cliente"],"E")."");
?>