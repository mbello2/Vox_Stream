<?php
require_once("inc/protecao-revenda.php");


$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_SESSION["code_user_logged"]."'"));

if($_POST["alterar_dados"]) {

mysql_query("Update revendas set senha = '".$_POST["senha"]."', url_logo = '".$_POST["url_logo"]."' where codigo = '".$dados_revenda["codigo"]."'");

// Loga a a��o executada
mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('configuracoes_revenda',NOW(),'".$_SERVER['REMOTE_ADDR']."','Altera��o nas configura��es da revenda ".$dados_revenda["nome"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Suas configura��es foram alteradas com sucesso.","ok");

}

$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_SESSION["code_user_logged"]."'"));

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li style="width:250px">&nbsp;</li>
        <li><a href="/admin/revenda-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/revenda-streamings" class="texto_menu">Streamings</a></li>
        <li><em></em><a href="/admin/revenda-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <form method="post" action="/admin/revenda-configuracoes" style="padding:0px; margin:0px">
    <table width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td width="150" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">URL Logo</td>
        <td width="450" align="left" class="texto_padrao_pequeno"><input name="url_logo" type="text" class="input" id="url_logo" style="width:250px;" value="<?php echo $dados_revenda["url_logo"]; ?>" />          
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Altura m�xima: 100px\nTipos de Imagem: JPG|GIF|PNG');" style="cursor:pointer" />          </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Chave API</td>
        <td align="left">
        <input type="text" class="input" style="width:250px;" readonly="readonly" onclick="this.select();" value="<?php echo $dados_revenda["chave_api"]; ?>" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Use esta chave para integrar seu painel de controle ao WHMCS e outros sistemas(em breve)');" style="cursor:pointer" />        </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Senha Painel de Controle</td>
        <td align="left">
        <input name="senha" type="password" class="input" id="senha" style="width:250px;" value="<?php echo $dados_revenda["senha"]; ?>" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Senha de acesso ao seu painel.');" style="cursor:pointer" />        </td>
      </tr>
      <tr>
        <td height="40"><input name="alterar_dados" type="hidden" id="alterar_dados" value="sim" /></td>
        <td align="left">
          <input type="submit" class="botao" value="Alterar Dados" />
          <input type="button" class="botao" value="Cancelar" onclick="window.location = '/admin/revenda-streamings';" /></td>
      </tr>
    </table>
  </form>
</div>

</body>
</html>
