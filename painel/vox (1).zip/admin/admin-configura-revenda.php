<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 600);

// Prote��o Login
require_once("inc/protecao-admin.php");
require_once("inc/classe.mail.php");

// Inclus�o de classes
require_once("inc/classe.ssh.php");

// Prote��o contra acesso direto
if(!preg_match("/".str_replace("http://","",str_replace("www.","",$_SERVER['HTTP_HOST']))."/i",$_SERVER['HTTP_REFERER'])) {
die("<span class='texto_status_erro'>Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
}

if(empty($_POST["codigo_revenda"]) or empty($_POST["nome"]) or empty($_POST["email"]) or empty($_POST["senha"]) or empty($_POST["streamings"]) or empty($_POST["ouvintes"]) or empty($_POST["bitrate"]) or empty($_POST["espaco"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

$dados_revenda_atual = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_POST["codigo_revenda"]."'"));

mysql_query("Update revendas set nome = '".$_POST["nome"]."', email = '".$_POST["email"]."', senha = '".$_POST["senha"]."', streamings = '".$_POST["streamings"]."', ouvintes = '".$_POST["ouvintes"]."', bitrate = '".$_POST["bitrate"]."', espaco = '".$_POST["espaco"]."', aacplus = '".$_POST["aacplus"]."' where codigo = '".$_POST["codigo_revenda"]."'");

if($_POST["aacplus"] == 'nao' && $dados_revenda_atual["aacplus"] == 'sim') {

$sql_stm = mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda_atual["codigo"]."'");
while ($dados_stm = mysql_fetch_array($sql_stm)) {

$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

$ssh->executar("/usr/local/WowzaMediaServer/desativar-aacplus ".$dados_stm["porta"]."");

mysql_query("Update streamings set aacplus = 'nao' where codigo = '".$dados_stm["codigo"]."'");

}

}

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Configura��es da revenda ".$_POST["nome"]." alteradas com sucesso.","ok");

header("Location: /admin/admin-revendas");
?>