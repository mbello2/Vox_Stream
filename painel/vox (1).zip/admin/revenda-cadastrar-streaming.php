<?php
require_once("inc/protecao-revenda.php");

$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_SESSION["code_user_logged"]."'"));

// Estat�sticas
$total_streamings_revenda = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
$ouvintes_revenda = mysql_fetch_array(mysql_query("SELECT SUM(ouvintes) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
$espaco_revenda = mysql_fetch_array(mysql_query("SELECT SUM(espaco) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));

$total_streamings_disponivel = $dados_revenda["streamings"]-$total_streamings_revenda;
$total_ouvintes_disponivel = $dados_revenda["ouvintes"]-$ouvintes_revenda["total"];
$total_espaco_disponivel = $dados_revenda["espaco"]-$espaco_revenda["total"];

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li style="width:250px">&nbsp;</li>
        <li><a href="/admin/revenda-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/revenda-streamings" class="texto_menu">Streamings</a></li>
        <li><em></em><a href="/admin/revenda-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php if($dados_revenda["status"] == '1') { ?>
  <form method="post" action="/admin/revenda-cadastra-streaming" style="padding:0px; margin:0px">
    <table width="530" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td width="120" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Porta</td>
        <td width="410" align="left" class="texto_padrao_pequeno"><input type="text" class="input" style="width:250px;" value="A porta ser&aacute; gerada autom&aacute;ticamente." disabled="disabled" />&nbsp;<span class="texto_padrao_pequeno">Dispon�vel: <?php echo $total_streamings_disponivel; ?></span>        </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">M&aacute;ximo Ouvintes</td>
        <td align="left"><input name="ouvintes" type="text" class="input" id="ouvintes" style="width:250px;" value="" />&nbsp;<span class="texto_padrao_pequeno">Dispon�vel: <?php echo $total_ouvintes_disponivel; ?></span></td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">M&aacute;ximo Bitrate</td>
        <td align="left">
        <select name="bitrate" class="input" id="bitrate" style="width:255px;">
          <option value="" style="font-size:13px; font-weight:bold; background-color:#CCCCCC;">Selecione uma op&ccedil;&atilde;o</option>
          <?php
		   foreach(array("24","32","48","64","96","128") as $bitrate){
		   
		   if($bitrate <= $dados_revenda["bitrate"]) {
		   
		   if($bitrate == $dados_revenda["bitrate"]) {
		   echo "<option value=\"".$bitrate."\">".$bitrate." Kbps(m�ximo)</option>\n";
		   } else {
		   echo "<option value=\"".$bitrate."\">".$bitrate." Kbps</option>\n";
		   }

		   }
		    
		   }
		  ?>
         </select>
        </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Espa�o AutoDJ</td>
        <td align="left" class="texto_padrao_pequeno"><input name="espaco" type="text" class="input" id="espaco" style="width:250px;" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('O valor deve ser em megabytes ex.: 1GB = 1000');" style="cursor:pointer" />
        &nbsp;<span class="texto_padrao_pequeno">Dispon�vel: <?php echo $total_espaco_disponivel; ?> Mb</span></td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Senha</td>
        <td align="left"><input name="senha" type="text" class="input" id="senha" style="width:250px;" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Use apenas lestras e/ou n�meros.\n\nCaracteres como !@#$%�& n�o ir�o funcionar corretamente.');" style="cursor:pointer" />
        </td>
      </tr>
      <tr>
        <td height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Identifica��o</td>
        <td align="left"><input name="identificacao" type="text" class="input" id="identificacao" style="width:250px;" />
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Um nome personalizado para facilitar a indentifica��o deste streaming no painel de controle.\n\nN�o tem rela��o com o funcionamento do ');" style="cursor:pointer" />
        </td>
      </tr>
      <?php if($dados_revenda["aacplus"] == 'sim') { ?>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Ativar AAC+ RTMP</td>
        <td align="left" class="texto_padrao">
          <input type="radio" name="aacplus" id="aacplus" value="sim" onclick="configurar_aacplus_revenda(this.value);" />&nbsp;Sim
          <input type="radio" name="aacplus" id="aacplus" value="nao" checked="checked" onclick="configurar_aacplus_revenda(this.value);" />&nbsp;N�o
        </td>
      </tr>
      <?php } else { ?>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Ativar AAC+ RTMP</td>
        <td align="left" class="texto_log_sistema_erro">Seu plano n�o possui o AAC+ com RTMP somente o AAC+!
        <input name="aacplus" id="aacplus" type="hidden" value="nao" />
        </td>
      </tr>
      <?php } ?>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input name="codigo" id="codigo" type="hidden" value="<?php echo $dados_revenda["codigo"]; ?>" />
          <input type="submit" class="botao" value="Cadastrar" />
          <input type="button" class="botao" value="Cancelar" onclick="window.location = '/admin/revenda-streamings';" /></td>
      </tr>
    </table>
     <table width="340" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:10px; margin-bottom:5px;">
          <tr>
            <td height="30" align="center" class="texto_padrao_destaque">Estat&iacute;stica de Uso do Plano</td>
          </tr>
    </table>
        <table width="340" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
        <tr>
          <td width="100" height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Streamings</td>
          <td width="240" align="left" class="texto_padrao" style="padding-left:5px;"><?php echo "".$total_streamings_revenda." / ".$dados_revenda["streamings"].""; ?></td>
        </tr>
        <tr>
          <td height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Ouvintes</td>
          <td align="left" class="texto_padrao" style="padding-left:5px;"><?php echo "".$ouvintes_revenda["total"]." / ".$dados_revenda["ouvintes"].""; ?></td>
        </tr>
        <tr>
          <td height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Espa&ccedil;o AutoDJ</td>
          <td align="left" class="texto_padrao" style="padding-left:5px;"><?php echo "".tamanho($espaco_revenda["total"])." / ".tamanho($dados_revenda["espaco"]).""; ?></td>
        </tr>
    </table>
  </form>
<?php } else { 
echo '<table width="790" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">
'.status_acao("Ooops! Sua conta esta bloqueada, voc� n�o pode cadastrar novos streamings. Contate nosso atendimento.","erro").'
</table>';

} ?>
</div>
</body>
</html>
