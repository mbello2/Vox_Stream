<?php
header("Content-Type: text/html;  charset=ISO-8859-1",true);

ini_set("memory_limit", "128M");
ini_set("max_execution_time", 600);

// Inclus�o de classes
require_once("inc/classe.ssh.php");
require_once("inc/classe.ftp.php");
require_once("inc/classe.mail.php");

// Fun��es gerais para uso com Ajax

$acao = query_string('2');

////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Streaming ////////////
////////////////////////////////////////////////////////

// Fun��o para ligar streaming
if($acao == "ligar_streaming") {
        

        $porta = code_decode(query_string('3'),"D");
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where status = 'on' AND codigo = '".$dados_stm["codigo_servidor"]."'"));
	
        $status_streaming = status_streaming($_SESSION["ftp_host"],$_SESSION["ftp_user"]);
	if($status_streaming == "desligado") {
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($_SESSION["ftp_host"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$config_streaming = array ("porta" => $_SESSION["ftp_user"], "ouvintes" => $dados_stm["ouvintes"], "senha" => $dados_stm["senha"], "relay" => sim, "relay_ip" => $dados_stm["relay_ip"], "relay_porta" => $dados_stm["relay_porta"], "bitrate" => $dados_stm["bitrate"], "shoutcast" => $dados_stm["shoutcast"]);
	
	$config_streaming = gerar_conf_streaming($config_streaming);
	
	$ssh->enviar_arquivo("../temp/".$config_streaming."","/home/streaming/configs/".$config_streaming."",0777);
	
	unlink("../temp/".$config_streaming."");
	
	$resultado = $ssh->executar("/home/streaming/shoutcast/".$dados_stm["shoutcast"]."/ligar_streaming /home/streaming/configs/".$config_streaming.";chmod -fR 777 /home/streaming;cd /home/streaming/configs;rm crossdomain.xml;wget http://184.95.53.54/temp/crossdomain.xml");
	
	$resultado = str_replace("\n","",$resultado);
	
	if(is_numeric($resultado)) {
	echo '<strong></strong></span>';
	$status_streaming = status_streaming($_SESSION["ftp_host"],$_SESSION["ftp_user"]);
	
	if($status_streaming == "ligado") {
	
	mysql_query("Update streamings set pid='".$resultado."' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$_SESSION["ftp_user"]."</strong> ligado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$_SESSION["ftp_user"]."</strong> ligado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	}
	
	} else {
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$_SESSION["ftp_user"]."</strong> ligado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	}
	
	} else {
        echo "<span class='texto_status_sucesso'>Streaming <strong>".$_SESSION["ftp_user"]."</strong> J� ligado,agora ligue o Auto DJ</span><br/><br/>";
	echo '<input type="button" class="botao" value="Ligar AutoDJ" onclick="carregar_playlists(\''.query_string('3').'\');" />';
	}
	
	exit();
}


// Fun��o para desligar streaming
if($acao == "desligar_streaming") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "ligado") {
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	
	// Atualiza a �ltima playlist tocada
	mysql_query("Update streamings set ultima_playlist = '0' where codigo = '".$dados_stm["codigo"]."'");
	}
	
	$resultado = $ssh->executar("/home/streaming/desligar_streaming ".$dados_stm["porta"]."");
	
	$resultado = str_replace("\n","",$resultado);
	
	if($resultado == "ok") {
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> desligado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel desligar o streaming <strong>".$dados_stm["porta"]."</strong><br>Log: Erro desconhecido.</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>".$resultado."</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel desligar o streaming <strong>".$dados_stm["porta"]."</strong><br>Log: O streaming n�o esta ligado.</span>";
	}
	
	exit();
}

// Fun��o para bloquear streaming
if($acao == "bloquear_streaming") {

	$porta = code_decode(query_string('3'),"D");
	
	if($porta == "" || $porta == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	$status = ($_SESSION["tipo_usuario_logado"] == "operador") ? 2 : 3;
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Bloqueia o streaming no servidor
	$ssh->executar("iptables -A INPUT -p tcp --dport ".$porta." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
	mysql_query("Update streamings set status ='".$status."' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> bloqueado com sucesso.<a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel bloquear o streaming <strong>".$dados_stm["porta"]."</strong><br>Log: Erro desconhecido.</span>";
	}
	
	}
	
	exit();
}

// Fun��o para desbloquear streaming
if($acao == "desbloquear_streaming") {

	$porta = code_decode(query_string('3'),"D");
	
	if($porta == "" || $porta == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Desbloqueia o streaming no servidor
	$resultado = $ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save");
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> desbloqueado com sucesso.</span><br /><br/><a href='javascript:window.location.reload()>[Atualizar]</a>";
	
	mysql_query("Update streamings set status = '1' where codigo = '".$dados_stm["codigo"]."'");
	
	}
	
	exit();
}

// Fun��o para remover streaming
if($acao == "remover_streaming") {

	$porta = code_decode(query_string('3'),"D");
	
	if($porta == "" || $porta == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {
	
	$checar_streaming = mysql_num_rows(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	
	if($checar_streaming == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Streaming ".$porta." n�o encontrado.</span>";
	
	exit();
	}
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "ligado") {
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	}

	$resultado = $ssh->executar("/home/streaming/desligar_streaming ".$dados_stm["porta"]."");
		
	$resultado = str_replace("\n","",$resultado);
	
	} else {
	$resultado = "ok";
	}
	
	if($resultado == "ok") {
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
	// Desbloqueia o streaming no servidor
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	$ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	$ssh->executar("rm -rf /home/streaming/".$dados_stm["porta"]." /home/streaming/configs/*".$dados_stm["porta"]."* /home/streaming/logs/*".$dados_stm["porta"]."* /home/streaming/playlists/".$dados_stm["porta"]."-*.pls;echo ok");
	
	mysql_query("Delete From streamings where codigo = '".$dados_stm["codigo"]."'");
	
	// Remove as estatisticas
	//mysql_query("Delete From estatisticas where codigo_stm = '".$dados_stm["codigo"]."'");
	//mysql_query("Delete From estatisticas_players where codigo_stm = '".$dados_stm["codigo"]."'");
	
	// Remove as playlists
	$query_playlists = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'");
	while ($dados_playlist = mysql_fetch_array($query_playlists)) {
	
	mysql_query("Delete From playlists where codigo = '".$dados_playlist["codigo"]."'");
	
	$query_playlists_musicas = mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'");
	while ($dados_playlist_musicas = mysql_fetch_array($query_playlists_musicas)) {
	mysql_query("Delete From playlists_musicas where codigo = '".$dados_playlist_musicas["codigo"]."'");
	}
	
	}
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> removido com sucesso.</span><br /><br/><a href='javascript:window.location.reload()'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o streaming <strong>".$dados_stm["porta"]."</strong><br>Log: Erro desconhecido.</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o streaming <strong>".$dados_stm["porta"]."</strong><br>Log: ".$resultado."</span>";
	}
	
	}
	
	exit();
}

// Fun��o para gerar o c�digo HTML do player
if($acao == "player_streaming") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

	echo '<br /><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/mediaplayer"><img src="http://'.$_SERVER['HTTP_HOST'].'/admin/img/img-player-mediaplayer.gif" width="25" height="25" border="0" title="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/mediaplayer" /></a>&nbsp;<a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/winamp"><img src="http://'.$_SERVER['HTTP_HOST'].'/admin/img/img-player-winamp.gif" title="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/winamp" width="25" height="25" border="0" /></a>&nbsp;<a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/realplayer"><img src="http://'.$_SERVER['HTTP_HOST'].'/admin/img/img-player-realplayer.gif" title="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/realplayer" width="25" height="25" border="0" /></a>&nbsp;<a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/quicktime"><img src="http://'.$_SERVER['HTTP_HOST'].'/admin/img/img-player-quicktime.gif" title="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/quicktime" width="25" height="25" border="0" /></a><br /><br /><embed height="17" width="260" flashvars="file=http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'/;type=mp3&volume=100&bufferlength=10&autostart=true" allowscriptaccess="always" quality="high" src="http://'.$_SERVER['HTTP_HOST'].'/player.swf" type="application/x-shockwave-flash"><br /><br /><textarea style="width:90%; height:15px;font-size:12px" readonly="readonly">C�digo do FlashPlayer:</textarea><textarea style="width:90%; height:50px;font-size:10px" readonly="readonly" onmouseover="this.select()"><embed height="17" width="260" flashvars="file=http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'/;type=mp3&volume=100&bufferlength=10&autostart=true" allowscriptaccess="always" quality="high" src="http://'.$_SERVER['HTTP_HOST'].'/player.swf" type="application/x-shockwave-flash"></textarea>';
	
	exit();
}

// Fun��o para verificar o status do streaming e autoDJ
if($acao == "status_streaming") {

	$porta = query_string('3');
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	$encoder = aacp;
	$status_conexao = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
        if($dados_stm["shoutcast"] == 'mp3') {
        $status_conexao_autodj = status_autodjv1($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"],$dados_stm["encoder"]);
        } else {
        }
        if($dados_stm["shoutcast"] == 'aacp') {
        $status_conexao_autodj = status_autodjv2($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"],$dados_stm["encoder"]);
        } else {
        }
	$status_conexao = ($status_conexao == "ligado") ? "ligado" : "desligado";
	$status_conexao = ($status_conexao_autodj == "ligado") ? "ligado-autodj" : $status_conexao;
	
	echo $status_conexao;
	
	exit();
	
}

// Fun��o para desconectar o source do streaming(kick)
if($acao == "kick_streaming") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "ligado") {
	
	$kick = curl_init();
	curl_setopt($kick, CURLOPT_URL, "http://".$dados_servidor["ip"].":".$dados_stm["porta"]."/admin.cgi?pass=".$dados_stm["senha"]."&mode=kicksrc");
	curl_setopt($kick, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($kick, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	$resultado = curl_exec($kick);
	curl_close($kick);
	
	if(preg_match('/redirect/i',$resultado)) {
	
	echo "<span class='texto_status_sucesso'>DJ(source) do streaming <strong>".$dados_stm["porta"]."</strong> desconectado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	
	} else {	
	echo "<span class='texto_status_erro'>N�o foi poss�vel desconectar o DJ(source) do streaming <strong>".$dados_stm["porta"]."</strong><br>Log: ".$resultado."</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel desconectar o DJ(source) do streaming <strong>".$dados_stm["porta"]."</strong><br>Log: O streaming n�o esta ligado.</span>";
	}
	
	exit();
	
}

// Fun��o para listar os streamings do servidor
if($acao == "listar_streamings_servidor") {
	
	$codigo_servidor = code_decode(query_string('3'),"D");
	
	$sql = mysql_query("SELECT * FROM streamings where codigo_servidor = '".$codigo_servidor."' ORDER by porta ASC");
	while ($dados_stm = mysql_fetch_array($sql)) {
	
	$streamings .= "".code_decode($dados_stm["porta"],"E")."|";
	
	}
	
	echo substr($streamings,0,-1);

	exit();
	
}

// Fun��o para listar os streamings do servidor
if($acao == "listar_streamings_autodj_servidor") {
	
	$codigo_servidor = code_decode(query_string('3'),"D");
	
	$sql = mysql_query("SELECT * FROM streamings where codigo_servidor = '".$codigo_servidor."' ORDER by porta ASC");
	while ($dados_stm = mysql_fetch_array($sql)) {
	
	$streamings .= "".code_decode($dados_stm["porta"],"E").",".$dados_stm["ultima_playlist"]."|";
	
	}
	
	echo substr($streamings,0,-1);

	exit();
	
}

// Fun��o para remover um multpoints
if($acao == "remover_multpoint") {

	

	$codigo = code_decode(query_string('3'),"D");
	
	$dados_multpoints = mysql_fetch_array(mysql_query("SELECT * FROM multpoints where codigo = '".$codigo."'"));

	mysql_query("Delete From multpoints where codigo = '".$dados_multpoints["codigo"]."'");
	
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>multpoints removido com sucesso.</span><br /><br /><a href='javascript:window.location.reload()' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o multpoints<br>Log: ".mysql_error()."</span>";
	
	}
	
	exit();

}


// Fun��o para carregar o formul�rio para altera��o das configura��es do relay do streaming
if($acao == "carregar_configuracoes_relay") {

	
	
	$porta = code_decode(query_string('3'),"D");
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	
	$relay  = ($dados_stm["relay"] == "sim") ? 'checked="checked"' : "";
	
	echo '<div id="quadro">
<div id="quadro-topo"><strong>Configura��es do Relay</strong></div>
 <div class="texto_medio" id="quadro-conteudo">
    <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px; background-color:#FFFF66; border:#DFDF00 1px solid">
  	 <table width="460" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:5px; margin-bottom:5px; background-color:#FFFF66; border:#DFDF00 1px solid">

                  <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/dica.png" width="16" height="16" />
                  <td width="430" align="left" class="texto_padrao_pequeno" scope="col">Para a fun��o relay funcionar desligue o streaming e ligue novamente!</td>
                </table>
                   <table width="430" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:5px; margin-bottom:5px; background-color:#FFFF66; border:#DFDF00 1px solid">
                  <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/dica.png" width="16" height="16" />
                  <td width="430" align="left" class="texto_padrao_pequeno" scope="col">Para desativar a fun��o relay basta retirar a <b>PORTA</b> e <b>IP</b> acima e clique em "<b>Alterar configura��es</b>" Ap�s,desligue e ligue o streaming novamente!</td>
    </table>
    <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">IP Streaming Remoto</td>
        <td align="left" class="texto_padrao_pequeno"><input name="relay_ip" type="text" class="input" id="relay_ip" style="width:250px;" value="'.$dados_stm["relay_ip"].'" />&nbsp;(Somente o IP sem http://)</td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Porta Streaming Remoto</td>
        <td align="left" class="texto_padrao_pequeno"><input name="relay_porta" type="text" class="input" id="relay_porta" style="width:250px;" value="'.$dados_stm["relay_porta"].'" />&nbsp;(Somente a Porta)</td>
      </tr>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
       <input name="relay" type="hidden" id="relay" value="sim" '.$relay.' />
      <input type="button" class="botao" value="Alterar Configura��es" onclick="alterar_configuracoes_relay(\''.query_string('3').'\');" />
      </td>
      </tr>
    </table>
  </div>
</div>';
	
}

// Fun��o para alterar as configura��es do relay
if($_POST["acao"] == "alterar_configuracoes_relay") {
	
	$porta = code_decode($_POST["porta"],"D");

	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	
	$relay_ip = str_replace("http://","",$_POST["relay_ip"]);
	$relay_ip = str_replace("www.","",$relay_ip);
	
	mysql_query("Update streamings set relay_ip = '".$_POST["relay_ip"]."', relay_porta = '".$_POST["relay_porta"]."' where codigo = '".$dados_stm["codigo"]."'");
	
	if(!mysql_error()) {	
	
	echo "<span class='texto_status_sucesso'>Configura��es alteradas com sucesso.<br />Voc� deve reiniciar o streaming para ter efeito.</span>";
	
	// Loga a a��o executada
    mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('alterar_configuracoes_relay',NOW(),'".$_SERVER['REMOTE_ADDR']."','Altera��o nas configura��es do relya do streaming ".$dados_stm["porta"]."')");
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel alterar as configura��es do relay.<br>Log: ".mysql_error()."</span>";
	}


}


////////////////////////////////////////////////////////
///////////// Fun��es Gerenciamento AutoDJ /////////////
////////////////////////////////////////////////////////


// Fun��o para carregar as playlists do streaming
if($acao == "carregar_playlists") {

	

	$porta = code_decode(query_string('3'),"D");
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
	$dados_ultima_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_stm["ultima_playlist"]."'"));
	$total_musicas_ultima_playlist = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_stm["ultima_playlist"]."'"));
	
	if($dados_stm["relay"] == "sim") {
	
	echo "<span class='texto_status_erro'>O AutoDJ n�o pode ser iniciado pois o relay esta ativado.</span><br />";
	echo "<span class='texto_status_erro_pequeno'>Para desativar clique em Configurar Relay no painel do </span>";
	
	exit();
	}
	
	if($total_playlists > 0) {
	
	echo '<span style="color: #FFFFFF;font-family: Geneva, Arial, Helvetica, sans-serif;font-size:20px;font-weight:bold;">Ligar AutoDJ '.$dados_stm["porta"].'</span><br />';
	echo '<span style="color: #FFFFFF;font-family: Geneva, Arial, Helvetica, sans-serif;font-size:11px;font-weight:bold;">(escolha as op��es desejadas, as �ltimas configura��es usadas j� est�o selecionadas)</span><br /><br />';
	echo '<select name="playlist" id="playlist" style="width:400px;">';
	echo '<optgroup label="�ltima Playlist Executada">';
	if($dados_stm["ultima_playlist"] > 0) {
	echo '<option value="'.$dados_stm["ultima_playlist"].'">'.$dados_ultima_playlist["nome"].' ('.$total_musicas_ultima_playlist.')</option>';
	}
	echo '</optgroup>';
	echo '<optgroup label="Playlists">';
	
	$query_playlists = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."' ORDER by codigo ASC");
	while ($dados_playlist = mysql_fetch_array($query_playlists)) {
	
	$total_musicas = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'"));

	echo '<option value="'.$dados_playlist["codigo"].'">'.$dados_playlist["nome"].' ('.$total_musicas.')</option>';
		
	}
	
	echo '</optgroup>';
	echo '</select>';
	echo '<br />';
	echo '<select name="shuffle" id="shuffle" style="width:135px;">';
	echo '<optgroup label="Ordem das M�sicas">';
	echo '<option value="0" selected="selected">Seguir Orderm</option>';
	echo '<option value="1">Misturar</option>';
	echo '</optgroup>';
	echo '</select>';
	echo '<select name="xfade" id="xfade" style="width:105px;">';
	echo '<optgroup label="AutoMix/xFade">';
	
	foreach(array("0" => "(sem xfade)","2" => "2 segundos","4" => "4 segundos","6" => "6 segundos","8" => "8 segundos","10" => "10 segundos") as $xfade => $xfade_descricao){
	
		if($xfade == $dados_stm["xfade"]) {
			echo '<option value="'.$xfade.'" selected="selected">'.$xfade_descricao.'</option>';
		} else {
			echo '<option value="'.$xfade.'">'.$xfade_descricao.'</option>';
		}
	
	}
	
	echo '</optgroup>';
	echo '</select>';
	echo '<select name="bitrate" id="bitrate" style="width:160px;">';
	echo '<optgroup label="Bitrate">';
	
	foreach(array("20","24","32","36","42","48","52","56","64","68","72","78","82","86","94","96","103","116","128") as $bitrate){
	
		if($bitrate <= $dados_stm["bitrate"]) {
			
			if($dados_stm["bitrate_autodj"]) {
		
			if($bitrate == $dados_stm["bitrate_autodj"]) {
				echo '<option value="'.$bitrate.'" selected="selected">'.$bitrate.' Kbps(�ltimo usado)</option>';
			} else {
				echo '<option value="'.$bitrate.'">'.$bitrate.' Kbps</option>';
			}
			
			} else {
			
			if($bitrate == $dados_stm["bitrate"]) {
				echo '<option value="'.$bitrate.'" selected="selected">'.$bitrate.' Kbps</option>';
			} else {
				echo '<option value="'.$bitrate.'">'.$bitrate.' Kbps</option>';
			}
			
			}
		
		}
		
	}	
		
	echo '</optgroup>';
	echo '</select>';
	echo '<br />';
	echo '<br />';	
	echo '<input type="button" class="botao" value="Ligar AutoDJ" onclick="ligar_autodj(\''.code_decode($dados_stm["porta"],"E").'\',document.getElementById(\'playlist\').value,document.getElementById(\'shuffle\').value,document.getElementById(\'bitrate\').value,document.getElementById(\'xfade\').value);" />';
	
	} else {
	echo "<span class='texto_status_erro'>O streaming ".$dados_stm["porta"]." n�o possui nenhuma playlist criada.<br />Voc� deve criar uma playlist para ligar o AutoDJ.</span>";
	}

}

// Fun��o para ligar autodj
if($acao == "ligar_autodj") {

	

	$porta = code_decode(query_string('3'),"D");
	$playlist = query_string('4');
	$shuffle = query_string('5');
	$bitrate = query_string('6');
	$xfade = query_string('7');
	$agendamento = query_string('8');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	if($dados_servidor["status"] == "off") {	
	
	echo "<span class='texto_status_alerta'>N�o foi poss�vel executar a��o, servidor em manuten��o.</span>";
	
	exit();	
	}
	
	$status_streaming = status_streaming($_SESSION["ftp_host"],$_SESSION["ftp_user"]);
	
	if($status_streaming == "ligado") {
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($_SESSION["ftp_host"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$_SESSION["ftp_user"]." ".$dados_stm["porta_dj"]."");
	
	// Atualiza a �ltima playlist tocada
	mysql_query("Update streamings set ultima_playlist = '0' where codigo = '".$dados_stm["codigo"]."'");
	}

        // Verifica se o autodj j� esta ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	
	echo "<span class='texto_status_erro'>O AutoDJ ".$_SESSION["ftp_user"]." j� esta em execuss�o.<br />Para iniciar outra playlist voc� desligar o AutoDJ.</span>";

	} else {
	
        if($dados_stm["shoutcast"] == 'aacp') {
	// Carrega Multpoint
	$qtd_multpoint = 2;
	
	$sql_multpoint = mysql_query("SELECT * FROM multpoints where codigo_stm = '".$dados_stm["codigo"]."' ORDER by codigo ASC");
	while ($dados_pontos = mysql_fetch_array($sql_multpoint)) {
	
	$multpoint_config_autodj .= "encoder_".$qtd_multpoint."=".$dados_pontos["encoder"]."\n";
        $multpoint_config_autodj .= "bitrate_".$qtd_multpoint."=".$dados_pontos["bitrate"]."000\n";
        $multpoint_config_autodj .= "aacformat_".$qtd_multpoint."=0\n";
	$multpoint_config_autodj .= "samplerate_".$qtd_multpoint."=44100\n";
        $multpoint_config_autodj .= "outprotocol_".$qtd_multpoint."=3\n";
        $multpoint_config_autodj .= "serverport_".$qtd_multpoint."=".$dados_stm["porta"]."\n";
        $multpoint_config_autodj .= "uvoxauth_".$qtd_multpoint."=".$dados_stm["senha"]."\n";
        $multpoint_config_autodj .= "uvoxstreamid_".$qtd_multpoint."=".$qtd_multpoint."\n";
        $multpoint_config_autodj .= "endpointname_".$qtd_multpoint."=/stream\n";
        $multpoint_config_autodj .= "serverip_".$qtd_multpoint."=127.0.0.1\n";
        
        $qtd_multpoint++;
	}
	} else {
        }
        // Carrega os DJs
        if($dados_stm["shoutcast"] == 'aacp') {
	$qtd_djs = 1;
        } else {
        $qtd_djs = 0;
        }
	
	$sql_djs = mysql_query("SELECT * FROM djs where codigo_stm = '".$dados_stm["codigo"]."' ORDER by login");
	while ($dados_dj = mysql_fetch_array($sql_djs)) {
	
	$djs_config_autodj .= "djlogin_".$qtd_djs."=".$dados_dj["login"]."\n";
	$djs_config_autodj .= "djpassword_".$qtd_djs."=".$dados_dj["senha"]."\n";
        $djs_config_calendar[] = "".$dados_dj["login"]."|".$dados_dj["inicio_hora"]."|".$dados_dj["inicio_minu"]."|".$dados_dj["final_hora"]."|".$dados_dj["final_minu"]."|".$dados_dj["restricao"]."|".$dados_dj["dias"]."";
	
	$qtd_djs++;
	}
        

     




	// Carrega os agendamentos de playlists para o arquivo de configura��o do autodj
	if($dados_stm["shoutcast"] == 'aacp') {
	$qtd_agendamentos = 1;
	} else {
        }
        if($dados_stm["shoutcast"] == 'mp3') {
	$qtd_agendamentos = 0;
	} else {
        }
	
	$sql_agendamento = mysql_query("SELECT DISTINCT codigo_playlist FROM playlists_agendamentos where codigo_stm = '".$dados_stm["codigo"]."' ORDER by codigo ASC");
	while ($dados_agendamento = mysql_fetch_array($sql_agendamento)) {
	
	$dados_playlist_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'"));
	
	$playlist_nome = str_replace(".pls","",$dados_playlist_agendamento["arquivo"]);
	
	$playlists_config_autodj .= "playlistfilename_".$qtd_agendamentos."=".$playlist_nome."\n";
	$playlists_config_autodj .= "playlistfilepath_".$qtd_agendamentos."=/home/streaming/playlists/".$dados_playlist_agendamento["arquivo"]."\n";
	
	$qtd_agendamentos++;
	}
	
	// Carrega os agendamentos de playlists para o calendar
	
	$sql_agendamento = mysql_query("SELECT * FROM playlists_agendamentos where codigo_stm = '".$dados_stm["codigo"]."' ORDER by codigo ASC");
	while ($dados_agendamento = mysql_fetch_array($sql_agendamento)) {
	
	$dados_playlist_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'"));
	

	$playlist_nome = str_replace(".pls","",$dados_playlist_agendamento["arquivo"]);
	
	$playlists_config_calendar[] = "".$playlist_nome."|".$dados_agendamento["frequencia"]."|".$dados_agendamento["data"]."|".$dados_agendamento["hora"]."|".$dados_agendamento["minuto"]."|".$dados_agendamento["duracao_hora"]."|".$dados_agendamento["duracao_minuto"]."|".$dados_agendamento["dias"]."|".$dados_agendamento["repetir"]."|".$dados_agendamento["shuffle"]."|".$dados_agendamento["url"]."";
        
	
	}
	
	$config_autodj = array ("porta" => $_SESSION["ftp_user"], "porta_dj" => $dados_stm["porta_dj"], "senha" => $dados_stm["senha"], "streamtitle" => $dados_stm["streamtitle"], "streamurl" => $dados_stm["streamurl"], "genre" => $dados_stm["genre"], "bitrate" => $bitrate, "playlist" => $dados_playlist["arquivo"], "shuffle" => $shuffle, "xfade" => $xfade, "encoder" => $dados_stm["encoder"], "djs" => $djs_config_autodj, "multpoint" => $multpoint_config_autodj,"playlists" => $playlists_config_autodj, "shoutcast" => $dados_stm["shoutcast"]);
	
	$config_autodj_calendar = array ("porta" => $_SESSION["ftp_user"], "listarelay" => $relay_config_calendar, "playlists" => $playlists_config_calendar, "djs" => $djs_config_calendar);
        
	
	$config_autodj = gerar_conf_autodj($config_autodj);					  
	$config_calendar = gerar_calendar_autodj($config_autodj_calendar);					
	
	$ssh->enviar_arquivo("../temp/".$config_autodj."","/home/streaming/configs/".$config_autodj."",0777);
	$ssh->enviar_arquivo("../temp/".$config_calendar."","/home/streaming/configs/".$config_calendar."",0777);
	
	unlink("../temp/".$config_autodj."");
	unlink("../temp/".$config_calendar."");
        
        $resultado = $ssh->executar("/home/streaming/shoutcast/".$dados_stm["shoutcast"]."/ligar_autodj /home/streaming/configs/".$config_autodj."");
	
	$resultado = str_replace("\n","",$resultado);
	
	if(is_numeric($resultado) || $resultado == "ok") {
	
	// Atualiza a �ltima playlist tocada e o bitrate do autodj
	mysql_query("Update streamings set ultima_playlist = '".$dados_playlist["codigo"]."', bitrate_autodj = '".$bitrate."', xfade = '".$xfade."' where codigo = '".$dados_stm["codigo"]."'");
        mysql_query("Update djs set status = '1' where codigo_stm = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>AutoDJ ".$dados_stm["porta"]." ligado com sucesso.</span><br /><br/><a href='javascript:window.opener.parent.location.replace();' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel ligar o AutoDJ ".$dados_stm["porta"]."<br>Tente novamente ou crie uma nova playlist.</span>";
	}
	
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel ligar o AutoDJ ".$dados_stm["porta"]."<br>Log: O streaming ".$dados_stm["porta"]." esta desligado.</span>";
	}
	
	exit();
}

// Fun��o para recarregar playlist no autodj
if($acao == "pular_musica") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Verifica se o autodj esta ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	
	$resultado = $ssh->executar("/home/streaming/pular_musica_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	
	$resultado = str_replace("\n","",$resultado);
	
	if($resultado == "ok") {
	echo "<span class='texto_status_sucesso'>M�sica atual do AutoDJ <strong>".$dados_stm["porta"]."</strong> pulada com sucesso.</span>";
	} else {
	echo "<span class='texto_status_erro'>".$resultado."</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel pular a m�sica atual do AutoDJ <strong>".$dados_stm["porta"]."</strong><br>Log: O AutoDJ n�o esta ligado.</span>";
	}
	
	exit();
}

// Fun��o para recarregar playlist no autodj
if($acao == "recarregar_playlist") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Verifica se o autodj esta ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	
	$resultado = $ssh->executar("/home/streaming/recarregar_playlist_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	
	$resultado = str_replace("\n","",$resultado);
	
	if($resultado == "ok") {
	echo "<span class='texto_status_sucesso'>Playlist do AutoDJ <strong>".$dados_stm["porta"]."</strong> recarregada com sucesso.</span>";
	} else {
	echo "<span class='texto_status_erro'>".$resultado."</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel recarregar a playlist do AutoDJ <strong>".$dados_stm["porta"]."</strong><br>Log: O AutoDJ n�o esta ligado.</span>";
	}
	
	exit();
}

// Fun��o para desligar autodj
if($acao == "desligar_autodj") {

	$porta = code_decode(query_string('3'),"D");
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Verifica se o autodj esta ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	
	$resultado = $ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	
	$resultado = str_replace("\n","",$resultado);
	
	if($resultado == "ok") {
	
	// Atualiza a �ltima playlist tocada
	mysql_query("Update streamings set ultima_playlist = '0' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>AutoDJ <strong>".$dados_stm["porta"]."</strong> desligado com sucesso.</span><br /><br/><a href='javascript:void(0);' onClick='status_streaming(\"".$dados_stm["porta"]."\");document.getElementById(\"log-sistema-fundo\").style.display = \"none\";document.getElementById(\"log-sistema\").style.display = \"none\";'>[Atualizar]</a>";
	
	} else {
	echo "<span class='texto_status_erro'>".$resultado."</span>";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel desligar o AutoDJ <strong>".$dados_stm["porta"]."</strong><br>Log: O AutoDJ n�o esta ligado.</span>";
	}
	
	exit();
}

// Fun��o para remover um DJ do AutoDJ
if($acao == "remover_dj") {

	$codigo = code_decode(query_string('3'),"D");
	
	$dados_dj = mysql_fetch_array(mysql_query("SELECT * FROM djs where codigo = '".$codigo."'"));

	mysql_query("Delete From djs where codigo = '".$dados_dj["codigo"]."'");
	
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>DJ <strong>".$dados_dj["login"]."</strong> removido com sucesso.</span><br /><br /><a href='javascript:window.location.reload()'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o DJ <strong>".$dados_dj["login"]."</strong><br>Log: ".mysql_error()."</span>";
	
	}
	
	exit();

}


// Fun��o para carregar o formul�rio para altera��o das configura��es do streaming
if($acao == "carregar_configuracoes_streaming") {

	$porta = code_decode(query_string('3'),"D");

	
	
	// Prote��o contra usuario n�o logados
	if(empty($_SESSION["porta_logada"])) {
	die("<span class='texto_status_erro'>0x002 - Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
	}
	
	// Prote��o contra usuario n�o logados
	if($_SESSION["porta_logada"] != $porta) {
	die("<span class='texto_status_erro'>0x003 - Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
	}	
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	
	$encoder_mp3_selecionado  = ($dados_stm["encoder"] == "mp3") ? ' selected="selected"' : "";
	$encoder_aacplus_selecionado  = ($dados_stm["encoder"] == "aacp") ? ' selected="selected"' : "";
	
	echo '<div id="quadro">
<div id="quadro-topo"><strong>Configura&ccedil;&otilde;es do Streaming</strong></div>
 <div class="texto_medio" id="quadro-conteudo">
    <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td width="140" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Senha</td>
        <td width="435" align="left">
        <input name="senha" type="password" class="input" id="senha" style="width:250px;" value="'.$dados_stm["senha"].'" onkeyup="bloquear_acentos(this);" />
		<br />
          <span class="texto_padrao_pequeno">N&atilde;o use espa&ccedil;os, acentos ou qualquer outro car�cter especial</span>
		</td>
      </tr></tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">T�tulo do Streaming</td>
        <td align="left"><input name="streamtitle" type="text" class="input" id="streamtitle" style="width:250px;" value="'.$dados_stm["streamtitle"].'" onkeyup="bloquear_acentos(this);" /></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">URL do Site</td>
        <td align="left"><input name="streamurl" type="text" class="input" id="streamurl" style="width:250px;" value="'.$dados_stm["streamurl"].'" /></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">G�nero Musical</td>
        <td align="left"><input name="genre" type="text" class="input" id="genre" style="width:250px;" value="'.$dados_stm["genre"].'" onkeyup="bloquear_acentos(this);" /></td>
      </tr>
       </td>
      </tr>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="button" class="botao" value="Alterar Configura��es" onclick="alterar_configuracoes_streaming(\''.query_string('3').'\',document.getElementById(\'senha\').value,document.getElementById(\'encoder\').value,document.getElementById(\'streamtitle\').value,document.getElementById(\'streamurl\').value,document.getElementById(\'genre\').value);" /></td>
      </tr>
    </table>
  </div>
</div>';
	
}

// Fun��o para carregar o formul�rio para altera��o das configura��es do streaming
if($_POST["acao"] == "alterar_configuracoes_streaming") {
	
	$porta = code_decode($_POST["porta"],"D");

	
	
	// Prote��o contra usuario n�o logados
	if(empty($_SESSION["porta_logada"])) {
	die("<span class='texto_status_erro'>0x002 - Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
	}
	
	// Prote��o contra usuario n�o logados
	if($_SESSION["porta_logada"] != $porta) {
	die("<span class='texto_status_erro'>0x003 - Aten��o! Acesso n�o autorizado, favor entrar em contato com nosso atendimento para maiores informa��es!</span>");
	}		

	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	
	mysql_query("Update streamings set senha = '".$_POST["senha"]."', streamtitle = '".addslashes(utf8_decode($_POST["streamtitle"]))."', streamurl = '".$_POST["streamurl"]."', genre = '".addslashes(utf8_decode($_POST["genre"]))."' where codigo = '".$dados_stm["codigo"]."'");
	
	if(!mysql_error()) {	
	
	echo "<span class='texto_status_sucesso'>Configura��es alteradas com sucesso.</span>";
	
	// Loga a a��o executada
    mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('alterar_configuracoes_streaming',NOW(),'".$_SERVER['REMOTE_ADDR']."','Altera��o nas configura��es do streaming ".$dados_stm["porta"]."')");
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel alterar as configura��es do <br>Log: ".mysql_error()."</span>";
	}


}



// Fun��o para carregar a lista de player dispon�veis
if($acao == "carregar_lista_players_streaming") {

	

	$porta = query_string('3');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".code_decode(query_string('3'),"D")."'"));

	echo '<div id="quadro">
<div id="quadro-topo"><strong>Players do Streaming</strong></div>
 <div class="texto_medio" id="quadro-conteudo">
    <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center">
        <select name="encoder" class="input" id="encoder" style="width:255px;" onchange="gerar_codigo_player_streaming(\''.$porta.'\',this.value);">
		  <option value="">Selecione o player desejado</option>
          <option value="flash">Player em Flash</option>
          <option value="winamp">Link para Winamp</option>
          <option value="mediaplayer">Link para Media Player</option>
          <option value="realplayer">Link para Real Player</option>
          <option value="iphone">Link para iphone/ipad/ipod</option>';
		  if($dados_stm["aacplus"] == 'sim') {
		  echo '<option value="android">Link para Android</option>';
		  }
         '</select>
		 </td>
      </tr>
    </table>
  </div>
</div>';
	
	exit();

}


// Fun��o para remover a hora certa
if($acao == "remover_hora") {


	

	$codigo = code_decode(query_string('3'),"D");
	
	$dados_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists_agendamentos where codigo = '".$codigo."'"));
        
	mysql_query("Delete From playlists_agendamentos where codigo = '".$dados_agendamento["codigo"]."'");
	mysql_query("Delete From playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'");
	if(!mysql_error()) {
	
	echo "";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o agendamento<br>Log: ".mysql_error()."</span>";
	
	}
	
	


	

	$codigo = code_decode(query_string('3'),"D");
	
	$dados_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists_agendamentos where codigo = '".$codigo."'"));

	mysql_query("Delete From playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'");
	
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>Hora removido com sucesso.</span><br /><br /><a href='javascript:window.location.reload()' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o agendamento<br>Log: ".mysql_error()."</span>";
	
	}
	
	exit();

}

// Fun��o para remover todas as horas certas
if($acao == "remover_hora_todas") {


	

	$codigo = code_decode(query_string('3'),"D");
	
	
	
	$dados_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists_agendamentos where codigo = '".$codigo."'"));
        $dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_agendamento["codigo_stm"]."'"));
	
	mysql_query("Delete From playlists_agendamentos where funcao = '".$dados_stm["codigo"]."hora'");
	mysql_query("Delete From playlists where funcao = '".$dados_stm["codigo"]."1'");
	if(!mysql_error()) {
	
	echo "";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o agendamento<br>Log: ".mysql_error()."</span>";
	
	}
	
	$codigo = code_decode(query_string('3'),"D");
	
	$dados_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists_agendamentos where codigo = '".$codigo."'"));

	mysql_query("Delete From playlists where funcao = '".$dados_stm["codigo"]."'");
	mysql_query("Delete From playlists_agendamentos where funcao = '".$dados_stm["codigo"]."'");
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>Todas as horas foram removidas com sucesso.</span><br /><br /><a href='javascript:window.location.reload()' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o agendamento<br>Log: ".mysql_error()."</span>";
	
	}
	
	exit();

}


// Fun��o para remover um agendamento de playlist
if($acao == "remover_agendamento") {

	

	$codigo = code_decode(query_string('3'),"D");
	
	$dados_agendamento = mysql_fetch_array(mysql_query("SELECT * FROM playlists_agendamentos where codigo = '".$codigo."'"));

	mysql_query("Delete From playlists_agendamentos where codigo = '".$dados_agendamento["codigo"]."'");
	
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>Agendamento removido com sucesso.</span><br /><br /><a href='javascript:window.location.reload()' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o agendamento<br>Log: ".mysql_error()."</span>";
	
	}
	
	exit();

}


// Fun��o para gerar o c�digo HTML do player do streaming
if($acao == "gerar_codigo_player_streaming") {

	

	$porta = code_decode(query_string('3'),"D");
	$player = query_string('4');
		
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	echo '<div id="quadro">
<div id="quadro-topo"><strong>Players do Streaming</strong></div>
 <div class="texto_medio" id="quadro-conteudo">
 <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-bottom:5px">
      <tr>
        <td height="30" align="center">
        <select name="encoder" class="input" id="encoder" style="width:255px;" onchange="gerar_codigo_player_streaming(\''.query_string('3').'\',this.value);">
		  <option value="">Selecione o player desejado</option>
          <option value="flash">Player em Flash HD</option>
          <option value="winamp">Link para Winamp</option>
          <option value="mediaplayer">Link para Media Player</option>
          <option value="realplayer">Link para Real Player</option>
          <option value="iphone">Link para iphone/ipad/ipod</option>';
		  if($dados_stm["aacplus"] == 'sim') {
		  echo '<option value="android">Link para Android</option>';
		  }
         '</select>
		 </td>
      </tr>
    </table>'; 

	if($player == "flash") {
	
	if($dados_stm["aacplus"] == 'sim') {
	
	$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center">
        <embed src="http://'.$_SERVER['HTTP_HOST'].'/acc.swf" width="280" height="20" allowscriptaccess="always" allowfullscreen="true" flashvars="height=20&width=280&file=rtmp://aa.stm-ip.com:1935/shoutcast&id=http://'.$dados_servidor["nome"].':'.$dados_stm["porta"].'/;type=rmtp&volume=100&bufferlength=10&autostart=true" type="application/x-shockwave-flash" /></embed>
        </td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><embed src="http://'.$_SERVER['HTTP_HOST'].'/acc.swf" width="280" height="20" allowscriptaccess="always" allowfullscreen="true" flashvars="height=20&width=280&file=rtmp://173.208.235.232:1935/shoutcast&id=http://'.$dados_servidor["nome"].':'.$dados_stm["porta"].'/;type=rmtp&volume=100&bufferlength=10&autostart=true" type="application/x-shockwave-flash" /></embed></textarea>
        </td>
      </tr>
    </table>';
	
	} else {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center">
       <embed src="http://'.$_SERVER['HTTP_HOST'].'/acc.swf" width="280" height="20" allowscriptaccess="always" allowfullscreen="true" flashvars="height=20&width=280&file=rtmp://aa.stm-ip.com:1935/shoutcast&id=http://'.$dados_servidor["nome"].':'.$dados_stm["porta"].'/;type=rmtp&volume=100&bufferlength=10&autostart=true" type="application/x-shockwave-flash" /></embed>
        </td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><embed src="http://'.$_SERVER['HTTP_HOST'].'/acc.swf" width="280" height="20" allowscriptaccess="always" allowfullscreen="true" flashvars="height=20&width=280&file=rtmp://aa.stm-ip.com:1935/shoutcast&id=http://'.$dados_servidor["nome"].':'.$dados_stm["porta"].'/;type=rmtp&volume=100&bufferlength=10&autostart=true" type="application/x-shockwave-flash" /></embed></textarea>
        </td>
      </tr>
    </table>';
	
	}
	
	} else if($player == "winamp") {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/winamp.pls"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-winamp.png" width="32" height="32" /></a></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/winamp.pls"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-winamp.png" width="32" height="32" title="Ouvir no Winamp" /></a></textarea>
        </td>
      </tr>
    </table>';
	
	} else if($player == "mediaplayer") {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/mediaplayer.asx"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-mediaplayer.png" width="32" height="32" /></a></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/mediaplayer.asx"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-mediaplayer.png" width="32" height="32" title="Ouvir no MediaPlayer" /></a></textarea>
        </td>
      </tr>
    </table>';
	
	} else if($player == "realplayer") {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/realplayer.rm"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-realplayer.png" width="32" height="32" /></a></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/realplayer.rm"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-realplayer.png" width="32" height="32" title="Ouvir no RealPlayer" /></a></textarea>
        </td>
      </tr>
    </table>';
	
	} else if($player == "iphone") {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/iphone.m3u"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-iphone.png" width="32" height="32" /></a></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/iphone.m3u"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-iphone.png" width="32" height="32" title="Ouvir no iphone" /></a></textarea>
        </td>
      </tr>
    </table>';
	
	} else if($player == "android") {
	
	echo '<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td height="30" align="center"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/android.m3u"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-android.png" width="32" height="32" /></a></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="left" style="padding:5px;">
          <textarea name="textarea" readonly="readonly" style="width:99%; height:80px;font-size:11px" onmouseover="this.select()"><a href="http://'.$_SERVER['HTTP_HOST'].'/player/'.$dados_stm["porta"].'/android.m3u"><img src="http://'.$_SERVER['HTTP_HOST'].'/img-icone-player-android.png" width="32" height="32" title="Ouvir no Android" /></a></textarea>
        </td>
      </tr>
    </table>';
	
	}
	
	echo '</div>
</div>';
	
	exit();

}

////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Playlist /////////////
////////////////////////////////////////////////////////

// Fun��o para carregar musicas do FTP
if($acao == "carregar_musicas_pasta") {

	

	$porta = code_decode(query_string('3'),"D");
	$pasta = query_string('4');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
		
	// Conex�o SSH
	$ftp = new FTP();
	$ftp->conectar($dados_servidor["ip"]);
	$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);
	
	$array_musicas = $ftp->listar_arquivos($pasta,"mp3");
	
	if($array_musicas) {

	foreach ($array_musicas as $musica) {
	$list_musicas = "".$musica."";
        $list_musicas = preg_replace( '/hora-feminina/', '<font color=\"#008000\">HORA CERTA ((Voz Feminina))</font>', $list_musicas, 1 );
        $list_musicas = preg_replace( '/mp3/', '', $list_musicas, 1 );
        $list_musicas = preg_replace( '/hora-masculina/', '<font color=\"#A0C0FF\">HORA CERTA ((Voz Masculina))</font>', $list_musicas, 1 );
   
	echo "".$pasta."/".$musica."|".$list_musicas.";";
	
	}
	
	}
		
	exit();

}


// Fun��o para carregar as playlists
if($acao == "carregar_lista_playlists") {

	

	$porta = code_decode(query_string('3'),"D");
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
	
	if($total_playlists > 0) {

	$query = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."' ORDER by nome ASC");
	while ($dados_playlist = mysql_fetch_array($query)) {
	
	$total_musicas = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'"));
	
	echo "".$dados_playlist["codigo"]."|".$dados_playlist["nome"]."|".$total_musicas.";";
	
	}
	
	}
	
	exit();

}


// Fun��o para carregar musicas do playlist
if($acao == "carregar_musicas_playlist") {

	

	$playlist = query_string('3');
	
	$total_musicas = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$playlist."'"));

	if($total_musicas > 0) {
        
      
		
	
	$query = mysql_query("SELECT SQL_CACHE * FROM playlists_musicas where codigo_playlist = '".$playlist."' ORDER by ordem,codigo ASC");
	while ($dados_playlist_musica = mysql_fetch_array($query)) {
      
        
	$playlist_musica = "".$dados_playlist_musica["musica"]."";
        $playlist_musica = preg_replace( '/hora-feminina/', '<<font color=\"#008000\">HORA CERTA ((Voz Feminina))</font>', $playlist_musica, 1 );
        $playlist_musica = preg_replace( '/mp3/', '', $playlist_musica, 1 );
        $playlist_musica = preg_replace( '/hora-masculina/', '<<font color=\"#A0C0FF\">HORA CERTA ((Voz Masculina))</font>', $playlist_musica, 1 );
        $playlist_musica = preg_replace( '/./', '', $playlist_musica, 1 );
	echo "".$dados_playlist_musica["path_musica"]."|".$playlist_musica.";";
	
	}
	
	}
	
	exit();


}

// Fun��o para criar nova playlist
if($acao == "criar_playlist") {

	

	$porta = code_decode(query_string('3'),"D");
	$playlist = query_string('4');
        $playlist_nome = "".$playlist."";
        $playlist_nome = ereg_replace("[����]","a",$playlist_nome);
        $playlist_nome = ereg_replace("[����]","A",$playlist_nome);
        $playlist_nome = ereg_replace("[���]","e",$playlist_nome);
        $playlist_nome = ereg_replace("[���]","E",$playlist_nome);
        $playlist_nome = ereg_replace("[�����]","o",$playlist_nome);
        $playlist_nome = ereg_replace("[����]","O",$playlist_nome);
        $playlist_nome = ereg_replace("[���]","u",$playlist_nome);
        $playlist_nome = ereg_replace("[���]","U",$playlist_nome);
        $playlist_nome = str_replace("�","c",$playlist_nome);
        $playlist_nome = str_replace("�","C",$playlist_nome);
        
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$playlist_arquivo = "".$dados_stm["porta"]."-".formatar_nome_playlist($playlist).".pls";
        $total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where cota = '1'"));
        $somar_playlist = $total_playlists+2;
        $gerar_novo_ID = date('s')+$somar_playlist;


	mysql_query("INSERT INTO playlists (codigo,codigo_stm,nome,arquivo,data) VALUES ('".$porta."".$gerar_novo_ID."','".$dados_stm["codigo"]."','".$playlist_nome."','".$playlist_arquivo."',NOW())");
	
	if(!mysql_error()) {
	
	echo "ok";
	
	}
	
	exit();

}

// Fun��o para remover m�sica da playlist
if($acao == "remover_musica") {

	$musica = query_string('3')."/".query_string('4');

	$verifica_musica = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where path_musica = '".$musica."'"));
	
	if($verifica_musica == 1) {
	
	mysql_query("Delete From playlists_musicas where path_musica = '".$musica."'");
	
	}
	
	exit();

}

// Fun��o para remover uma playlist
if($acao == "remover_playlist") {

	

	$playlist = query_string('3');
	
	$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_playlist["codigo_stm"]."'"));
	
	$verifica_playlist = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
	
	if($verifica_playlist == 1) {
	
	mysql_query("Delete From playlists where codigo = '".$dados_playlist["codigo"]."'");
	mysql_query("Delete From playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'");
	mysql_query("Delete From playlists_agendamentos where codigo_playlist = '".$dados_playlist["codigo"]."'");
	
	if(!mysql_error()) {
	
	echo "<span class='texto_status_sucesso'>Playlist removida com sucesso.</span><br /><br /><a href='javascript:carregar_playlists(\"".code_decode($dados_stm["porta"],"E")."\");' class='texto_status_atualizar'>[Atualizar]</a>";
	
	} else {
	
	echo "<span class='texto_status_sucesso'>Playlist removida com sucesso.</span><br /><br /><a href='javascript:carregar_playlists(\"".code_decode($dados_stm["porta"],"E")."\");' class='texto_status_atualizar'>[Atualizar]</a>";
	
	}
	
	} else {
	
	echo "<span class='texto_status_erro'>A playlist que tentou remover n�o existe.</span>";
	
	}
	
	exit();

}

////////////////////////////////////////////////////////
//////////// Fun��es Gerenciamento M�sicas /////////////
////////////////////////////////////////////////////////

// Fun��o para criar nova pasta
if($acao == "criar_pasta") {

	$porta = code_decode(query_string('3'),"D");
	$pasta = remover_acentos(query_string('4'));

	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

	// Conex�o SSH
	$ftp = new FTP();
	$ftp->conectar($dados_servidor["ip"]);
	$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);
	
	$resultado = $ftp->criar_pasta($pasta);
	
	if($resultado) {
	
	echo $pasta;
	
	}
	
	exit();

}

// Fun��o para remover uma pasta
if($acao == "remover_pasta") {

	$porta = code_decode(query_string('3'),"D");
	$pasta = query_string('4');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

	// Conex�o SSH
	$ftp = new FTP();
	$ftp->conectar($dados_servidor["ip"]);
	$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);
	
	$resultado = $ftp->remover_pasta($pasta);
	
	if($resultado) {
	
	echo "ok";
	
	}
	
	exit();

}

// Fun��o para remover uma m�sica no FTP
if($acao == "remover_musica_ftp") {

	$porta = code_decode(query_string('3'),"D");
	$musica = str_replace("|","/",query_string('4'));
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

	// Conex�o SSH
	$ftp = new FTP();
	$ftp->conectar($dados_servidor["ip"]);
	$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);
	
	$resultado = $ftp->remover_arquivo($musica);
	
	if($resultado) {
	
	echo "ok";
	
	}
	
	exit();

}


// Fun��o para carregar as pastas
if($acao == "carregar_lista_pastas") {

	

	$porta = code_decode(query_string('3'),"D");
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o FTP
	$ftp = new FTP();
	$ftp->conectar($dados_servidor["ip"]);
	$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);

	$array_pastas = $ftp->listar_pastas("/");
	
	$lista_pastas .= "/|".$ftp->total_arquivos("/","mp3").";";

	if(count($array_pastas) > 0){
	
	foreach ($array_pastas as $pasta) {

	if($pasta != "." && $pasta != "..") {
	
	$lista_pastas .= "".$pasta."|".$ftp->total_arquivos($pasta,"mp3").";";
	
	}
	
	}
	
	}
	
	echo $lista_pastas;
		
	exit();

}

////////////////////////////////////////////////////////
//////////// Fun��es Gerenciamento Revenda /////////////
////////////////////////////////////////////////////////

// Fun��o para bloquear revenda
if($acao == "bloquear_revenda") {

	$codigo = code_decode(query_string('3'),"D");
	
	if($codigo == "" || $codigo == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {

	$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$codigo."'"));
	
	// Desliga os streamings da revenda
	$query_stms = mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'");
	while ($dados_stm = mysql_fetch_array($query_stms)) {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_stm["codigo"]."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	// Bloqueia o streaming no servidor
	$ssh->executar("iptables -A INPUT -p tcp --dport ".$porta." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	mysql_query("Update streamings set status = '2' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> bloqueado com sucesso.</span><br />";
	
	}
	
	mysql_query("Update revendas set status = '2' where codigo = '".$dados_revenda["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'><br />Revenda <strong>".$dados_revenda["nome"]."</strong> bloqueada com sucesso.</span><br /><br /><a href='javascript:window.location.reload()'>[Atualizar]</a>";
	
	}
	
	exit();
}

// Fun��o para desbloquear revenda
if($acao == "desbloquear_revenda") {

	$codigo = code_decode(query_string('3'),"D");
	
	if($codigo == "" || $codigo == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {
	
	$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$codigo."'"));
	
	// Desbloqueia os streamings da revenda
	$query_stms = mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'");
	while ($dados_stm = mysql_fetch_array($query_stms)) {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_stm["codigo"]."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	// Bloqueia o streaming no servidor
	$ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	mysql_query("Update streamings set status = '1' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> desbloqueado com sucesso.</span><br />";
	}
	
	mysql_query("Update revendas set status = '1' where codigo = '".$dados_revenda["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'><br />Revenda <strong>".$dados_revenda["nome"]."</strong> desbloqueada com sucesso.</span><br /><br /><a href='javascript:window.location.reload()'>[Atualizar]</a>";
	
	}
	
	exit();
}

// Fun��o para remover revenda
if($acao == "remover_revenda") {

	$codigo = code_decode(query_string('3'),"D");
	
	if($codigo == "" || $codigo == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando.</span>";
	
	} else {
	
	$checar_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas where codigo = '".$codigo."'"));
	
	if($checar_revenda == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Revenda n�o encontrada.</span>";
	
	exit();
	}
	
	$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$codigo."'"));
	
	// Remove os streamings da revenda
	$query_stms = mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'");
	while ($dados_stm = mysql_fetch_array($query_stms)) {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_stm["codigo"]."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "ligado") {
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	}

	$resultado = $ssh->executar("/home/streaming/desligar_streaming ".$dados_stm["porta"]."");
		
	$resultado = str_replace("\n","",$resultado);
	
	} else {
	$resultado = "ok";
	}
	
	if($resultado == "ok") {
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
	// Desbloqueia o streaming no servidor
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	$ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	$ssh->executar("nohup rm -rf /home/streaming/".$dados_stm["porta"]." /home/streaming/configs/*".$dados_stm["porta"]."* /home/streaming/logs/*".$dados_stm["porta"]."* /home/streaming/playlists/".$dados_stm["porta"]."-*.pls; echo ok");
	
	mysql_query("Delete From streamings where codigo = '".$dados_stm["codigo"]."'");
	
	// Remove as playlists
	$query_playlists = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'");
	while ($dados_playlist = mysql_fetch_array($query_playlists)) {
	
	mysql_query("Delete From playlists where codigo = '".$dados_playlist["codigo"]."'");
	
	$query_playlists_musicas = mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'");
	while ($dados_playlist_musicas = mysql_fetch_array($query_playlists_musicas)) {
	mysql_query("Delete From playlists_musicas where codigo = '".$dados_playlist_musicas["codigo"]."'");
	}
	
	}
	
	// Remove estatisticas
    // DESATIVADO
	
	echo "<span class='texto_status_sucesso'>Streaming <strong>".$dados_stm["porta"]."</strong> removido com sucesso.</span><br />";
	
	} else {
	
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o streaming <strong>".$dados_stm["porta"]."</strong> Log: Erro desconhecido.</span><br />";
	}
	
	} else {
	echo "<span class='texto_status_erro'>N�o foi poss�vel remover o streaming <strong>".$dados_stm["porta"]."</strong> Log: ".$resultado."</span><br />";
	}
	
	}
	
	mysql_query("Delete From revendas where codigo = '".$dados_revenda["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Revenda <strong>".$dados_revenda["nome"]."</strong> removida com sucesso.</span><br /><br /><a href='javascript:window.location.reload()'>[Atualizar]</a>";
	
	}
	
	exit();
}

// Fun��o para ativar prote��o contra ataques ao streaming
if($acao == "ativar_protecao") {

	$porta = code_decode(query_string('3'),"D");
	
	if($porta == "" || $porta == 0) {
	
	echo "<span class='texto_status_erro'>Aten��o! Erro ao executar a��o, dados faltando</span>";
	
	} else {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	if($dados_stm["protecao"] == "0") {	
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Bloqueia o streaming no servidor
	$ssh->executar("iptables -A INPUT -p tcp --syn --dport ".$dados_stm["porta"]." -m connlimit --connlimit-above 10 -j REJECT --reject-with tcp-reset;service iptables save;echo ok");
	
	mysql_query("Update streamings set protecao = '1' where codigo = '".$dados_stm["codigo"]."'");
	
	echo "<span class='texto_status_sucesso'>Prote��o contra ataques na porta <strong>".$dados_stm["porta"]."</strong> ativada com sucesso.</span>";
	
	} else {
	echo "<span class='texto_status_erro'>A prote��o contra ataques na porta <strong>".$dados_stm["porta"]."</strong> j� esta ativa.</span>";
	}
	
	}
	
	exit();
}
?>