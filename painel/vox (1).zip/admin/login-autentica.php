<?php
$_POST["email"] = str_replace("'='","",$_POST["email"]);
$_POST["senha"] = str_replace("'='","",$_POST["senha"]);

if($_POST["email"] == '' || $_POST["senha"] == '') {

$_SESSION[status_login] = '<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td width="100%" height="25" bgcolor="#F2BBA5" class="texto_log_sistema_alerta" style="padding-left: 5px;" scope="col" align="left">
<img src="img/icones/atencao.png" align="absmiddle">&nbsp;<strong>Por favor informe seu e-mail/senha de acesso</strong>
  </td>
</tr>
</table>';

unset($_SESSION["type_logged_user"]);
unset($_SESSION["code_user_logged"]);
header("Location: http://".$_SERVER['HTTP_HOST']."/admin/login");
exit;
}

if(ereg("@",$_POST["email"])) {

$valida_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE email = '".anti_sql_injection($_POST["email"])."' AND senha = '".anti_sql_injection($_POST["senha"])."'"));

if($valida_revenda == 1) {

$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE email = '".anti_sql_injection($_POST["email"])."'"));

$_SESSION["type_logged_user"] = "cliente";
$_SESSION["code_user_logged"] = $dados_revenda[codigo];

// Loga o acesso do usuario
mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('login',NOW(),'".$_SERVER['REMOTE_ADDR']."','Revenda ".$_POST["email"]." acessou sistema.')");

header("Location: http://".$_SERVER['HTTP_HOST']."/admin/revenda-streamings");
exit;

} else {

$_SESSION[status_login] = '<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td width="100%" height="25" bgcolor="#F2BBA5" class="texto_log_sistema_erro" style="padding-left: 5px;" scope="col" align="left">
<img src="img/icones/atencao.png" align="absmiddle">&nbsp;<strong>E-mail ou senha inv�lidos, tente novamente.</strong>
  </td>
</tr>
</table>';

unset($_SESSION["type_logged_user"]);
unset($_SESSION["code_user_logged"]);
header("Location: http://".$_SERVER['HTTP_HOST']."/admin/login");
exit;

}

} else { // se nao for cliente � operador

$valida_operador = mysql_num_rows(mysql_query("SELECT * FROM administradores WHERE usuario = '".anti_sql_injection($_POST["email"])."' AND senha = '".anti_sql_injection($_POST["senha"])."'"));

if($valida_operador == 1) {

$dados_operador = mysql_fetch_array(mysql_query("SELECT * FROM administradores WHERE usuario = '".anti_sql_injection($_POST["email"])."'"));

$_SESSION["type_logged_user"] = "operador";
$_SESSION["code_user_logged"] = $dados_operador["codigo"];

// Loga o acesso do usuario
mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('login',NOW(),'".$_SERVER['REMOTE_ADDR']."','Administrador ".$_POST["email"]." acessou sistema.')");

if(preg_match("/\b".$_SERVER['HTTP_HOST']."\b/i",$_POST["url"])) {
header("Location: ".$_POST["url"]."");
} else {
header("Location: http://".$_SERVER['HTTP_HOST']."/admin/admin-configuracoes");
}

exit;

} else {

$_SESSION[status_login] = '<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td width="100%" height="25" bgcolor="#F2BBA5" class="texto_log_sistema_erro" style="padding-left: 5px;" scope="col" align="left">
<img src="img/icones/atencao.png" align="absmiddle">&nbsp;<strong>Usu�rio ou senha inv�lidos, tente novamente</strong>
  </td>
</tr>
</table>';

unset($_SESSION["type_logged_user"]);
unset($_SESSION["code_user_logged"]);
header("Location: http://".$_SERVER['HTTP_HOST']."/admin/login");
exit;

}

}
?>