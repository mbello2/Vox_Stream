<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 600);

// Inclus�o de classes
require_once("inc/protecao-revenda.php");
require_once("inc/classe.ssh.php");


if(empty($_POST["porta"]) or empty($_POST["ouvintes"]) or empty($_POST["bitrate"]) or empty($_POST["espaco"]) or empty($_POST["senha"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
$dados_stm_atual = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_POST["porta"]."'"));

if($_POST["aacplus"] == 'sim') {

$encoder = "aacp";
$aacplus = "sim";
$servidor_aacplus = ($dados_stm_atual["codigo_servidor_aacplus"] == '0') ? $dados_config["codigo_servidor_aacplus_atual"] : $dados_stm_atual["codigo_servidor_aacplus"];

} else {

$encoder = "mp3";
$aacplus = "nao";
$servidor_aacplus = 0;

}

mysql_query("Update streamings set codigo_servidor_aacplus = '".$servidor_aacplus."', ouvintes = '".$_POST["ouvintes"]."', bitrate = '".$_POST["bitrate"]."', encoder = '".$encoder."', espaco = '".$_POST["espaco"]."', senha = '".$_POST["senha"]."', encoder = '".$encoder."', identificacao = '".$_POST["identificacao"]."', aacplus = '".$aacplus."' where porta = '".$_POST["porta"]."'");

$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm_atual["codigo_servidor"]."'"));

// Ativa/Desativa o relay no servidor aacplus
if($dados_stm_atual["aacplus"] != $_POST["aacplus"]) {

if($_POST["aacplus"] == 'sim') {

$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$servidor_aacplus."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

$ssh->executar("/usr/local/WowzaMediaServer/ativar-aacplus ".$_POST["porta"]." ".$dados_servidor["ip"]." ".$_POST["ouvintes"]."");

} else {

if($dados_stm_atual["codigo_servidor_aacplus"] != 0) {

$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm_atual["codigo_servidor_aacplus"]."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

$ssh->executar("/usr/local/WowzaMediaServer/desativar-aacplus ".$_POST["porta"]."");

}

}

}

// Atualiza o limite de ouvintes no relay no servidor aacplus
if($dados_stm_atual["ouvintes"] != $_POST["ouvintes"]) {

if($_POST["aacplus"] == 'sim') {

$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$servidor_aacplus."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

$ssh->executar("/usr/local/WowzaMediaServer/desativar-aacplus ".$_POST["porta"]."");
$ssh->executar("/usr/local/WowzaMediaServer/ativar-aacplus ".$_POST["porta"]." ".$dados_servidor["ip"]." ".$_POST["ouvintes"]."");

}

}

// Loga a a��o executada
mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('alterar_configuracoes_streaming',NOW(),'".$_SERVER['REMOTE_ADDR']."','Altera��o nas configura��es do streaming ".$dados_stm["porta"]." pela revenda.')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Configura��es do streaming ".$_POST["porta"]." alteradas com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Agora voc� precisa desligar e ligar novamente o streaming para aplicar as altera��es.","alerta");

header("Location: /admin/revenda-streamings/resultado/".$_POST["porta"]."");
?>