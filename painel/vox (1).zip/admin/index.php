<?php
session_set_cookie_params(0);
session_start();

unset($_SESSION["tipo_usuario_logado"]);
unset($_SESSION["codigo_usuario_logado"]);

require_once("inc/conecta.php");
require_once("inc/funcoes.php");

// Navega��o
$pagina = query_string('1');

if($pagina == "sair") {

$pagina = "login";

unset($_SESSION["type_logged_user"]);
unset($_SESSION["code_user_logged"]);
}

if ($pagina == "") {
require("login.php");
} elseif (!file_exists($pagina.".php")) {
require("login.php");
} else {
require("".$pagina.".php");
}
?>