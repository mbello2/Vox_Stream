<?php
require_once('inc/classe.ssh.php');

if(empty($_POST["ouvintes"]) or empty($_POST["bitrate"]) or empty($_POST["espaco"]) or empty($_POST["senha"])) {
die ("<script> alert(\"Voc� deixou campos em branco!\\n \\nPor favor volte e tente novamente.\"); 
		 window.location = 'javascript:history.back(1)'; </script>");
}

// Verifica a �ltima gerada e gera a pr�xima
$porta_livre_stm = false;
$porta_livre_dj = false;

$nova_porta_stm = 7998;
$nova_porta_dj = 34998;

// Porta Streaming
while(!$porta_livre_stm) {

$nova_porta_stm += 2;

$total_porta_livre_stm = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta = '".$nova_porta_stm."' ORDER BY porta"));

if($total_porta_livre_stm == 0) {
$porta_livre_stm = true;
}

}

// Porta DJ
while(!$porta_livre_dj) {

$nova_porta_dj += 2;

$total_porta_livre_dj = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta_dj = '".$nova_porta_dj."' ORDER BY porta_dj"));

if($total_porta_livre_dj == 0) {
$porta_livre_dj = true;
}

}

$porta = $nova_porta_stm;
$porta_dj = $nova_porta_dj;

// Verifica os limites do cliente
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$_SESSION["codigo_usuario_logado"]."'"));
$total_streamings_revenda = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
$ouvintes_revenda = mysql_fetch_array(mysql_query("SELECT SUM(ouvintes) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
$espaco_revenda = mysql_fetch_array(mysql_query("SELECT SUM(espaco) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));

if($dados_revenda["root"] == '2') {

// Verifica se excedeu o limite de streamings do cliente
$total_streamings_revenda = $total_streamings_revenda+1;

if($total_streamings_revenda > $dados_revenda["streamings"]) {
die ("<script> alert(\"Oops! Voc� atingiu o limite de streamings de seu plano.\\n \\nContate nosso atendimento para aumentar seu plano.\"); 
		 window.location = '/admin/revenda-streamings'; </script>");
}

// Verifica se excedeu o limite de ouvintes do cliente
$total_ouvintes_revenda = $ouvintes_revenda["total"]+$_POST["ouvintes"];

if($total_ouvintes_revenda > $dados_revenda["ouvintes"]) {
die ("<script> alert(\"Oops! Voc� atingiu o limite de ouvintes de seu plano.\\n \\nContate nosso atendimento para aumentar seu plano.\"); 
		 window.location = '/admin/revenda-streamings'; </script>");
}

// Verifica se excedeu o limite de ouvintes do cliente
$total_espaco_revenda = $espaco_revenda["total"]+$_POST["espaco"];

if($total_espaco_revenda > $dados_revenda["espaco"]) {
die ("<script> alert(\"Oops! Voc� atingiu o limite de espa�o para autodj de seu plano.\\n \\nContate nosso atendimento para aumentar seu plano.\"); 
		 window.location = '/admin/revenda-streamings'; </script>");
}

// Verifica se excedeu o limite de bitrate do cliente
if($_POST["bitrate"] > $dados_revenda["bitrate"]) {
die ("<script> alert(\"Oops! Voc� atingiu o limite de bitrate de seu plano.\\n \\nContate nosso atendimento para aumentar seu plano.\"); 
		 window.location = '/admin/revenda-streamings'; </script>");
}

} else {
}

// Adicioanr o streaming no servidor
$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));

if($dados_config["rodom"] == 1) {
if($dados_revenda["servidor"] == 0) {
$codigo = array (
"3",);

$codigototal = count($codigo);
$codigototal--;
$randomcodigo = rand(0,$codigototal);

$servidor = $codigo[$randomcodigo];

} else {
$servidor = $dados_revenda["servidor"];
}

} else {

if($dados_revenda["servidor"] == 0) {
$servidor = $dados_config["codigo_servidor_atual"];
} else {
$servidor = $dados_revenda["servidor"];
}

}

// Adicionar o streaming no mysql
mysql_query("INSERT INTO streamings (codigo_cliente,codigo_servidor,porta,porta_dj,ouvintes,bitrate,bitrate_autodj,espaco,senha,ftp_dir,identificacao,data_cadastro) VALUES ('".$_POST["codigo"]."','".$servidor."','".$porta."','".$porta_dj."','".$_POST["ouvintes"]."','".$_POST["bitrate"]."','".$_POST["bitrate"]."','".$_POST["espaco"]."','".$_POST["senha"]."','/home/streaming/".$porta."','".$_POST["identificacao"]."',NOW())") or die("Erro ao processar query.<br>Mensagem do servidor: ".mysql_error());
$codigo_streaming = mysql_insert_id();

// Atualizar o IP do streaming no mysql
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
mysql_query("Update streamings set ip_conexao = '".$dados_servidor["ip"]."' where codigo = '".$dados_stm["codigo"]."'");


// Cria o diret�rio do streaming no FTP
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_config["codigo_servidor_atual"]."'"));

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
$ssh->executar("mkdir -v /home/streaming/".$porta."; chown -v streaming.streaming /home/streaming/".$porta."");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] = status_acao("Streaming ".$porta." cadastrado com sucesso.","ok");

header("Location: /admin/revenda-streamings/resultado/".$porta."");
?>