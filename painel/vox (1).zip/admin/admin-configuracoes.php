<?php
require_once("inc/protecao-admin.php");

if($_POST["alterar_dados"]) {

mysql_query("Update configuracoes set ip_painel = '".$_POST["ip_painel"]."', codigo_servidor_atual = '".$_POST["codigo_servidor_atual"]."', codigo_servidor_aacplus_atual = '".$_POST["codigo_servidor_aacplus_atual"]."'");

// Cria o sess�o do status das a��es executadas e redireciona.

if(!mysql_error()) {

$_SESSION["status_acao"] = status_acao("Configura��es alteradas com sucesso.","ok");

} else {

$_SESSION["status_acao"] = status_acao("N�o foi poss�vel alterar as configura��es. Log: ".mysql_error()."","erro");

}

header("Location: /admin/admin-configuracoes");
exit();
}

$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
<script type="text/javascript">
   window.onload = function() {
	setTimeout("window.location.reload(true);",300000);   };
</script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo" style="background:url(/admin/img/img-logo-painel.gif) no-repeat left;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li>&nbsp;&nbsp;&nbsp;</li>
        <li><a href="/admin/admin-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/admin-streamings" class="texto_menu">Streamings</a></li>
  		<li><em></em><a href="/admin/admin-cadastrar-revenda" class="texto_menu">Cadastrar Revenda</a></li>
  		<li><em></em><a href="/admin/admin-revendas" class="texto_menu">Revendas</a></li>
        <li><em></em><a href="/admin/admin-cadastrar-servidor" class="texto_menu">Cadastrar Servidor</a></li>
        <li><em></em><a href="/admin/admin-servidores" class="texto_menu">Servidores</a></li>
        <li><em></em><a href="/admin/admin-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <form method="post" action="/admin/admin-configuracoes" style="padding:0px; margin:0px">
    <table width="500" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      <tr>
        <td width="150" height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">IP Painel de Controle</td>
        <td width="350" align="left"><input name="ip_painel" type="text" class="input" id="ip_painel" style="width:250px;" value="<?php echo $dados_config["ip_painel"]; ?>" /></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Chave API Google Maps</td>
        <td align="left"><input name="chave_api_google_maps" type="text" class="input" id="chave_api_google_maps" style="width:250px;" value="<?php echo $dados_config["chave_api_google_maps"]; ?>" /></td>
      </tr>

       <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Rodom na escolha dos servidores</td>
        <td align="left">
         <select name="rodom" class="input" id="rodom" style="width:235px;">
         <option value="0"<?php if($dados_config["rodom"] == "0") { echo ' selected="selected"'; } ?>>N�O</option>
         <option disabled value"1"<?php if($dados_config["rodom"] == "1") { echo ' selected="selected"'; } ?>"disabled="disabled">SIM</option>
         
        </select></td>
      </tr>
<tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Listas de IDs</td>
        <td align="left">
<textarea name="rodomid" id="rodomid"  rows="5" cols="33"><?php

$query = mysql_query("SELECT codigo,ip,nome FROM servidores WHERE loadserver = 'sim'  ORDER by codigo ASC");
while ($dados_servidor = mysql_fetch_array($query)) {

echo '"' . $dados_servidor["codigo"] . '",';

}
?>
</textarea>


</td>
      </tr>
    


      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Servidor Atual</td>
        <td align="left">
          <select name="codigo_servidor_atual" class="input" id="codigo_servidor_atual" style="width:255px;">
            <?php

$query = mysql_query("SELECT codigo,ip,nome FROM servidores WHERE tipo = 'streaming' ORDER by codigo ASC");
while ($dados_servidor = mysql_fetch_array($query)) {

$total_streamings = mysql_num_rows(mysql_query("SELECT * FROM streamings where codigo_servidor = '".$dados_servidor["codigo"]."'"));

if($dados_servidor["codigo"] == $dados_config["codigo_servidor_atual"]) {
echo '<option value="' . $dados_servidor["codigo"] . '" selected="selected">' . $dados_servidor["nome"] . ' - ' . $dados_servidor["ip"] . ' (' . $total_streamings . ')</option>';
} else {
echo '<option value="' . $dados_servidor["codigo"] . '">' . $dados_servidor["nome"] . ' - ' . $dados_servidor["ip"] . ' (' . $total_streamings . ')</option>';
}

}
?>
          </select>          </td>
      </tr>




      <tr>
        <td height="40">
        <input name="alterar_dados" type="hidden" id="alterar_dados" value="sim" />
       
        </td>
        <td align="left">
          <input type="submit" class="botao" value="Alterar Dados" />
          <input type="button" class="botao" value="Cancelar" onclick="window.location = '/admin/RooT-configuracoes';" />        </td>
      </tr>
    </table>
  </form>
</div>

</body>
</html>
