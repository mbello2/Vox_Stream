// Fun��es Gerais
function get_host() {

var url = location.href;
url = url.split("/");

return url[2];

}

function abrir_janela( url,largura,altura ) {

window.open( url, "","width="+largura+",height="+altura+",toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=NO" );

}

function executar_acao_streaming( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "ligar") {
		ligar_streaming( codigo );
	} else if(acao == "desligar") {
		desligar_streaming( codigo );
	} else if(acao == "configurar") {
		window.location = "/configurar-streaming/"+codigo+"";
	} else if(acao == "player") {
		carregar_lista_players_streaming( codigo );
	} else if(acao == "ouvintes-conectados") {
		abrir_janela( "/ouvintes-conectados/"+codigo+"",720,600 );
	} else if(acao == "estatisticas") {
		window.location = "/estatisticas/"+codigo+"";
	} else if(acao == "kick") {
		kick_streaming( codigo );
	} else if(acao == "ativar-protecao") {
		
		if(window.confirm("Aten��o! Ative esta prote��o somente se esta porta estiver sofrendo ataques.\n\nDeseja realmente ativar a prote��o para este streaming?")) {
			ativar_protecao( codigo );
		} else {
			return false;
		}
		
	} else if(acao == "ligar-autodj") {
		carregar_playlists( codigo );
	} else if(acao == "pular-musica") {
		pular_musica( codigo );
	} else if(acao == "recarregar-playlist") {
		recarregar_playlist( codigo );
	} else if(acao == "desligar-autodj") {
		desligar_autodj( codigo );
	} else if(acao == "gerenciar-musicas") {
		abrir_janela( "/gerenciar-musicas/"+codigo+"",720,550 );
	} else if(acao == "gerenciar-playlist") {
		abrir_janela( "/gerenciar-playlists/"+codigo+"",800,500 );
	} else if(acao == "gerenciar-djs") {
		window.location = "/gerenciar-djs/"+codigo+"";
	} else if(acao == "remover-dj") {
		remover_dj( codigo );
	} else if(acao == "remover-multpoint") {
		remover_multpoint( codigo );
	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";

}

function executar_acao_streaming_movel( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "ligar") {
		ligar_streaming( codigo );
	} else if(acao == "desligar") {
		desligar_streaming( codigo );
	} else if(acao == "kick") {
		kick_streaming( codigo );
	} else if(acao == "ligar-autodj") {
		carregar_playlists( codigo );
	} else if(acao == "pular-musica") {
		pular_musica( codigo );
	} else if(acao == "recarregar-playlist") {
		recarregar_playlist( codigo );
	} else if(acao == "desligar-autodj") {
		desligar_autodj( codigo );
	}

	document.getElementById(codigo).value = "";

}

function executar_acao_streaming_admin( codigo,acao ) {
	
	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "ligar") {
		ligar_streaming( codigo );
	} else if(acao == "desligar") {
		desligar_streaming( codigo );
	} else if(acao == "configurar") {
		window.location = "/admin/admin-configurar-streaming/"+codigo+"";
	} else if(acao == "player") {
		carregar_lista_players_streaming( codigo );
	} else if(acao == "ouvintes-conectados") {
		abrir_janela( "/ouvintes-conectados/"+codigo+"",720,600 );
	} else if(acao == "kick") {
		kick_streaming( codigo );
	} else if(acao == "ativar-protecao") {
		
		if(window.confirm("Aten��o! Ative esta prote��o somente se esta porta estiver sofrendo ataques.\n\nDeseja realmente ativar a prote��o para este streaming?")) {
			ativar_protecao( codigo );
		} else {
			return false;
		}
	} else if(acao == "sincronizar-aacplus") {
		sincronizar_aacplus( codigo );	
	} else if(acao == "ligar-autodj") {
		carregar_playlists( codigo );
	} else if(acao == "pular-musica") {
		pular_musica( codigo );
	} else if(acao == "recarregar-playlist") {
		recarregar_playlist( codigo );
	} else if(acao == "desligar-autodj") {
		desligar_autodj( codigo );
	} else if(acao == "bloquear") {
		bloquear_streaming( codigo );
	} else if(acao == "desbloquear") {
		desbloquear_streaming( codigo );
	} else if(acao == "remover") {

		if(window.confirm("Deseja realmente remover este streaming?")) {
			remover_streaming( codigo );
		} else {
			return false;
		}

	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";

}

function executar_acao_streaming_revenda( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "ligar") {
		ligar_streaming( codigo );
	} else if(acao == "desligar") {
		desligar_streaming( codigo );
	} else if(acao == "configurar") {
		window.location = "/admin/revenda-configurar-streaming/"+codigo+"";
	} else if(acao == "player") {
		carregar_lista_players_streaming( codigo );
	} else if(acao == "ouvintes-conectados") {
		abrir_janela( "/ouvintes-conectados/"+codigo+"",720,600 );
	} else if(acao == "kick") {
		kick_streaming( codigo );
	} else if(acao == "ativar-protecao") {
		
		if(window.confirm("Aten��o! Ative esta prote��o somente se esta porta estiver sofrendo ataques.\n\nDeseja realmente ativar a prote��o para este streaming?")) {
			ativar_protecao( codigo );
		} else {
			return false;
		}
	} else if(acao == "sincronizar-aacplus") {
		sincronizar_aacplus( codigo );	
	} else if(acao == "ligar-autodj") {
		carregar_playlists( codigo );
	} else if(acao == "pular-musica") {
		pular_musica( codigo );
	} else if(acao == "recarregar-playlist") {
		recarregar_playlist( codigo );
	} else if(acao == "desligar-autodj") {
		desligar_autodj( codigo );
	} else if(acao == "bloquear") {
		bloquear_streaming( codigo );
	} else if(acao == "desbloquear") {
		desbloquear_streaming( codigo );
	} else if(acao == "remover") {

		if(window.confirm("Deseja realmente remover este streaming?")) {
			remover_streaming( codigo );
		} else {
			return false;
		}

	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";

}

function executar_acao_revenda( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "bloquear") {
		bloquear_revenda( codigo );
	} else if(acao == "desbloquear") {
		desbloquear_revenda ( codigo );
	} else if(acao == "configurar") {
		window.location = "/admin/admin-configurar-revenda/"+codigo+"";
	} else if(acao == "listar-streamings") {
		window.location = "/admin/admin-streamings/resultado-revenda/"+codigo+"";
	} else if(acao == "alterar-servidor") {
		window.location = "/admin/admin-alterar-servidor-streaming-revenda/"+codigo+"";
	} else if(acao == "exportar-lista-streamings") {
		window.location = "/admin/admin-exportar-streamings-revenda/"+codigo+"";
	} else if(acao == "remover") {

		if(window.confirm("Deseja realmente remover esta revenda?")) {
			remover_revenda( codigo );
		} else {
			return false;
		}

	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";
}

function executar_acao_servidor( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "ligar") {
		ligar_streamings_servidor( codigo );
	} else if(acao == "ligar-autodjs") {
		ligar_autodjs_servidor( codigo );
	} else if(acao == "ativar-manutencao") {
		var mensagem = prompt('Informe a mensagem de manuten��o a ser exibida no painel de streaming:','Seu servidor esta offline neste momento. Nossa equipe j� esta trabalhando na solu��o do problema, por favor aguarde.');
		manutencao_servidor( codigo, "ativar", mensagem  );
	} else if(acao == "desativar-manutencao") {
		manutencao_servidor( codigo, "desativar", "" );
	} else if(acao == "desligar") {
		
		if(window.confirm("Deseja realmente desligar todos os streamings deste servidor?")) {
			desligar_streamings_servidor( codigo );
		}		
		
	} else if(acao == "listar-streamings") {
		window.location = "/admin/admin-streamings/resultado-servidor/"+codigo+"";
	} else if(acao == "sincronizar-aacplus") {
		sincronizar_aacplus_servidor( codigo );
	} else if(acao == "exportar-lista-streamings") {
		window.location = "/admin/admin-exportar-streamings-servidor/"+codigo+"";
	} else if(acao == "alterar-servidor") {
		window.location = "/admin/admin-alterar-servidor-streaming/"+codigo+"";
	} else if(acao == "configurar") {
		window.location = "/admin/admin-configurar-servidor/"+codigo+"";
	} else if(acao == "remover") {

		if(window.confirm("Deseja realmente remover este servidor?")) {
			window.location = "/admin/admin-remover-servidor/"+codigo+"";
		}

	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";
}


function executar_acao_diversa( codigo,acao ) {

	if(acao == "") {
		alert("Escolha a a��o a ser executada!");
	} else if(acao == "remover-dica-rapida") {
		remover_dica_rapida( codigo );
	} else if(acao == "remover-dica-rapida") {
		remover_dica_rapida( codigo );
	} else if(acao == "alterar-status-aviso") {
		alterar_status_aviso( codigo );
	} else if(acao == "remover-aviso") {
		remover_aviso( codigo );	
	} else {
		abrir_janela( acao,720,500 );
	}

	document.getElementById(codigo).value = "";
}

function mover_musica(listID, direction) {

	var listbox = document.getElementById(listID);
	var selIndex = listbox.selectedIndex;

	if(-1 == selIndex) {
		alert("Por favor selecione uma m�sica!");
		return;
	}

	var increment = -1;
	if(direction == 'up')
		increment = -1;
	else
		increment = 1;

	if((selIndex + increment) < 0 ||
		(selIndex + increment) > (listbox.options.length-1)) {
		return;
	}

	var selValue = listbox.options[selIndex].value;
	var selText = listbox.options[selIndex].text;
	listbox.options[selIndex].value = listbox.options[selIndex + increment].value
	listbox.options[selIndex].text = listbox.options[selIndex + increment].text

	listbox.options[selIndex + increment].value = selValue;
	listbox.options[selIndex + increment].text = selText;

	listbox.selectedIndex = selIndex + increment;
}

function selecionar_tudo(campo) {

	var tamanho = document.getElementById( campo ).length;

	for(var i = 0; i < tamanho; i++) {
		document.getElementById( campo ).options[i].selected=true;
	}

}

function remover_tudo(campo) {

	var tamanho = document.getElementById( campo ).length;

	for(var i = 0; i < tamanho; i++) {
		document.getElementById(campo ).remove(document.getElementById( campo ).options[i]);
	}

}

function checar_status_streamings( streamings ) {
  
  array_streamings = streamings.split("|");
  
  for(var cont = 0; cont < array_streamings.length; cont++) {
  
  var porta = array_streamings[cont];
  
  if(porta) {
  
  status_streaming( porta );
  
  }
  
  }

}

// Fun��o para carregar a configura��o do plano de streaming/revenda pr�-definido
function configuracao_plano( configuracoes,tipo ) {
  
  if(configuracoes) {
  
  array_configuracoes = configuracoes.split("|");
  
  if(tipo == "streaming") {
	  
  document.getElementById("ouvintes").value = array_configuracoes[0];
  document.getElementById("bitrate").value = array_configuracoes[1];
  document.getElementById("espaco").value = array_configuracoes[2];
  
  } else {
  
  document.getElementById("streamings").value = array_configuracoes[0];
  document.getElementById("ouvintes").value = array_configuracoes[1];
  document.getElementById("bitrate").value = array_configuracoes[2];
  document.getElementById("espaco").value = array_configuracoes[3];
  
  }
  
  }
  
}

// Fun��o para carregar a configura��o do cliente(revenda)
function configuracao_revenda( configuracoes ) {
  
  if(configuracoes) {
  
  array_configuracoes = configuracoes.split("|");
  
  document.getElementById("nome").value = array_configuracoes[0];
  document.getElementById("email").value = array_configuracoes[1];
  document.getElementById("senha").value = array_configuracoes[2];
  
  }
  
}

function tipo_estatistica( tipo ) {
	
  document.getElementById("tabela_data").style.display = "block";
  
  if(tipo == "3" || tipo == "4") {  
  document.getElementById("tabela_data").style.display = "none";  
  }  
  
}

function adicionar_musica(ctrlSource, ctrlTarget) {
	
  var Source = document.getElementById(ctrlSource);
  var Target = document.getElementById(ctrlTarget);
  
  if (Target.selectedIndex >= 0) {
	var curOption = Target.options[Target.selectedIndex+1]; 
  } else {
	var curOption = Target.options[Target.length+1]; 
  }
  
  for(var i = 0; i < Source.length; i++) {
	  
    if(Source.options[i].selected === true) {
		
    var newOption = document.createElement('option');
    newOption.text = Source.options[i].text;
    newOption.value = Source.options[i].value;

    try {
      Target.add(newOption, curOption); // standards compliant; doesn't work in IE
    }
    catch(ex) {
      Target.add(newOption, Target.selectedIndex); // IE only
    }
	
	}
  }
  
}

function buscar_streaming(porta,painel) {

window.location = "/admin/"+painel+"-streamings/resultado/"+porta;

}

function buscar_revenda(chave) {

window.location = "/admin/admin-revendas/resultado/"+chave;

}

function buscar_servidor(chave) {

window.location = "/admin/admin-servidores/resultado/"+chave;

}

function selecionar_servidor(codigo_servidor) {
	
for(var x=0; x < document.frm.servidor_novo.length; x++) {

	for(var y=0; y < document.frm.servidor_novo[x].length; y++) {

		if(document.frm.servidor_novo[x].options[y].value == codigo_servidor) {
			document.frm.servidor_novo[x].options[y].selected = true;
		}
	}
}

}

function configurar_aacplus_streaming( opcao, servidor_aacplus ) {
	
if(opcao == "sim") {

document.getElementById("servidor_aacplus").value = servidor_aacplus;
document.getElementById("encoder").value = "aacp";

} else {

document.getElementById("encoder").value = "mp3";
document.getElementById("servidor_aacplus").value = "0";
	
}

}

function configurar_aacplus_revenda( opcao ) {
	
if(opcao == "sim") {

document.getElementById("encoder").value = "aacp";

} else {

document.getElementById("encoder").value = "mp3";
	
}

}

function valida_opcoes_frequencia( frequencia ) {
	
document.getElementById("data").disabled = true;

for(var cont = 0; cont < document.agendamentos.dias.length; cont++) {
document.agendamentos.dias[cont].disabled = true;
}

if(frequencia == "1") {
document.getElementById("data").disabled = false;
}

if(frequencia == "3") {

for(var cont = 0; cont < document.agendamentos.dias.length; cont++) {
document.agendamentos.dias[cont].disabled = false;
}

}

}

// Fun��o para mascarar campos
function txtBoxFormat(objeto, sMask, evtKeyPress) {
    var i, nCount, sValue, fldLen, mskLen,bolMask, sCod, nTecla;

if(document.all) { // Internet Explorer
    nTecla = evtKeyPress.keyCode;
} else if(document.layers) { // Nestcape
    nTecla = evtKeyPress.which;
} else {
    nTecla = evtKeyPress.which;
    if (nTecla == 8) {
        return true;
    }
}

    sValue = objeto.value;

    // Limpa todos os caracteres de formata��o que
    // j� estiverem no campo.
    sValue = sValue.toString().replace( "-", "" );
    sValue = sValue.toString().replace( "-", "" );
    sValue = sValue.toString().replace( ".", "" );
    sValue = sValue.toString().replace( ".", "" );
    sValue = sValue.toString().replace( "/", "" );
    sValue = sValue.toString().replace( "/", "" );
    sValue = sValue.toString().replace( ":", "" );
    sValue = sValue.toString().replace( ":", "" );
    sValue = sValue.toString().replace( "(", "" );
    sValue = sValue.toString().replace( "(", "" );
    sValue = sValue.toString().replace( ")", "" );
    sValue = sValue.toString().replace( ")", "" );
    sValue = sValue.toString().replace( " ", "" );
    sValue = sValue.toString().replace( " ", "" );
    fldLen = sValue.length;
    mskLen = sMask.length;

    i = 0;
    nCount = 0;
    sCod = "";
    mskLen = fldLen;

    while (i <= mskLen) {
      bolMask = ((sMask.charAt(i) == "-") || (sMask.charAt(i) == ".") || (sMask.charAt(i) == "/") || (sMask.charAt(i) == ":"))
      bolMask = bolMask || ((sMask.charAt(i) == "(") || (sMask.charAt(i) == ")") || (sMask.charAt(i) == " "))

      if (bolMask) {
        sCod += sMask.charAt(i);
        mskLen++; }
      else {
        sCod += sValue.charAt(nCount);
        nCount++;
      }

      i++;
    }

    objeto.value = sCod;

    if (nTecla != 8) { // backspace
      if (sMask.charAt(i-1) == "9") { // apenas n�meros...
        return ((nTecla > 47) && (nTecla < 58)); }
      else { // qualquer caracter...
        return true;
      }
    }
    else {
      return true;
    }
}

// Fun��o para bloquear acentos
function bloquear_acentos( texto ) {
	
    var NaoPode = new RegExp( /\W/gi );
    var resultado = NaoPode.exec( texto.value );
    if ( resultado ) {
        alert( "Aten��o! N�o use acentos ou car�cteres especiais." );
        texto.value = texto.value.substring( 0 , ( texto.value.length - 1 ) );
    }
}

// Fun��o para contar a quantidade de caracteres digitados num campo
function contar_caracteres( campo, maximo ) {
	
	var total_digitado = document.getElementById(campo).value.length;	
	document.getElementById('total_caracteres').innerHTML = maximo - total_digitado;

}