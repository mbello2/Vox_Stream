<?php

function envia_Email($nome_cliente,$email_cliente1,$email_cliente2,$assunto,$mensagem) {

require_once('classe.phpmailer.php');

$mail = new PHPMailer();
$mail->IsSMTP(); // set mailer to use SMTP
$mail->Host = "XXXXX"; // specify main and backup server
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->Username = "XXXXXX"; // SMTP username
$mail->Password = "XXXXX"; // SMTP password

$mail->From = $email_cliente1;
$mail->FromName = "Streaming";
$mail->AddAddress($email_cliente1, $nome_cliente);
if($email_cliente2) {
$mail->AddCC($email_cliente2, $nome_cliente); // Com c�pia
}
$mail->IsHTML(true); // set email format to HTML

$mail->Subject = $assunto;
$mail->Body = $mensagem;

if($mail->Send()){
return "ok";
} else {
return $mail->ErrorInfo;
}

}
?>