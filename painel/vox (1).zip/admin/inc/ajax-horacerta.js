////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Playlist /////////////
////////////////////////////////////////////////////////
// Fun��o para remover acentos no auto dj
function remover_acentos( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_acentos/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}
// Fun��o para carregar as playlists
function carregar_playlists( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Limpa a lista de playlist j� carregadas
  document.getElementById("lista-playlists").innerHTML = "";
  
  document.getElementById("status_lista_playlists").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("status_lista_playlists").style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_lista_playlists/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_playlists = resultado.split(";");
	
	for(var cont = 0; cont < array_playlists.length; cont++) {	
	 
	if(array_playlists[cont]) {
	
	dados_playlist = array_playlists[cont].split("|");
	
	var nova_playlist = document.createElement("li");
  
    nova_playlist.innerHTML = "<img src='/admin/img/icones/img-icone-pasta-playlist.png' align='absmiddle' />&nbsp;<a href='javascript:carregar_musicas_playlist(\""+dados_playlist[0]+"\");'>"+dados_playlist[1]+"&nbsp;("+dados_playlist[2]+")</a><a href='javascript:remover_playlist(\""+dados_playlist[0]+"\")' style='float:right;'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover' title='Remover' border='0' /></a>";
  
    document.getElementById("lista-playlists").appendChild(nova_playlist);
	
	document.getElementById("status_lista_playlists").style.display = "none";
	document.getElementById("log-sistema-fundo").style.display = "none";
    document.getElementById("log-sistema").style.display = "none";
	
	}
	
	}
	
	} else {
	
	document.getElementById("status_lista_playlists").innerHTML = "Nenhuma playlist encontrada.";
	
	}
  
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar as pastas
function carregar_pastas( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Limpa a lista de playlist j� carregadas
  document.getElementById("lista-pastas").innerHTML = "";
  
  document.getElementById("status_lista_pastas").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("status_lista_pastas").style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_lista_pastas/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_pastas = resultado.split(";");
	
	for(var cont = 0; cont < array_pastas.length; cont++) {	
	 
	if(array_pastas[cont]) {
	
	dados_pasta = array_pastas[cont].split("|");
	
	var nova_pasta = document.createElement("li");
	
	nova_pasta.innerHTML = "<img src='/admin/img/icones/img-icone-pasta.png' align='absmiddle' />&nbsp;<a href='javascript:carregar_musicas_pasta(\""+porta+"\",\""+dados_pasta[0]+"\");'>"+dados_pasta[0]+"&nbsp;("+dados_pasta[1]+")</a>";
  
    document.getElementById("lista-pastas").appendChild(nova_pasta);
	
	document.getElementById("status_lista_pastas").style.display = "none";
	
	}
	
	}
	
	} else {
	
	document.getElementById("status_lista_playlists").innerHTML = "Nenhuma pasta encontrada.";
	
	}
  
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar as m�sicas da pasta do FTP no gerenciamento de playlist
function carregar_musicas_pasta( porta,pasta ) {
	
  if(porta == "" || pasta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Limpa a lista de m�sicas j� carregadas
  document.getElementById("lista-musicas-pasta").innerHTML = "";
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  document.getElementById("msg_pasta").style.display = "none";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_musicas_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_musicas = resultado.split(";");
	
	for(var cont = 0; cont < array_musicas.length; cont++) {	
	 
	if(array_musicas[cont]) {
	
	dados_musica = array_musicas[cont].split("|");
	
	var nova_musica = document.createElement("li");
    if(playlist == "") {  
    alert("Aten��o! Voc� deve clicar em uma playlist abaixo para seleciona-la esta m�sica.");  
    } else {
    nova_musica.innerHTML = "<input id='musicas_pasta' type='checkbox' value='"+dados_musica[0]+"' style='display:none' checked /><img src='/admin/img/icones/img-icone-arquivo-musica.png' border='0' align='absmiddle' />&nbsp;<a href='javascript:adicionar_musica_playlist(\""+dados_musica[0]+"\",\""+dados_musica[1]+"\");'>"+dados_musica[1]+"</a><a href='javascript:adicionar_vinheta(\""+dados_musica[0]+"\",\""+dados_musica[1]+"\");' title='Adicionar como Vinheta' style='float:right;'><img src='/admin/img/icones/img-icone-vinheta.png' width='16' height='16' alt='Adicionar como Vinheta' border='0' align='absmiddle' /></a>";
  
    document.getElementById("lista-musicas-pasta").appendChild(nova_musica);
	
	document.getElementById("log-sistema-fundo").style.display = "none";
    document.getElementById("log-sistema").style.display = "none";
	}
	}
	
	}
	
	} else {
	


	document.getElementById("msg_pasta").innerHTML = "A pasta selecionada n�o possui m�sicas. Voc� deve enviar as m�sicas usando FTP ou gerenciador de m�sicas.";
	document.getElementById("msg_pasta").style.display = "block";
	document.getElementById("log-sistema-fundo").style.display = "none";
    document.getElementById("log-sistema").style.display = "none";
	
	}
  
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar as m�sicas da playlist
function carregar_musicas_playlist( playlist ) {
	
  if(playlist == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Seleciona a playlist
  document.getElementById("playlist").value = playlist;
  
  // Limpa as m�sicas da �ltima playlist selecionada
  limpar_lista_musicas('playlist');
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<font color=\"#FF0000\">ISSO PODE LEVAR ALGUNS MINUTOS,POR FAVOR, AGUARDE...</font><br><img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  document.getElementById("msg_playlist").style.display = "none";

  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_musicas_playlist/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_musicas = resultado.split(";");
	
	for(var cont = 0; cont < array_musicas.length; cont++) {	
	 
	if(array_musicas[cont]) {
	
	dados_musica = array_musicas[cont].split("|");
	
	adicionar_musica_playlist( dados_musica[0],dados_musica[1] );
	
	document.getElementById("log-sistema-fundo").style.display = "none";
    document.getElementById("log-sistema").style.display = "none";
	
	quantidade_musicas_playlist();
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>Ocorreu um erro ao tentar carregar as m�sicas, tente novamente.</span>";
	}
	
	}
	
	} else {
	
	document.getElementById("msg_playlist").innerHTML = "A playlist selecionada n�o possui m�sicas cadastradas para serem exibidas.";
	document.getElementById("msg_playlist").style.display = "block";
	document.getElementById("log-sistema-fundo").style.display = "none";
    document.getElementById("log-sistema").style.display = "none";
	
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}







// Fun��o para criar uma nova playlist
function criar_playlist( porta ) {
  
  var playlist = prompt("Informe um nome para a nova playlist:\n(N�o use caracteres especiais e acentos)");
	
  if(playlist != "" && playlist != null) {
  
  document.getElementById("status_lista_playlists").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("status_lista_playlists").style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/criar_playlist/"+porta+"/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ok") {

    carregar_playlists( porta );
	
	} else {
	
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel criar a playlist, tente novamente ou contate o suporte.</span>";
	document.getElementById("log-sistema-fundo").style.display = "block";
    document.getElementById("log-sistema").style.display = "block";	
	
	}
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para adicionar uma musica do FTP na playlist
function adicionar_musica_playlist( path,musica ) {
if(playlist == "") {  
  alert("Aten��o! Voc� deve clicar em uma playlist para seleciona-la e s� ent�o adicionar as m�sicas.");  
  } else {	
  if(path == "" && musica == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById("msg_playlist").style.display = "none";
  
  var lista_musicas = document.getElementById("lista-musicas-playlist");
  
  var total_musicas = 0;
  
  for (var i = 0; i < lista_musicas.childNodes.length; i++) {
        if (lista_musicas.childNodes[i].nodeName == "LI") {
          total_musicas++;
        }
  }
  
  var novo_id = (total_musicas+1);
   }
  //alert("Total: "+lista_musicas.childNodes.length+"\nM�sicas: "+total_musicas+"\nNovo ID: "+novo_id+"");
  var nova_musica = document.createElement("li");
  
  nova_musica.setAttribute("id",novo_id);
  nova_musica.setAttribute("class","musica");
  
  nova_musica.innerHTML = "<input name='musicas_adicionadas[]' type='checkbox' value='"+path+"' style='display:none' checked /><img src='/admin/img/icones/img-icone-arquivo-musica.png' border='0' align='absmiddle' />&nbsp;"+musica+"<a href='javascript:remover_musica(\""+novo_id+"\")' style='float:right;'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover' title='Remover' border='0' align='absmiddle' /></a>";
  
  document.getElementById("lista-musicas-playlist").appendChild(nova_musica);
  
  quantidade_musicas_playlist();
  
  setListeners();
  
  }  
  
  
}

// Fun��o para adicionar todas as musicas do FTP na playlist
function adicionar_tudo() {
  if(playlist == "") {  
  alert("Aten��o! Voc� deve clicar em uma playlist para seleciona-la e s� ent�o adicionar estas m�sicas.]");  
  } else {
  var lista_musicas_pasta = document.forms["gerenciador"].elements["musicas_pasta"];
  
  for (var i = 0; i < lista_musicas_pasta.length; i++) {
  
  var path = lista_musicas_pasta[i].value;
  
  var musica = path.split("/");
  
  adicionar_musica_playlist( path,musica[1] );

  }  
  
}
  }
// Fun��o para remover uma m�sica de uma playlist
function remover_musica( id ) {
  
  // Remove a m�sica da lista
  document.getElementById("lista-musicas-playlist").removeChild(document.getElementById(id));

}

// Fun��o para remover uma playlist
function remover_playlist( playlist ) {
	
  if(playlist == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  if(window.confirm("Deseja realmente remover esta playlist e todas as suas m�sicas?")) {
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_playlist/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  }
  
  }
}

// Fun��o para renomear uma musica no FTP
function renomear_musica_ftp( porta,musica,novo ) {

  if(musica == "") {  
  alert("Aten��o! Voc� deve clicar na m�sica que deseja renomear.");  
  } else {
	  
  novo = prompt ("Informe o novo nome para a m�sica:\n(N�o use caracteres especiais e acentos)");
  
  if(novo != "" && novo != null) {
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  
  var musica = musica.replace("/", "|");
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/renomear_musica_ftp/"+porta+"/"+musica+"/"+novo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  
  }
  
  }
}

// Fun��o para remover uma musica no FTP
function remover_musica_ftp( porta,musica ) {

  if(musica == "") {  
  alert("Aten��o! Voc� deve selecionar a m�sica que deseja remover.");  
  } else {
  
  if(window.confirm("Deseja realmente remover esta m�sica?")) {
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  
  var musica = musica.replace("/", "|");
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_musica_ftp/"+porta+"/"+musica , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  }
  }
}

// Fun��o para limpar a lista de m�sicas
function limpar_lista_musicas( local ) {

  if(local == "ftp") {
  
  document.getElementById("msg_pasta").innerHTML = "Clique na pasta ao lado para carregar as m�sicas.";
  document.getElementById("lista-musicas-pasta").innerHTML = "";
  document.getElementById("msg_pasta").style.display = "block";
  
  } else {
  
  document.getElementById("msg_playlist").innerHTML = "Clique na playlist ao lado para carregar as m�sicas ou adicione as m�sicas de uma pasta acima.";
  document.getElementById("lista-musicas-playlist").innerHTML = "";
  document.getElementById("msg_playlist").style.display = "block";
    
  quantidade_musicas_playlist();
  
  }
  
}

// Fun��o para adicionar vinheta na playlist(intercalar uma m�sica)
function adicionar_vinheta( path,musica ) {
   if(playlist == "") {  
   alert("Aten��o! Voc� deve clicar em uma playlist para seleciona-la e s� ent�o adicionar esta vinheta/m�sica.");  
   } else {
  var frequencia = parseInt(prompt("REPETIR ESTA M�SICA/VINHETA ENTRE AS OUTRAS NA PLAYLIST ABAIXO, INFORME QUANTAS VEZES DESEJA REPETIR?\nExemplo: 5"));
  
  var lista_musicas = document.getElementById("lista-musicas-playlist");
	
  var total_musicas = 0;
  
  for (var i = 0; i < lista_musicas.childNodes.length; i++) {
    if (lista_musicas.childNodes[i].nodeName == "LI") {
      total_musicas++;
    }
	
  }
	
  var listafilhos = lista_musicas.getElementsByTagName("li");
	
  for(i=frequencia, x=1; i<=listafilhos.length; i+=frequencia+1, x++) {
		
    if(novo_id) {
      var novo_id = (novo_id+1);
    } else {
      var novo_id = (total_musicas+1);
    }
		
    var nova_musica = document.createElement("li");
		
    nova_musica.setAttribute("id",novo_id);
    nova_musica.setAttribute("class","musica");
  
    nova_musica.innerHTML = "<input name='musicas_adicionadas[]' type='checkbox' value='"+path+"' style='display:none' checked /><img src='/admin/img/icones/img-icone-arquivo-musica.png' border='0' align='absmiddle' />&nbsp;"+musica+"<a href='javascript:remover_musica(\""+novo_id+"\")' style='float:right;'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover' title='Remover' border='0' align='absmiddle' /></a>";
		
    if (i == listafilhos.length) {
      lista_musicas.appendChild(nova_musica);
    } else {
      lista_musicas.insertBefore(nova_musica, listafilhos[i]);
    }
	
	quantidade_musicas_playlist();
	
	setListeners();
	
  }
 
}
    }
// Fun��o para adicionar vinheta na playlist(intercalar uma m�sica)
function adicionar_horacerta( path,musica ) {
  var playlist = document.getElementById("playlist").value;
  
  if(playlist == "") {  
  alert("Aten��o! Voc� deve clicar em uma playlist para seleciona-la e s� ent�o adicionar a hora certa.");  
  } else {
  var frequencia = parseInt(prompt("EXECUTAR A HORA CERTA CADA QUANTAS M�SICAS?:\nExemplo: 5"));
  
  var lista_musicas = document.getElementById("lista-musicas-playlist");
	
  var total_musicas = 0;
  
  for (var i = 0; i < lista_musicas.childNodes.length; i++) {
    if (lista_musicas.childNodes[i].nodeName == "LI") {
      total_musicas++;
    }
  }
	
  var listafilhos = lista_musicas.getElementsByTagName("li");
	
  for(i=frequencia, x=1; i<=listafilhos.length; i+=frequencia+1, x++) {
		
    if(novo_id) {
      var novo_id = (novo_id+1);
    } else {
      var novo_id = (total_musicas+1);
    }
		
    var nova_musica = document.createElement("li");
		
    nova_musica.setAttribute("id",novo_id);
    nova_musica.setAttribute("class","musica");
  
    nova_musica.innerHTML = "<input name='musicas_adicionadas[]' type='checkbox' value='"+path+"' style='display:none' checked /><img src='/admin/img/icones/img-icone-arquivo-musica.png' border='0' align='absmiddle' />&nbsp;"+musica+"<a href='javascript:remover_musica(\""+novo_id+"\")' style='float:right;'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover' title='Remover' border='0' align='absmiddle' /></a>";
	document.getElementById("log-sistema-conteudo").innerHTML = "<font color=\"#FF0000\">ISSO PODE LEVAR ALGUNS MINUTOS,POR FAVOR, AGUARDE...</font><br><img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";	
    if (i == listafilhos.length) {
      lista_musicas.appendChild(nova_musica);
    } else {
      lista_musicas.insertBefore(nova_musica, listafilhos[i]);
    }
	
	quantidade_musicas_playlist();
	
	setListeners();
	}
  }
 
}

// Fun��o para contar a quantidade de m�sicas na playlist
function quantidade_musicas_playlist() {

  var lista_musicas = document.getElementById("lista-musicas-playlist");
  
  var total_musicas = 0;

  for (var i = 0; i < lista_musicas.childNodes.length; i++) {
        if (lista_musicas.childNodes[i].nodeName == "LI") {
          total_musicas++;
        }
  }
  
  document.getElementById("quantidade_musicas_playlist").innerHTML = "("+total_musicas+")";

}

// Fun��o para misturar playlist

function shuffle( ) {
 
       var arr = document.getElementById('lista-musicas-playlist').innerHTML;
       document.getElementById('lista-musicas-playlist').innerHTML =" ";{
   shuffle = function(o){ //v1.0
   for(var j, x, i = o.length; i; j = parseInt(Math.random() * n), x = o[--i], o[i] = o[j], o[j] = x);
   return o;
};    
newArray = shuffle(nums);
document.getElementById('lista-musicas-playlist').innerHTML +=newArray;
 
 
}
}
   



// Fun��o para salvar a playlist
function salvar_playlist() {
  
  var playlist = document.getElementById("playlist").value;
  
  if(playlist == "") {  
  alert("Aten��o! Voc� deve clicar em uma playlist para seleciona-la e adicionar as m�sicas para s� ent�o salvar a playlist.");  
  } else {
  
  document.getElementById("log-sistema-conteudo").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("log-sistema-fundo").style.display = "block";
  document.getElementById("log-sistema").style.display = "block";
  
  document.gerenciador.submit();
  }

}

// Fun��o para obter o host
function get_host() {

var url = location.href;
url = url.split("/");

return url[2];

}

// Fun��o Drag&Drop para organizar as m�sicas da playlist
var zxcMseX, zxcMseY;

function zxcMove(event, zxcobj){
    var tgt;
    if (!event) var event = window.event;
    if (event.target) tgt = event.target;
    else if (event.srcElement) tgt = event.srcElement;
    if (tgt.nodeType == 3) tgt = tgt.parentNode;
    if (tgt.tagName != 'A' && tgt.tagName != 'IMG')
    {
        var zxcels = zxcobj.parentNode.getElementsByTagName(zxcobj.tagName);

        zxcobj.ary = [];    
        for (var zxc0 = 0; zxc0 < zxcels.length; zxc0++)
        {
            zxcobj.ary.push(zxcels[zxc0]);
        }
    
        zxcMseDown(event, zxcobj);
    }
}

function zxcMseDown(event, obj)
{
    document.onmousemove = function(event)
    {
        zxcDrag(event);
    }
    document.onmouseup = function(event)
    {
        zxcMseUp(event);
    }
    document.onselectstart = function(event)
    {
        window.event.returnValue = false;
    }
    
    zxcObj = obj;
    zxcObj.style.zIndex = 1;
    
    zxcMse(event);
    zxcDragY = zxcMseY;
}

function zxcMseUp(event)
{
    zxcObj.style.zIndex = 0;
    
    document.onmousemove = null;
    document.onselectstart = null;
    
    zxcDragX = -1;
    zxcDragY = -1;
    
    zxcRePos();
}

function zxcDrag(event)
{
    zxcMse(event);
    zxcObj.style.top = ((zxcMseY - zxcDragY)) + 'px';
}

function zxcMse(event)
{
    if (!event)
        var event = window.event;

    if (document.all)
    {
        zxcMseX = event.clientX+zxcDocS()[0];
        zxcMseY = event.clientY+zxcDocS()[1];
    }
    else
    {
        zxcMseX = event.pageX;
        zxcMseY = event.pageY;
    }
}

function zxcDocS()
{
    var zxcsx, zxcsy;
    
    if (!document.body.scrollTop)
    {
        zxcsx = document.documentElement.scrollLeft;
        zxcsy = document.documentElement.scrollTop;
    }
    else
    {
        zxcsx = document.body.scrollLeft;
        zxcsy = document.body.scrollTop;
    }
    
    return [zxcsx,zxcsy];
}

function zxcRePos()
{
    if (zxcObj.parentNode)
    {
        var zxcpar = zxcObj.parentNode;
        var zxccloneary = [];
    
        for (var zxc0 = 0; zxc0 < zxcObj.ary.length; zxc0++)
        {
            zxccloneary.push([zxcObj.ary[zxc0].cloneNode(true), zxcObj.ary[zxc0].offsetTop]);
        }

        for (var zxc1 = 0; zxc1 < zxcObj.ary.length; zxc1++)
        {
            zxcpar.removeChild(zxcObj.ary[zxc1]);
        }
    
        zxccloneary = zxccloneary.sort(zxcSortPos);
    
        for (var zxc2 = 0; zxc2 < zxccloneary.length; zxc2++)
        {
            zxcpar.appendChild(zxccloneary[zxc2][0]);
            zxccloneary[zxc2][0].style.top = '0px';
        }
    
        setListeners();
    }
}

function zxcSortPos(zxca, zxcb)
{
    var zxcA = zxca[1];
    var zxcB = zxcb[1];
    
    if (zxcA < zxcB)
    {
        return -1;
    }
    
    if (zxcA > zxcB)
    {
        return 1;
    }
    
    return 0;
}

function setListeners()
{
    var item = document.getElementsByClassName("musica");
    
    for (var i = 0; i < item.length; i++)
    {
        if (item[i].addEventListener)
        {
            item[i].addEventListener ("mousedown", function (e) { zxcMove(e, this); }, false);
        }
        else if (item[i].attachEvent)
        {
            item[i].attachEvent ("onmousedown", function (e) { zxcMove(e, this); });
        }
    }
}

// Rotina AJAX
function Ajax() {
var req;

try {
 req = new ActiveXObject("Microsoft.XMLHTTP");
} catch(e) {
 try {
	req = new ActiveXObject("Msxml2.XMLHTTP");
 } catch(ex) {
	try {
	 req = new XMLHttpRequest();
	} catch(exc) {
	 alert("Esse browser n�o tem recursos para uso do Ajax");
	 req = null;
	}
 }
}

return req;
}