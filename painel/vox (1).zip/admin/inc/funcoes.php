<?php
// Fun��o para gerenciar query string

function query_string($posicao='0') {
$gets = explode("/",str_replace(strrchr($_SERVER["REQUEST_URI"], "?"), "", $_SERVER["REQUEST_URI"]));
array_shift($gets);
return utf8_decode(urldecode($gets[$posicao]));
}

// Fun��o para codificar e decodificar strings
function code_decode($texto, $tipo = "E") {
  if($tipo == "E") {
    $sesencoded = $texto;
  $num = mt_rand(0,3);
  for($i=1;$i<=$num;$i++)
  {
     $sesencoded = base64_encode($sesencoded);
  }
  $alpha_array =  array('Y','D','U','R','P','S','B','M','A','T','H');
  $sesencoded =
  $sesencoded."+".$alpha_array[$num];
  $sesencoded = base64_encode($sesencoded);
  return $sesencoded;
   } else {
   $alpha_array =
   array('Y','D','U','R','P','S','B','M','A','T','H');
   $decoded = base64_decode($texto);
   list($decoded,$letter) = explode("+",$decoded);
   for($i=0;$i<count($alpha_array);$i++)
   {
   if($alpha_array[$i] == $letter)
   break;
   }
   for($j=1;$j<=$i;$j++)
   {
      $decoded = base64_decode($decoded);
   }
   return $decoded;
  }
}

// Fun��o para checar status do streaming
function status_streaming($ip,$porta){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($ch, CURLOPT_TIMEOUT, 2);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	$resultado = curl_exec($ch);
	curl_close($ch);
	if($resultado === false){
		return "desligado";
	}else{
		return "ligado";
	}
}


// Fun��o para checar status do streaming bloqueado
function status_streaming_bloqueado($ip,$porta){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($ch, CURLOPT_TIMEOUT, 2);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	$resultado = curl_exec($ch);
	curl_close($ch);
	if($resultado === false){
		return "bloqueado";
	}else{
		return "ligado";
	}
}


// Fun��o para checar status do streaming do admin
function status_streaming_desbloqueado($ip,$porta){

        

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($ch, CURLOPT_TIMEOUT, 2);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	$resultado = curl_exec($ch);
	curl_close($ch);
	if($resultado === false){
		return "desligado";
	}else{
		return "ligado";
	}
}




// Fun��o para checar status do autodj e do ao vivo
function status_autodjv1($ip,$porta,$senha,$encoder){


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?pass=dj$senha");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
$resultado = curl_exec($ch);
curl_close($ch);

if(preg_match('/Server is currently up/i',$resultado)) {

if(preg_match('/127.0.0.1/i',$resultado)) {
return "ligado";
} else {
return "desligado";
}

} else {
return "desligado";
}

}

// Fun��o para checar status do autodj e do ao vivo
function status_autodjv2($ip,$porta,$senha){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?sid=1&pass=dj$senha");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($ch, CURLOPT_TIMEOUT, 2);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	$resultado = curl_exec($ch);
	curl_close($ch);
	if(preg_match('/Stream is currently up/i',$resultado)) {
		if(preg_match('/127.0.0.1/i',$resultado)) {
			return "ligado";
		}else{
			return "aovivo";
		}
	}else{
		return "desligado";
	}
}







// Fun�ao para checar status do autodj
function status_relay($ip,$porta,$senha) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?sid=1&pass=dj$senha");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
curl_setopt($ch, CURLOPT_TIMEOUT, 2);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
$resultado = curl_exec($ch);
curl_close($ch);
if(preg_match('/Stream is currently up/i',$resultado)) {
if(preg_match('/relaying/i',$resultado)) {
return "ligado";
} else {
return "desligado";
}
} else {
return "desligado";
}
}

// Fun�ao para obter as estatisticas do streaming
function estatistica_streaming($ip,$porta,$senha) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?sid=1&pass=dj$senha&mode=viewxml");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
$resultado = curl_exec($ch);
curl_close($ch);
if($resultado) {
$resultado = str_replace("&#x","",$resultado);
return $resultado;
}
}

// Fun�ao para obter as estatisticas do streaming no servidor shoutcast
function estatistica_streaming_shoutcast($stm_ip,$stm_porta,$stm_senha) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$stm_ip:$stm_porta/admin.cgi?sid=1&pass=dj$senha&mode=viewxml");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
$resultado = curl_exec($ch);
curl_close($ch);
if($resultado) {
$resultado = str_replace("&#x","",$resultado);
$xml = simplexml_load_string(utf8_encode($resultado));
$total_ouvintes = count($xml->LISTENERS->LISTENER);
if($total_ouvintes > 0) {
for($i=0;$i<$total_ouvintes;$i++){
$ip = $xml->LISTENERS->LISTENER[$i]->HOSTNAME;
$tempo_conectado = tempo_conectado($xml->LISTENERS->LISTENER[$i]->CONNECTTIME);
$array_ouvintes .= "".$ip."|".$tempo_conectado."|".pais_ip($ip,"sigla")."|".pais_ip($ip,"nome")."-";
}
}
}
return $array_ouvintes;
}

// Fun�ao para obter as estatisticas do streaming pelo robot
function estatistica_streaming_shoutcast_robot($ip,$porta,$senha) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?sid=1&pass=dj$senha&mode=viewxml");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$resultado = curl_exec($ch);
curl_close($ch);
if($resultado) {
$resultado = str_replace("&#x","",$resultado);
return $resultado;
}
}

// Fun��o para criar logs do sistema
function status_acao($status,$tipo) {
if($tipo == 'ok') {
$celula_status = '<tr style="background-color:#A6EF7B;">
      <td width="790" height="35" class="texto_log_sistema" scope="col">
	  <div align="center">'.$status.'</div>
	  </td>
</tr>
<tr><td scope="col" height="2" width="770"></td></tr>
';
} elseif($tipo == 'ok2') {
$celula_status = '<tr style="background-color:#A6EF7B;">
      <td width="790" height="35" class="texto_log_sistema" scope="col">
	  <div align="center">'.$status.'</div>
	  </td>
</tr>
<tr><td scope="col" height="2" width="770"></td></tr>
';
} elseif($tipo == 'alerta') {
$celula_status = '<tr style="background-color:#FFFF66;">
      <td width="790" height="35" class="texto_log_sistema_alerta" scope="col">
	  <div align="center">'.$status.'</div>
	  </td>
</tr>
<tr><td scope="col" height="2" width="770"></td></tr>
';
} else {
$celula_status = '<tr style="background-color:#F2BBA5;">
      <td width="790" height="35" class="texto_log_sistema_erro" scope="col">
	  <div align="center">'.$status.'</div>
	  </td>
</tr>
<tr><td scope="col" height="2" width="770"></td></tr>
';
}  
return $celula_status;
}

// FunÃƒÂ§ÃƒÂ£o para formatar os segundos em segundos, minutos e horas
function tempo_conectado($segundos) {

$days=intval($segundos/86400);
$remain=$segundos%86400;
$hours=intval($remain/3600);
$remain=$remain%3600;
$mins=intval($remain/60);
$secs=$remain%60;
if (strlen($mins)<2) {
$mins = '0'.$mins;
}
if($days > 0) $dia = $days.'d';
if($hours > 0) $hora = $hours.'hr, ';
if($mins > 0) $minuto = $mins.'min, ';

$segundo = $secs.'seg';
$segundos = $dia.$hora.$minuto.$segundo;

return $segundos;

}





// Fun��o para obter o player do ouvinte
function player_ouvinte($player) {
if(preg_match('/WMF/i',$player)) {
return "Windows Media Player";
} else if(preg_match('/Winamp/i',$player)) {
return "Winamp";
} else if(preg_match('/Ultravox/i',$player)) {
return "Ultravox(Winamp)";
} else if(preg_match('/RealMedia/i',$player)) {
return "RealPlayer";
} else if(preg_match('/RMA/i',$player)) {
return "RealPlayer";
} else if(preg_match('/MPEG OVERRIDE/i',$player)) {
return "Flash Player";
} else if(preg_match('/iTunes/i',$player)) {
return "iTunes";
} else if(preg_match('/Streamripper/i',$player)) {
return "Stream Ripper";
} else {
return "Desconhecido";
}
}

// Fun��o para gerar arquivo de configura��o do streaming

function gerar_conf_streaming($config) {


$config_streaming = "portbase=".$config["porta"]."
maxuser=".$config["ouvintes"]."
streammaxuser=".$config["ouvintes"]."
maxbitrate = ".$config["bitrate"]."000
password=".$config["senha"]."
adminpassword=dj".$config["senha"]."
logfile=/home/streaming/logs/log-".$config["porta"].".log
flashpolicyfile=/home/streaming/configs/crossdomain.xml
screenlog=0
showlastsongs=10
w3cenable=0
w3clog=/home/streaming/logs/w3c-".$config["porta"].".log
publicserver=default
namelookups=0
autodumpusers=0

allowrelay=1
allowpublicrelay=0
";


if($config["relay"] == "sim") {

$config_streaming .= "RelayPort=".$config["relay_porta"]."\n";
$config_streaming .= "RelayServer=".$config["relay_ip"]."\n";

} else {

$config_streaming .= "RelayPort=0\n";
$config_streaming .= "RelayServer=empty\n";

}

$config_streaming .= "MetaInterval=32768";

$arquivo_config_streaming = "".$config["porta"].".conf";
$handle_config_streaming = fopen("../temp/".$arquivo_config_streaming."" ,"a");
fwrite($handle_config_streaming, $config_streaming);
fclose($handle_config_streaming);

return $arquivo_config_streaming;
}


// Fun��o para gerar arquivo de configura��o do AutoDJ
function gerar_conf_autodj($config) {
$config_autodj = "logfile=/home/streaming/logs/autodj-".$config["porta"].".log";

if($config["shoutcast"] == "aacp") {

$config_autodj = "calendarrewrite=0
encoder_1=".$config["encoder"]."
bitrate_1=".$config["bitrate"]."000
aacformat_1=0
samplerate_1=44100
outprotocol_1=3
serverip_1=127.0.0.1
serverport_1=".$config["porta"]."
uvoxauth_1=".$config["senha"]."
uvoxstreamid_1=1
endpointname_1=/stream
".$config["multpoint"]."
streamtitle=".$config["streamtitle"]."
streamurl=".$config["streamurl"]."
genre=".$config["genre"]."
maxbitrate = ".$config["bitrate"]."000
channels=2
shuffle=".$config["shuffle"]."
xfade=".$config["xfade"]."
xfadethreshold=20
playlistfile=/home/streaming/playlists/".$config["playlist"]."
calendarfile=/home/streaming/configs/calendar-".$config["porta"].".xml
flashpolicyfile=/home/streaming/configs/crossdomain.xml
unlockkeyname=Richard Salm
unlockkeycode=NA5ER-X0D3B-Y9MR4-RQDDA
djport=".$config["porta_dj"]."
".$config["djs"]."
".$config["playlists"]."\n";

} else {

$config_autodj = "playlistfile=/home/streaming/playlists/".$config["playlist"]."
serverip=localhost
serverport=".$config["porta"]."
password=".$config["senha"]."
streamtitle=".$config["streamtitle"]."
streamurl=".$config["streamurl"]."
genre=".$config["genre"]."
encoder=".$config["encoder"]."
bitrate=".$config["bitrate"]."000
samplerate=44100
channels=2
logfile=/home/streaming/logs/autodj-".$config["porta"].".log
shuffle=".$config["shuffle"]."
xfade=".$config["xfade"]."
xfadethreshold=20
calendarfile=/home/streaming/configs/calendar-".$config["porta"].".xml
calendarrewrite=0
djport=".$config["porta_dj"]."

".$config["djs"]."
".$config["playlists"]."";

}
$arquivo_config_autodj = "autodj-".$config["porta"].".conf";
$handle_config_autodj = fopen("../temp/".$arquivo_config_autodj."" ,"a");
fwrite($handle_config_autodj, $config_autodj);
fclose($handle_config_autodj);

return $arquivo_config_autodj;
}

// Fun��o para gerar calendar de configura��o dos DJs do AutoDJ
function gerar_calendar_autodj($config) {


$config_calendar = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<eventlist>\n\n";

if($config["djs"]) {

foreach($config["djs"] as $dj) {

list($login,$inicio_hora,$inicio_minu,$final_hora,$final_minu,$restricao,$dias,$dj) = explode("|",$dj);
$duracao = ($final_hora != 00) ? "duration=\"".$final_hora.":".$final_minu.":00\"" : "";
$dias_executar = 0;
$array_dias = explode(",",$dias);
foreach($array_dias as $dia) {
$dias_executar += $dia;
}

if($restricao == "0") { // Executar sem restricao)
$config_calendar .= "<event type=\"dj\">\n";
$config_calendar .= "<dj archive=\"0\">".$login."</dj>\n";
$config_calendar .= "<calendar />\n";
$config_calendar .= "</event>\n\n";

} else if($restricao == "1") { // Executar com restricao

$config_calendar .= "<event type=\"dj\">\n";
$config_calendar .= "<dj archive=\"1\">".$login."</dj>\n";
$config_calendar .= "<calendar />\n";
$duracao = ($final_hora != 00) ? "duration=\"".$final_hora.":".$final_minu.":00\"" : "";
$config_calendar .= "<calendar startdate=\"2016/01/11\" starttime=\"".$inicio_hora.":".$inicio_minu.":00\"  ".$duracao." repeat=\"".$dias_executar."\" />\n";
$config_calendar .= "</event>\n\n";

} else {

$config_calendar .= "<event type=\"dj\">\n";
$config_calendar .= "<dj archive=\"0\">".$login."</dj>\n";
$config_calendar .= "<calendar />\n";
$config_calendar .= "</event>\n\n";


}
}
}

if($config["listarelay"]) {

foreach($config["listarelay"] as $listarelay) {
list($frequencia,$data,$hora,$minuto,$duracao_hora,$duracao_minuto,$dias,$repetir,$shuffle,$url) = explode("|",$listarelay);
$NumAtual = 1+$NumAtual++;
$dias_executar = 0;

$array_dias = explode(",",$dias);

foreach($array_dias as $dia) {
$dias_executar += $dia;
}
$config_calendar .= "<event type=\"relay\">\n";
$config_calendar .= "<relay url=\"".$url."/;\" priority=\"".$NumAtual++."\" />\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":00\"" : "";
$duracao_final = ($duracao_hora != 00) ? "timeoffset=\"".$duracao_hora.":".$duracao_minuto.":00\"" : "";
$config_calendar .= "<calendar startdate=\"".str_replace("-","/",$data)."\" enddate=\"2059/01/11\" starttime=\"".$hora.":".$minuto.":00\" ".$duracao."  repeat=\"".$dias_executar."\" />\n";
$config_calendar .= "</event>\n\n";
}
}


$config_calendar .= "\n";

if($config["playlists"]) {

foreach($config["playlists"] as $playlist) {

list($playlist,$frequencia,$data,$hora,$minuto,$duracao_hora,$duracao_minuto,$dias,$repetir,$shuffle,$url) = explode("|",$playlist);

$repetir = ($duracao_hora != 00) ? "1" : $repetir;
$novadata = 2015/01/01;
$NumAtual = 1+$NumAtual++;


if($frequencia == "1") { // Executar uma vez(dia espec�fico)
$config_calendar .= "<event type=\"playlist\">\n";
$config_calendar .= "<playlist loopatend=\"0\" shuffle=\"".$shuffle."\" priority=\"1".$NumAtual++."\">".$playlist."</playlist>\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":00\"" : "";
$config_calendar .= "<calendar startdate=\"".str_replace("-","/",$data)."\" enddate=\"".str_replace("-","/",$data)."\" starttime=\"".$hora.":".$minuto.":00\" ".$duracao." />\n";



} else if($frequencia == "2") { // Executar diariamente
$config_calendar .= "<event type=\"playlist\">\n";
$config_calendar .= "<playlist loopatend=\"0\" shuffle=\"".$shuffle."\" priority=\"2".$NumAtual++."\">".$playlist."</playlist>\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":00\"" : "";
$config_calendar .= "<calendar starttime=\"".$hora.":".$minuto.":00\" ".$duracao." repeat=\"127\" />\n";




} else if($frequencia == "5") { // Executar hora certa
$config_calendar .= "<event type=\"playlist\">\n";
$config_calendar .= "<playlist loopatend=\"0\" shuffle=\"1\" priority=\"3".$NumAtual++."\">".$playlist."</playlist>\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":04\"" : "";
$config_calendar .= "<calendar startdate=\"".str_replace("-","/",$data)."\" starttime=\"".$hora.":".$minuto.":00\" ".$duracao." repeat=\"127\" />\n";




} else if($frequencia == "6") { // Executar comerciais
$config_calendar .= "<event type=\"playlist\">\n";
$config_calendar .= "<playlist loopatend=\"0\" shuffle=\"1\" priority=\"4".$NumAtual++."\">".$playlist."</playlist>\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":04\"" : "";
$config_calendar .= "<calendar startdate=\"".str_replace("-","/",$data)."\" starttime=\"".$hora.":".$minuto.":00\"  duration=\"23:59:00\"  repeat=\"127\" />\n";


} else { // Executar em dias espec�ficos

$dias_executar = 0;

$array_dias = explode(",",$dias);

foreach($array_dias as $dia) {
$dias_executar += $dia;
}
$config_calendar .= "<event type=\"playlist\">\n";
$config_calendar .= "<playlist loopatend=\"0\" shuffle=\"".$shuffle."\" priority=\"5".$NumAtual++."\">".$playlist."</playlist>\n";
$duracao = ($duracao_hora != 00) ? "duration=\"".$duracao_hora.":".$duracao_minuto.":00\"" : "";
$config_calendar .= "<calendar starttime=\"".$hora.":".$minuto.":00\" ".$duracao." repeat=\"".$dias_executar."\" />\n";
}

$config_calendar .= "</event>\n\n";
}
}

$config_calendar .= "\n</eventlist>";

$arquivo_config_calendar = "calendar-".$config["porta"].".xml";
$handle_config_calendar = fopen("../temp/".$arquivo_config_calendar."" ,"a");
fwrite($handle_config_calendar, $config_calendar);
fclose($handle_config_calendar);

return $arquivo_config_calendar;
}

// Fun��o para retornar o tipo de medida do tamanho do arquivo(Byts, Kbytes, Megabytes, Gigabytes, etc...)
function tamanho($size)
{
    $filesizename = array(" MB", " GB", " TB", " PB", " EB", " ZB", " YB");
    return $size ? round($size/pow(1000, ($i = floor(log($size, 1000)))), 2) . $filesizename[$i] : '0 Bytes';
}





// Fun��o para capturar informa��es de um streaming
function shoutcast_info($ip,$porta,$senha) {

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$ip:$porta/admin.cgi?pass=$senha&mode=viewxml");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
$resultado = curl_exec($ch);
curl_close($ch);

$resultado = str_replace("&#x","",$resultado);

$xml = simplexml_load_string(utf8_encode($resultado));

return array("ouvintes" => $xml->MAXLISTENERS, "bitrate" => $xml->BITRATE, "encoder" => $xml->CONTENT, "musica" => $xml->SONGTITLE, "titulo" => $xml->SERVERTITLE);
}
// Fun��o para retornar o nome do m�s
function nome_mes($a) {

	switch($a) {
		case 01: $mes = "Janeiro"; break;
		case 02: $mes = "Fevereiro"; break;
		case 03: $mes = "Mar�o"; break;
		case 04: $mes = "Abril"; break;
		case 05: $mes = "Maio"; break;
		case 06: $mes = "Junho"; break;
		case 07: $mes = "Julho"; break;
		case 08: $mes = "Agosto"; break;
		case 09: $mes = "Setembro"; break;
		case 10: $mes = "Outubro"; break;
		case 11: $mes = "Novembro"; break;
		case 12: $mes = "Dezembro"; break;
		
}

return $mes;
}

// Fun��o para calcular tempo de exceuss�o
function tempo_execucao() {
    $sec = explode(" ",microtime());
    $tempo = $sec[1] + $sec[0];
    return $tempo;
}

function anti_sql_injection($str) {
    if (!is_numeric($str)) {
        $str = get_magic_quotes_gpc() ? stripslashes($str) : $str;
        $str = function_exists('mysql_real_escape_string') ? mysql_real_escape_string($str) : mysql_escape_string($str);
    }
    return $str;
}

// Fun��o para remover acentos e espaÃƒÂ§os
function formatar_nome_playlist($playlist) {
$array_caracteres = array("/[�����]/"=>"a","/[�����]/"=>"a","/[����]/"=>"e","/[����]/"=>"e","/[����]/"=>"i","/[����]/"=>"i","/[�����]/"=>"o", "/[�����]/"=>"o","/[����]/"=>"u","/[����]/"=>"u","/�/"=>"c","/�/"=> "c","/ /"=> "-","/_/"=> "-");
$formatado = preg_replace(array_keys($array_caracteres), array_values($array_caracteres), $playlist);
return strtolower($formatado);
}

// Fun��o para localizar o IP
function pais_ip($ip,$tipo) {
$paises = array("AF" => "Afeganist�o", "AL" => "Alb�nia", "DE" => "Alemanha", "AD" => "Andorra", "AO" => "Angola", "AI" => "Anguilla", "AQ" => "Ant�rctida", "AG" => "Antigua e Barbuda", "AN" => "Antilhas Holandesas", "SA" => "Ar�bia Saudita", "AR" => "Argentina", "DZ" => "Arg�lia", "AM" => "Arm�nia", "AW" => "Aruba", "AU" => "Austr�lia", "AZ" => "Azerbeij�o", "ZA" => "�frica do Sul", "AT" => "�ustria", "AX" => "�land", "BS" => "Bahamas", "BH" => "Bahrain", "BD" => "Bangladesh", "BB" => "Barbados", "BZ" => "Belize", "BJ" => "Benin", "BM" => "Bermuda", "BE" => "B�lgica", "BY" => "Bielo-R�ssia", "BO" => "Bol�via", "BW" => "Botswana", "BV" => "Bouvet", "BA" => "B�snia-Herzegovina", "BR" => "Brasil", "BN" => "Brunei", "BG" => "Bulg�ria", "BF" => "Burkina Faso", "BI" => "Burundi", "BT" => "But�o", "CV" => "Cabo Verde", "CM" => "Camar�es", "KH" => "Cambodja", "CA" => "Canad�", "KY" => "Cayman", "KZ" => "Cazaquist�o", "CF" => "Centro-africana, Rep�blica", "TD" => "Chade", "CZ" => "Rep�blica Checa", "CL" => "Chile", "CN" => "China", "CY" => "Chipre", "CX" => "Christmas", "CC" => "Cocos", "CO" => "Col�mbia", "KM" => "Comores", "CD" => "Rep�blica Democr�tica do Congo", "CG" => "Rep�blica do Congo", "CK" => "Cook", "KR" => "Coreia do Sul", "KP" => "Coreia do Norte", "CI" => "Costa do Marfim", "CR" => "Costa Rica", "HR" => "Cro�cia", "CU" => "Cuba", "DK" => "Dinamarca", "DJ" => "Djibouti", "DM" => "Dominica", "DO" => "Rep�blica Dominicana", "EG" => "Egito", "SV" => "El Salvador", "AE" => "Emiratos �rabes", "EC" => "Equador", "ER" => "Eritreia", "SK" => "Eslov�quia", "SI" => "Eslov�nia", "ES" => "Espanha", "US" => "Estados Unidos", "EE" => "Est�nia", "ET" => "Eti�pia", "FO" => "Faroe", "FJ" => "Fiji", "PH" => "Filipinas", "FI" => "Finl�ndia", "FR" => "Fran�a", "GA" => "Gab�o", "GH" => "Gana", "GM" => "G�mbia", "GE" => "Ge�rgia", "GS" => "Ge�rgia do Sul", "GI" => "Gibraltar", "GD" => "Grenada", "GR" => "Gr�cia", "GL" => "Gronel�ndia", "GP" => "Guadeloupe", "GU" => "Guam", "GT" => "Guatemala", "GG" => "Guernsey", "GY" => "Guiana", "GF" => "Guiana Francesa", "GQ" => "Guin� Equatorial", "GW" => "Guin�-Bissau", "GN" => "Guin�-Conacri", "HT" => "Haiti", "HM" => "Heard e Ilhas McDonald", "HN" => "Honduras", "HK" => "Hong Kong", "HU" => "Hungria", "YE" => "I�men", "ID" => "Indon�sia", "IQ" => "Iraque", "IR" => "Ir�o", "IE" => "Irlanda", "IS" => "Isl�ndia", "IL" => "Israel", "IT" => "It�lia", "IN" => "�ndia", "JM" => "Jamaica", "JP" => "Jap�o", "JE" => "Jersey", "JO" => "Jord�nia", "KI" => "Kiribati", "KW" => "Kuwait", "LA" => "Laos", "LS" => "Lesoto", "LV" => "Let�nia", "LR" => "Lib�ria", "LI" => "Liechtenstein", "LT" => "Litu�nia", "LB" => "L�bano", "LY" => "L�bia", "LU" => "Luxemburgo", "MO" => "Macau", "MK" => "Maced�nia, Rep�blica da", "MG" => "Madag�scar", "MW" => "Malawi", "MY" => "Mal�sia", "MV" => "Maldivas", "ML" => "Mali", "MT" => "Malta", "FK" => "Malvinas (Falkland)", "IM" => "Man", "MP" => "Marianas Setentrionais", "MA" => "Marrocos", "MH" => "Marshall", "MQ" => "Martinica", "MR" => "Maurit�nia", "MU" => "Maur�cia", "YT" => "Mayotte", "UM" => "Menores Distantes dos Estados Unidos", "MX" => "M�xico", "FM" => "Micron�sia", "MZ" => "Mo�ambique", "MD" => "Mold�via", "MN" => "Mong�lia", "ME" => "Montenegro", "MS" => "Montserrat", "MC" => "M�naco", "MM" => "Myanmar", "NA" => "Nam�bia", "NR" => "Nauru", "NP" => "Nepal", "NI" => "Nicar�gua", "NG" => "Nig�ria", "NU" => "Niue", "NE" => "N�ger", "NF" => "Norfolk", "NO" => "Noruega", "NC" => "Nova Caled�nia", "NZ" => "Nova Zel�ndia", "OM" => "Oman", "NL" => "Holanda", "PW" => "Palau", "PS" => "Palestina", "PA" => "Panam�", "PG" => "Papua-Nova Guin�", "PK" => "Paquist�o", "PY" => "Paraguai", "PE" => "Peru", "PN" => "Pitcairn", "PF" => "Polin�sia Francesa", "PL" => "Pol�nia", "PR" => "Porto Rico", "PT" => "Portugal", "QA" => "Qatar", "KE" => "Qu�nia", "KG" => "Quirguist�o", "GB" => "Reino Unido da Gr�-Bretanha e Irlanda do Norte", "RE" => "Reuni�o", "RO" => "Rom�nia", "RW" => "Ruanda", "RU" => "R�ssia", "EH" => "Saara Ocidental", "PM" => "Saint Pierre et Miquelon", "SB" => "Salom�o", "WS" => "Samoa (Samoa Ocidental)", "AS" => "Samoa Americana", "SM" => "San Marino", "SH" => "Santa Helena", "LC" => "Santa L�cia", "KN" => "S�o Crist�v�o e N�vis (Saint Kitts e Nevis)", "ST" => "S�o Tom� e Pr�ncipe", "VC" => "S�o Vicente e Granadinas", "SN" => "Senegal", "SL" => "Serra Leoa", "SC" => "Seychelles", "RS" => "S�rvia", "SG" => "Singapura", "SY" => "S�ria", "SO" => "Som�lia", "LK" => "Sri Lanka", "SZ" => "Suazil�ndia", "SD" => "Sud�o", "SE" => "Su�cia", "CH" => "Su��a", "SR" => "Suriname", "SJ" => "Svalbard e Jan Mayen", "TH" => "Tail�ndia", "TW" => "Taiwan", "TJ" => "Tajiquist�o", "TZ" => "Tanz�nia", "TF" => "Terras Austrais e Ant�rticas Francesas", "IO" => "Territ�rio Brit�nico do Oceano �ndico", "TL" => "Timor-Leste", "TG" => "Togo", "TO" => "Tonga", "TK" => "Toquelau", "TT" => "Trindade e Tobago", "TN" => "Tun�sia", "TC" => "Turks e Caicos", "TM" => "Turquemenist�o", "TR" => "Turquia", "TV" => "Tuvalu", "UA" => "Ucr�nia", "UG" => "Uganda", "UY" => "Uruguai", "UZ" => "Usbequist�o", "VU" => "Vanuatu", "VA" => "Vaticano", "VE" => "Venezuela", "VN" => "Vietname", "VI" => "Virgens Americanas", "VG" => "Virgens Brit�nicas", "WF" => "Wallis e Futuna", "ZM" => "Z�mbia", "ZW" => "Zimbabwe");
//$pais_ip = geoip_country_code_by_name($ip);
if($tipo == "nome") {
if($paises[$pais_ip]) {
return $paises[$pais_ip];
} else {
return "Desconhecido";
}
} else {
if($pais_ip) {
return $pais_ip;
} else {
return "Desconhecido";
}
}
}

// Fun��o para remover acentos
function remover_acentos($msg) {
$a = array("/[�����]/"=>"A","/[�����]/"=>"a","/[����]/"=>"E","/[����]/"=>"e","/[����]/"=>"I","/[����]/"=>"i","/[�����]/"=>"O",	"/[�����]/"=>"o","/[����]/"=>"U","/[����]/"=>"u","/�/"=>"c","/�/"=> "C");
return preg_replace(array_keys($a), array_values($a), $msg);
}




?>