////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Streaming ////////////
////////////////////////////////////////////////////////

// Fun��o para ligar o streaming
function ligar_streaming( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/ligar_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para desligar o streaming
function desligar_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/desligar_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para bloquear o streaming
function bloquear_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/bloquear_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para desbloquear o streaming
function desbloquear_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/desbloquear_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover o streaming
function remover_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para criar codigo HTML do player
function player_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/player_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {		
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel carregar o player do streaming <strong>"+porta+"</strong></span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para checar o status do streaming e autodj
function status_streaming( porta ) {
  
  document.getElementById( porta ).innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
	
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/status_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ligado") {
		
	document.getElementById( porta ).innerHTML = "Ligado";
	document.getElementById( porta ).style.backgroundColor = "#A8FFA8";
	
	} else if(resultado == "ligado-autodj") {
	
	document.getElementById( porta ).innerHTML = "AutoDJ";
	document.getElementById( porta ).style.backgroundColor = "#A8FFA8";
	
	} else if(resultado == "ligado-relay") {
	
	document.getElementById( porta ).innerHTML = "Relay";
	document.getElementById( porta ).style.backgroundColor = "#A8FFA8";
	
	} else if(resultado == "desligado") {
	
	document.getElementById( porta ).innerHTML = "Desligado";
	document.getElementById( porta ).style.backgroundColor = "#FFB3B3";
	
	} else if(resultado == "manutencao") {
	
	document.getElementById( porta ).innerHTML = "Manuten��o";
	document.getElementById( porta ).style.backgroundColor = "#FFB3B3";
	
	} else {
	
	document.getElementById( porta ).style.backgroundColor = "#FFFF97";
	
	}
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para checar o status do streaming e autodj no painel do cliente final
function status_streaming_cliente( porta ) {
  
  document.getElementById( porta ).innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
	
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/status_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ligado") {
		
	document.getElementById( porta ).innerHTML = "Ligado";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "ligado-autodj") {
	
	document.getElementById( porta ).innerHTML = "AutoDJ";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "desligado") {
	
	document.getElementById( porta ).innerHTML = "Desligado";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	} else {
	
	document.getElementById( porta ).innerHTML = "Erro";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	}
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para desconectar source do streaming(kick)
function kick_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/kick_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}


// Fun��o para ativar prote��o contra ataques ao streaming
function ativar_protecao( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/ativar_protecao/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar a lista de player dispon�veis
function carregar_lista_players_streaming( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_lista_players_streaming/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para gerar o c�digo HTML do player do streaming
function gerar_codigo_player_streaming( porta,player ) {
	
  if(porta == "" || player == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/gerar_codigo_player_streaming/"+porta+"/"+player+"" , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para sincronizar streaming no servidor AAC+
function sincronizar_aacplus( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/sincronizar_aacplus/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

////////////////////////////////////////////////////////
///////////// Fun��es Gerenciamento AutoDJ /////////////
////////////////////////////////////////////////////////

// Fun��o para carregar lista de playlists do streaming
function carregar_playlists( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_playlists/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para ligar o autodj
function ligar_autodj( porta,playlist,shuffle,bitrate,xfade ) {
	
  if(porta == "" || playlist == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/ligar_autodj/"+porta+"/"+playlist+"/"+shuffle+"/"+bitrate+"/"+xfade+"" , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;		
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para recarregar playlist no autodj
function recarregar_playlist( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/recarregar_playlist/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para pular musica atual playlist no autodj
function pular_musica( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/pular_musica/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para desligar o autodj
function desligar_autodj( porta ) {
	
  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/desligar_autodj/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover um DJ do AutoDJ
function remover_dj( codigo ) {
	
  if(codigo == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_dj/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Playlist /////////////
////////////////////////////////////////////////////////

// Fun��o para carregar as m�sicas da pasta do FTP
function carregar_musicas_pasta( porta,pasta ) {
	
  if(porta == "" || pasta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_musicas_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
		
	array_musicas = resultado.split(";");
	
	for(var cont = 0; cont < array_musicas.length; cont++) {	
	 
	 if(array_musicas[cont]) {
	 
	 array_musica = array_musicas[cont].split("|");
	 
	 opcao = document.createElement("OPTION");
	 document.getElementById("musicas_pasta").appendChild(opcao);
	 opcao.value = array_musica[0];
	 opcao.text = array_musica[1];
	 }
	 
	}
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel carregar as m�sicas.<br />Esta pasta n�o possui m�sicas.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar as m�sicas da playlist
function carregar_musicas_playlist( playlist ) {
	
  if(playlist == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/carregar_musicas_playlist/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
		
	array_musicas = resultado.split(";");
	
	for(var cont = 0; cont < array_musicas.length; cont++) {	
	 
	 if(array_musicas[cont]) {
	 
	 array_musica = array_musicas[cont].split("|");
	 
	 opcao = document.createElement("OPTION");
	 document.getElementById("musicas").appendChild(opcao);
	 opcao.value = array_musica[0];
	 opcao.text = array_musica[1];
	 }
	 
	}
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel carregar as m�sicas.<br />Esta playlist n�o possui m�sicas cadastradas.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para criar uma nova playlist
function criar_playlist( porta ) {
  
  var playlist = prompt('Informe um nome para a nova playlist:');
	
  if(playlist != "" && playlist != null) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/criar_playlist/"+porta+"/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
		
    array_nova_playlist = resultado.split("|");
		
	opcao = document.createElement("OPTION");
	document.getElementById("playlists").appendChild(opcao);
	opcao.value = array_nova_playlist[0];
	opcao.text = array_nova_playlist[1]+" (0)";
	opcao.selected = true;
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	document.getElementById('nova_playlist').value = "";
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel criar a nova playlist.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover uma m�sica de uma playlist
function remover_musica( musica ) {
	
  if(musica == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_musica/"+musica , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	document.getElementById("musicas").remove(document.getElementById("musicas").selectedIndex);
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
  
  }
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover uma playlist
function remover_playlist( playlist ) {
	
  if(playlist == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_playlist/"+playlist , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ok") {
		
	document.getElementById("playlists").remove(document.getElementById("playlists").selectedIndex);
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel remover a playlist.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

////////////////////////////////////////////////////////
//////////// Fun��es Gerenciamento M�sicas /////////////
////////////////////////////////////////////////////////

// Fun��o para criar uma nova pasta no FTP
function criar_pasta( porta ) {
  
  var pasta = prompt('Informe um nome para a nova pasta:');
	
  if(pasta != "" && pasta != null) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/criar_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	pasta = http.responseText;
	
	if(pasta) {
		
	opcao = document.createElement("OPTION");
	document.getElementById("pastas").appendChild(opcao);
	opcao.value = pasta;
	opcao.text = pasta+" (0)";
	opcao.selected = true;
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel criar a pasta <strong>"+$pasta+"</strong> no FTP.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover uma pasta
function remover_pasta( porta,pasta ) {
  
  if(window.confirm("Deseja realmente remover esta pasta e todo o seu conte�do?")) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ok") {
		
	document.getElementById("pastas").remove(document.getElementById("pastas").selectedIndex);
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel remover a pasta <strong>"+pasta+"</strong> no FTP.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover uma musica no FTP
function remover_musica_ftp( porta,musica ) {

  if(musica == "") {  
  alert("Aten��o! Voc� deve selecionar a m�sica que deseja remover.");  
  } else {
  
  if(window.confirm("Deseja realmente remover esta m�sica?")) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var musica = musica.replace("/", "|")
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_musica_ftp/"+porta+"/"+musica , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ok") {
		
	document.getElementById("musicas").remove(document.getElementById("musicas").selectedIndex);
	
	document.getElementById('log-sistema-fundo').style.display = "none";
    document.getElementById('log-sistema').style.display = "none";
	
	} else {
	document.getElementById("log-sistema-conteudo").innerHTML = "<span class='texto_status_erro'>N�o foi poss�vel remover a m�sica no FTP.</span>";
	}
	
  }
  
  }
  http.send(null);
  delete http;
  }
  }
}

// Fun��o para iniciar envio de m�sicas
function enviar_musicas( pasta ) {
  
  if(pasta == "") {
  
  alert("Aten��o! Voc� deve selecionar a pasta para onde ser�o enviada(s) a(s) m�sica(s).");  
  document.getElementById('pastas').focus();
  
  } else {
	  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  document.form_musicas.submit();
  
  }

}

////////////////////////////////////////////////////////
//////////// Fun��es Gerenciamento Revenda /////////////
////////////////////////////////////////////////////////

// Fun��o para bloquear revenda
function bloquear_revenda( codigo ) {
	
  if(codigo == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/bloquear_revenda/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para desbloquear revenda
function desbloquear_revenda( codigo ) {
	
  if(codigo == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/desbloquear_revenda/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover revenda
function remover_revenda( codigo ) {
	
  if(codigo == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_revenda/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Servidor /////////////
////////////////////////////////////////////////////////

// Fun��o para ligar todos os streaming do servidor
function ligar_streamings_servidor( servidor ) {
	
  if(servidor == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/listar_streamings_servidor/"+servidor , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	streamings = http.responseText;
	
	array_streamings = streamings.split("|");
  
  	for(var cont = 0; cont < array_streamings.length; cont++) {
  
  	var porta = array_streamings[cont];
	
  	ligar_streaming( porta );
  
  	}	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para ligar todos os streaming do servidor
function ligar_autodjs_servidor( servidor ) {
	
  if(servidor == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/listar_streamings_autodj_servidor/"+servidor , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	streamings = http.responseText;
	
	array_streamings = streamings.split("|");
  
  	for(var cont = 0; cont < array_streamings.length; cont++) {
	
	var array_dados_porta = array_streamings[cont].split(",");
  
  	var porta = array_dados_porta[0];
	var playlist = array_dados_porta[1];
	var shuffle = array_dados_porta[2];
	var bitrate = array_dados_porta[3];
	var xfade = array_dados_porta[4];
	
	if(playlist != 0) {

	ligar_autodj( porta,playlist,shuffle,bitrate,xfade );
	
	}
	
  	}	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}


// Fun��o para desligar todos os streaming do servidor
function desligar_streamings_servidor( servidor ) {
	
  if(servidor == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/listar_streamings_servidor/"+servidor , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	streamings = http.responseText;
	
	array_streamings = streamings.split("|");
  
  	for(var cont = 0; cont < array_streamings.length; cont++) {
  
  	var porta = array_streamings[cont];
	
  	desligar_streaming( porta );
  
  	}	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}


// Fun��o para sincronizar streaming no servidor AAC+
function sincronizar_aacplus_servidor( servidor ) {

  if(servidor == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/sincronizar_aacplus_servidor/"+servidor , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	streamings = http.responseText;
	
	array_streamings = streamings.split("|");
  
  	for(var cont = 0; cont < array_streamings.length; cont++) {
  
  	var porta = array_streamings[cont];
	
  	sincronizar_aacplus( porta );
  
  	}	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para remover uma dica r�pida
function remover_dica_rapida( codigo ) {
	
  if(codigo == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_dica_rapida/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para ativar/desativar manuten��o em um servidor
function manutencao_servidor( codigo, acao, mensagem ) {
	
  if(codigo == "" && acao == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/manutencao_servidor/"+codigo+"/"+acao+"/"+mensagem , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para exibir avisos
function exibir_aviso( codigo ) {
	
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/exibir_aviso/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para marcar um aviso como vizualizado
function desativar_exibicao_aviso( codigo, area, codigo_usuario ) {
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/desativar_exibicao_aviso/"+codigo+"/"+area+"/"+codigo_usuario , true);
  http.send(null);
  delete http;
  
}

// Fun��o para mudar o status de exibi��o de um aviso
function alterar_status_aviso( codigo ) {
	
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/alterar_status_aviso/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para remover um aviso
function remover_aviso( codigo ) {
	
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/remover_aviso/"+codigo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
}

// Rotina AJAX
function Ajax() {
var req;

try {
 req = new ActiveXObject("Microsoft.XMLHTTP");
} catch(e) {
 try {
	req = new ActiveXObject("Msxml2.XMLHTTP");
 } catch(ex) {
	try {
	 req = new XMLHttpRequest();
	} catch(exc) {
	 alert("Esse browser n�o tem recursos para uso do Ajax");
	 req = null;
	}
 }
}

return req;
}