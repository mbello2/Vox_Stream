<?php
// conexao banco de dados
$host = "localhost";//nome do host
$user = "stmradio_root";//nome de usuario do mysql
$pass = "1t8h748iu8"; //senha do mysql
$bd_streaming = "stmradio_root"; //nome do banco de dados
$conexao = mysql_connect($host,$user,$pass) or die('Imposs�vel selecionar o banco de dados');
mysql_select_db($bd_streaming,$conexao) or die('Imposs�vel selecionar o banco de dados');
?>