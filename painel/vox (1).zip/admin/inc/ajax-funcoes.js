////////////////////////////////////////////////////////
/////////// Fun��es Gerenciamento Streaming ////////////
////////////////////////////////////////////////////////
 


// Fun��o para carregar o formul�rio youtube
function downloads( porta ) {
	
  if(porta == "") {
  alert("Erro! Informe o URL do Youtube.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/youtube/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para fazer downloads arquivos
function baixar_youtube( porta,senha,encoder,streamtitle,streamurl,genre ) {
	
  if(porta == "" || senha == "" || encoder == "" || streamtitle == "" || streamurl == "" || genre == "") {
  alert("Erro! Informe o URL do Youtube.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("POST", "/admin/funcoes-ajax" , true);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send("acao=baixar_youtube&porta="+porta+"&senha="+senha+"&encoder="+encoder+"&streamtitle="+streamtitle+"&streamurl="+streamurl+"&genre="+genre+"");
  delete http;
  }
}

// Fun��o para salvar musica do youtube no ftp
function Salvar_musicas( porta,senha,encoder,streamtitle,streamurl,genre ) {
	
  if(porta == "" || senha == "" || encoder == "" || streamtitle == "" || streamurl == "" || genre == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("POST", "/admin/funcoes-ajax" , true);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send("acao=Salvar_musicas&porta="+porta+"&senha="+senha+"&encoder="+encoder+"&streamtitle="+streamtitle+"&streamurl="+streamurl+"&genre="+genre+"");
  delete http;
  }
}

// Fun��o para checar o status do streaming e autodj
function status_streamingmp3( porta ) {
  
  document.getElementById( porta ).innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
	
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/status_streamingmp3/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ligado") {
		
	document.getElementById( porta ).innerHTML = "Ligado";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "ligado-autodj") {
	
	document.getElementById( porta ).innerHTML = "AutoDJ";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "ligado-relay") {
	
	document.getElementById( porta ).innerHTML = "Relay";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "desligado") {
	
	document.getElementById( porta ).innerHTML = "Desligado";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	} else if(resultado == "bloqueado") {
	
	document.getElementById( porta ).innerHTML = "Bloqueado";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	} else if(resultado == "manutencao") {
	
	document.getElementById( porta ).innerHTML = "Manuten��o";
	document.getElementById( porta ).style.backgroundColor = "#FFB3B3";
	
	} else {
	
	document.getElementById( porta ).innerHTML = "Erro";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	}
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para checar o status do streaming e autodj
function status_streamingaacp( porta ) {
  
  document.getElementById( porta ).innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
	
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/status_streamingaacp/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado == "ligado") {
		
	document.getElementById( porta ).innerHTML = "Ligado";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "ligado-autodj") {
	
	document.getElementById( porta ).innerHTML = "AutoDJ";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "ligado-relay") {
	
	document.getElementById( porta ).innerHTML = "Relay";
	document.getElementById( porta ).className = "texto_status_streaming_online";
	
	} else if(resultado == "desligado") {
	
	document.getElementById( porta ).innerHTML = "Desligado";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	} else if(resultado == "bloqueado") {
	
	document.getElementById( porta ).innerHTML = "Bloqueado";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	} else if(resultado == "manutencao") {
	
	document.getElementById( porta ).innerHTML = "Manuten��o";
	document.getElementById( porta ).style.backgroundColor = "#FFB3B3";
	
	} else {
	
	document.getElementById( porta ).innerHTML = "Erro";
	document.getElementById( porta ).className = "texto_status_streaming_offline";
	
	}
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para marcar um aviso como vizualizado
function desativar_exibicao_aviso( codigo, area, codigo_usuario ) {
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-br/desativar_exibicao_aviso/"+codigo+"/"+area+"/"+codigo_usuario , true);
  http.send(null);
  delete http;
  
}
// Fun��o para trocar playlists
function trocar_playlists( porta ) {
	
  if(porta == "") {
  alert("Erro! ao acessar a playlist.");
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax/trocar_playlists/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	document.getElementById("log-sistema-conteudo").innerHTML = resultado;	
	
  }
  
  }
  http.send(null);
  delete http;
  }
}
// Rotina AJAX
function Ajax() {
var req;

try {
 req = new ActiveXObject("Microsoft.XMLHTTP");
} catch(e) {
 try {
	req = new ActiveXObject("Msxml2.XMLHTTP");
 } catch(ex) {
	try {
	 req = new XMLHttpRequest();
	} catch(exc) {
	 alert("Esse browser n�o tem recursos para uso do Ajax");
	 req = null;
	}
 }
}

return req;
}