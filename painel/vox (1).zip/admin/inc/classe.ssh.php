<?php
class SSH {

  function conectar($ip,$porta) {

     $this->conexao = ssh2_connect($ip,$porta);
     if(!$this->conexao) {
       die("N�o foi poss�vel se conectar-se ao servidor.");
     }

  }

  function autenticar($usuario,$senha) {

     if(!ssh2_auth_password($this->conexao,$usuario,$senha)) {
       die("N�o foi poss�vel autenticar-se ao servidor.");
     }

  }

  function executar($comando) {

     $this->stream = ssh2_exec($this->conexao,$comando.';sleep 1');
	 stream_set_blocking( $this->stream, true );
	 $this->resultado = fread( $this->stream, 4096 );
	 fclose($this->stream); 
	 
	 if($this->resultado) {
	 return $this->resultado;
	 } else {
	 die("N�o foi poss�vel executar o comando no servidor.<br>Comando: ".$comando."");
	 }

  }
  
  function enviar_arquivo($origem,$destino,$permissao) {

	 $this->resultado = ssh2_scp_send($this->conexao,$origem,$destino,$permissao);
	 
	 if($this->resultado) {
	 return "ok";
	 } else {
	 die("N�o foi poss�vel enviar o arquivo para o servidor.");
	 }

  }

}
?>