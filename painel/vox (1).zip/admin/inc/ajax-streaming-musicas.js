////////////////////////////////////////////////////////
//////////// Fun��es Gerenciamento M�sicas /////////////
////////////////////////////////////////////////////////

// Fun��o para carregar as pastas
function carregar_pastas( porta ) {

  if(porta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Limpa a lista de playlist j� carregadas
  document.getElementById("lista-pastas").innerHTML = "";
  
  document.getElementById("status_lista_pastas").innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById("status_lista_pastas").style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/carregar_lista_pastas/"+porta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_pastas = resultado.split(";");
	
	for(var cont = 0; cont < array_pastas.length; cont++) {	
	 
	if(array_pastas[cont]) {
	
	dados_pasta = array_pastas[cont].split("|");
	
	var nova_pasta = document.createElement("li");
	
	nova_pasta.innerHTML = "<img src='/admin/img/icones/img-icone-pasta.png' align='absmiddle' />&nbsp;<a href='javascript:carregar_musicas_pasta(\""+porta+"\",\""+dados_pasta[0]+"\");'>"+dados_pasta[0]+"&nbsp;("+dados_pasta[1]+")</a><a href='javascript:remover_pasta(\""+porta+"\",\""+dados_pasta[0]+"\")' style='float:right;'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover' title='Remover' border='0' align='absmiddle' /></a><a href='javascript:renomear_pasta(\""+porta+"\",\""+dados_pasta[0]+"\")' style='float:right;padding-right:5px;'><img src='/admin/img/icones/img-icone-renomear.png' alt='Renomear' title='Renomear' border='0' align='absmiddle' /></a>";
  
    document.getElementById("lista-pastas").appendChild(nova_pasta);
	
	document.getElementById("status_lista_pastas").style.display = "none";
	
	}
	
	}
	
	} else {
	
	document.getElementById("status_lista_playlists").innerHTML = "Nenhuma pasta encontrada.";
	
	}
  
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para carregar as m�sicas da pasta do FTP no gerenciamento de musicas
function carregar_musicas_pasta( porta,pasta ) {
	
  if(porta == "" || pasta == "") {
  alert("Erro! Tente novamente ou contate o suporte.");
  } else {
  
  // Limpa a lista de m�sicas j� carregadas
  document.getElementById("lista-musicas-pasta").innerHTML = "";
  
  // Seleciona a pasta para uploads
  document.getElementById("pasta_selecionada").value = pasta;
  document.getElementById("msg_pasta_selecionada").innerHTML = "Pasta Selecionada: "+pasta+"";
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  document.getElementById('msg_pasta').style.display = "none";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/carregar_musicas_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(resultado) {
	
	array_musicas = resultado.split(";");
	
	for(var cont = 0; cont < array_musicas.length; cont++) {	
	 
	if(array_musicas[cont]) {
	
	dados_musica = array_musicas[cont].split("|");
	
	var nova_musica = document.createElement("li");
  
    nova_musica.innerHTML = "<img src='/admin/img/icones/img-icone-arquivo-musica.png' border='0' align='absmiddle' />&nbsp;"+dados_musica[1]+"<span style='float:right;'><a href='javascript:renomear_musica_ftp(\""+porta+"\",\""+dados_musica[0]+"\");' title='Renomear "+dados_musica[1]+"'><img src='/admin/img/icones/img-icone-renomear.png' border='0' style='padding-right:5px;' align='absmiddle' /></a><a href='javascript:remover_musica_ftp(\""+porta+"\",\""+dados_musica[0]+"\")'><img src='/admin/img/icones/img-icone-fechar.png' width='16' height='16' alt='Remover "+dados_musica[1]+"' title='Remover "+dados_musica[1]+"' border='0' align='absmiddle' /></a></span>";
  
    document.getElementById("lista-musicas-pasta").appendChild(nova_musica);
	
	}
	
	}
	
	}
	
  document.getElementById('log-sistema-fundo').style.display = "none";
  document.getElementById('log-sistema').style.display = "none";
  
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para criar uma nova pasta no FTP
function criar_pasta( porta ) {
  
  var pasta = prompt('Informe um nome para a nova pasta:\n(N�o use caracteres especiais e acentos)');
	
  if(pasta != "" && pasta != null) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/criar_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	document.getElementById("log-sistema-conteudo").style.fontSize = "25px";

	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para renomear uma musica no FTP
function renomear_pasta( porta,pasta ) {

  if(pasta == "") {  
  alert("Aten��o! Voc� deve clicar na pasta que deseja renomear.");  
  } else {
	  
  novo = prompt ("Informe o novo nome para a pasta:\n(N�o use caracteres especiais e acentos)");
  
  if(novo != "" && novo != null) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/renomear_pasta/"+porta+"/"+pasta+"/"+novo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  
  }
  
  }
}

// Fun��o para remover uma pasta
function remover_pasta( porta,pasta ) {
  
  if(window.confirm("Deseja realmente remover esta pasta e todas as suas m�sicas?")) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/remover_pasta/"+porta+"/"+pasta , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  }
}

// Fun��o para renomear uma musica no FTP
function renomear_musica_ftp( porta,musica,novo ) {

  if(musica == "") {  
  alert("Aten��o! Voc� deve clicar na m�sica que deseja renomear.");  
  } else {
	  
  novo = prompt ("Informe o novo nome para a m�sica:\n(N�o use caracteres especiais e acentos)");
  
  if(novo != "" && novo != null) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var musica = musica.replace("/", "|");
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/renomear_musica_ftp/"+porta+"/"+musica+"/"+novo , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  
  }
  
  }
}

// Fun��o para remover uma musica no FTP
function remover_musica_ftp( porta,musica ) {

  if(musica == "") {  
  alert("Aten��o! Voc� deve selecionar a m�sica que deseja remover.");  
  } else {
  
  if(window.confirm("Deseja realmente remover esta m�sica?")) {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  var musica = musica.replace("/", "|");
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/remover_musica_ftp/"+porta+"/"+musica , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
	
	resultado = http.responseText;

	document.getElementById("log-sistema-conteudo").innerHTML = resultado;
	
  }
  
  }
  http.send(null);
  delete http;
  }
  }
}

// Fun��o para iniciar envio de m�sicas
function enviar_musicas( pasta ) {
  
  if(pasta == "") {
  
  alert("Aten��o! Voc� deve clicar em uma pasta para onde ser�o enviada(s) a(s) m�sica(s) para seleciona-la.");  
  
  } else {
  
  document.getElementById('log-sistema-conteudo').innerHTML = "<img src='http://"+get_host()+"/admin/img/ajax-loader.gif' />";
  document.getElementById('log-sistema-fundo').style.display = "block";
  document.getElementById('log-sistema').style.display = "block";
  
  document.gerenciador.submit();
  
  }

}

// Fun��o para checar a estatistica de uso do plano e criar barra de porcentagem de uso
function estatistica_uso_plano( porta,recurso,texto ) {
  
  if(recurso == "ouvintes") {
  document.getElementById('estatistica_uso_plano_ouvintes').innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
  } else {
  document.getElementById('estatistica_uso_plano_ftp').innerHTML = "<img src='http://"+get_host()+"/admin/img/spinner.gif' />";
  }
  
  var http = new Ajax();
  http.open("GET", "/admin/funcoes-ajax-musicas/estatistica_uso_plano/"+porta+"/"+recurso+"/"+texto , true);
  http.onreadystatechange = function() {
	
  if(http.readyState == 4) {
  
	resultado = http.responseText;
	
	if(recurso == "ouvintes") {
  	document.getElementById('estatistica_uso_plano_ouvintes').innerHTML = resultado;
  	} else {
  	document.getElementById('estatistica_uso_plano_ftp').innerHTML = resultado;
  	}
	
  }
  
  }
  http.send(null);
  delete http;
}

// Fun��o para adicionar campos no formulario de upload
var input = 0; 
function adicionar_campo_upload( local ) {

var novadiv = document.createElement("div"); 
novadiv.innerHTML = "<input name='novas_musicas[]' type='file' class='botao_padrao' id='novas_musicas[]' size='60' />"; 
document.getElementById(local).appendChild(novadiv); 

input++;

}

// Fun��o para obter o host
function get_host() {

var url = location.href;
url = url.split("/");

return url[2];

}

// Rotina AJAX
function Ajax() {
var req;

try {
 req = new ActiveXObject("Microsoft.XMLHTTP");
} catch(e) {
 try {
	req = new ActiveXObject("Msxml2.XMLHTTP");
 } catch(ex) {
	try {
	 req = new XMLHttpRequest();
	} catch(exc) {
	 alert("Esse browser n�o tem recursos para uso do Ajax");
	 req = null;
	}
 }
}

return req;
}