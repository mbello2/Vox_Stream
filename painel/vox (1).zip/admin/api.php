<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 600);

// Inclus&atilde;o de classes
require_once('inc/classe.ssh.php');

/*
api -> query_string('2');
acao -> query_string('3');
porta -> query_string('4');
*/

$chave_api = query_string('2');
$acao = query_string('3');

// Verifica se a chave da api foi informada
if($chave_api == "") {
echo "0||Chave da API vazia.";
exit();
}

// Verifica se a chave da api esta configurada
$valida_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE chave_api = '".$chave_api."'"));

if($valida_revenda == 0) {
echo "0||Chave da API inv&aacute;lida.";
exit();
}

// Fun��o para cadastrar streaming
if($acao == "cadastrar") {
	
	$ouvintes = query_string('4');
	$bitrate = query_string('5');
	$espaco = query_string('6');
	$senha = query_string('7');
	$aacplus = query_string('8');

	// Verifica a �ltima gerada e gera a pr�xima
	$porta_livre_stm = false;
	$porta_livre_dj = false;

	$nova_porta_stm = 7998;
	$nova_porta_dj = 34998;

	// Porta Streaming
	while(!$porta_livre_stm) {

	$nova_porta_stm += 2;

	$total_porta_livre_stm = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta = '".$nova_porta_stm."' ORDER BY porta"));

	if($total_porta_livre_stm == 0) {
	$porta_livre_stm = true;
	}

	}

	// Porta DJ
	while(!$porta_livre_dj) {

	$nova_porta_dj += 2;

	$total_porta_livre_dj = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta_dj = '".$nova_porta_dj."' ORDER BY porta_dj"));

	if($total_porta_livre_dj == 0) {
	$porta_livre_dj = true;
	}

	}

	$porta = $nova_porta_stm;
	$porta_dj = $nova_porta_dj;

	// Verifica os limites do cliente
	$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE chave_api = '".$chave_api."'"));
	$total_streamings_revenda = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
	$ouvintes_revenda = mysql_fetch_array(mysql_query("SELECT SUM(ouvintes) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));
	$espaco_revenda = mysql_fetch_array(mysql_query("SELECT SUM(espaco) as total FROM streamings WHERE codigo_cliente = '".$dados_revenda["codigo"]."'"));

	// Verifica se excedeu o limite de streamings do cliente
	$total_streamings_revenda = $total_streamings_revenda+1;

	if($total_streamings_revenda > $dados_revenda["streamings"]) {
		echo "0||Limite de streamings atingido.";
		exit();
	}

	// Verifica se excedeu o limite de ouvintes do cliente
	$total_ouvintes_revenda = $ouvintes_revenda["total"]+$ouvintes;

	if($total_ouvintes_revenda > $dados_revenda["ouvintes"]) {
		echo "0||Limite de ouvintes atingido.";
		exit();
	}

	// Verifica se excedeu o limite de ouvintes do cliente
	$total_espaco_revenda = $espaco_revenda["total"]+$espaco;

	if($total_espaco_revenda > $dados_revenda["espaco"]) {
		echo "0||Limite de espa&ccedil;o para autodj atingido.";
		exit();
	}

	// Verifica se excedeu o limite de bitrate do cliente
	if($bitrate > $dados_revenda["bitrate"]) {
		echo "0||Limite de bitrate atingido.";
		exit();
	}
	
	// Carrega as configura&ccedil;�es do sistema
	$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
	
	if($dados_revenda["aacplus"] == 'sim' && $aacplus == 'sim') {
	
	$servidor_aacplus = $dados_config["codigo_servidor_aacplus_atual"];
	$encoder = "aacp";
	$aacplus = "sim";
	
	} else {
	
	$servidor_aacplus = 0;
	$encoder = "mp3";
	$aacplus = "nao";
	
	}
	
	mysql_query("INSERT INTO streamings (codigo_cliente,codigo_servidor,codigo_servidor_aacplus,porta,porta_dj,ouvintes,bitrate,bitrate_autodj,encoder,espaco,senha,ftp_dir,aacplus,data_cadastro) VALUES ('".$dados_revenda["codigo"]."','".$dados_config["codigo_servidor_atual"]."','".$servidor_aacplus."','".$porta."','".$porta_dj."','".$ouvintes."','".$bitrate."','".$bitrate."','".$encoder."','".$espaco."','".$senha."','/home/streaming/".$porta."','".$aacplus."',NOW())");
	
	if(!mysql_error()) {
	
		$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_config["codigo_servidor_atual"]."'"));
		
		// Loga a a��o executada
		mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('cadastro_streaming_whmcs',NOW(),'".$_SERVER['REMOTE_ADDR']."','Cadastrado streaming ".$porta." no servidor ".$dados_servidor["ip"]." pela revenda ".$dados_revenda["nome"]."')");
	
		echo "1|".$dados_servidor["ip"].":".$porta."|Streaming cadastrado com sucesso.";	
	
	} else {
		echo "0||Erro ao executar query no mysql: ".mysql_error()."";
	}
	
	exit();
}

// Fun��o para bloquear streaming
if($acao == "bloquear") {

	$porta = query_string('4');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Verifica se a chave da api informada � do cliente propriet&aacute;rio do streaming
	$valida_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE chave_api = '".$chave_api."' AND codigo = '".$dados_stm["codigo_cliente"]."'"));
	
	if($valida_revenda == 0) {
		echo "0|".$dados_stm["porta"]."|Permiss&atilde;o negada.";
		exit();
	}

	// Conex&atilde;o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];

	// Bloqueia o streaming no servidor
	$ssh->executar("iptables -A INPUT -p tcp --dport ".$porta." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -A INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
		mysql_query("Update streamings set status = '3' where codigo = '".$dados_stm["codigo"]."'");
		
		// Loga a a��o executada
		mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('bloquear_streaming_whmcs',NOW(),'".$_SERVER['REMOTE_ADDR']."','Bloqueio do streaming ".$dados_stm["porta"]."')");
	
		echo "1|".$dados_stm["porta"]."|Streaming bloqueado com sucesso.";
	
	} else {
	
		mysql_query("Update streamings status = '3' where codigo = '".$dados_stm["codigo"]."'");
	
		echo "0|".$dados_stm["porta"]."|Erro desconhecido.";
	}
	
	exit();
}

// Fun��o para desbloquear streaming
if($acao == "desbloquear") {
	
	$porta = query_string('4');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	
	// Verifica se a chave da api informada � do cliente propriet&aacute;rio do streaming
	$valida_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE chave_api = '".$chave_api."' AND codigo = '".$dados_stm["codigo_cliente"]."'"));
	
	if($valida_revenda == 0) {
		echo "0|".$dados_stm["porta"]."|Permiss&atilde;o negada.";
		exit();
	}
	
	if($dados_stm["status"] == 2) {
		echo "0|".$dados_stm["porta"]."|Permiss&atilde;o negada.";
		exit();
	}	
	
	// Conex&atilde;o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	// Desbloqueia o streaming no servidor
	$resultado = $ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save");
	
	mysql_query("Update streamings set status = '1' where codigo = '".$dados_stm["codigo"]."'");
	
	// Loga a a��o executada
	mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('desbloquear_streaming_whmcs',NOW(),'".$_SERVER['REMOTE_ADDR']."','Desbloqueio do streaming ".$dados_stm["porta"]."')");
	
	echo "1|".$dados_stm["porta"]."|Streaming desbloqueado com sucesso.";
	
	exit();
}

// Fun��o para remover streaming
if($acao == "remover") {
	
	$porta = query_string('4');
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
	$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));

	// Verifica se a chave da api informada � do cliente propriet&aacute;rio do streaming
	$valida_revenda = mysql_num_rows(mysql_query("SELECT * FROM revendas WHERE chave_api = '".$chave_api."' AND codigo = '".$dados_stm["codigo_cliente"]."'"));
	
	if($valida_revenda == 0) {
		echo "0|".$dados_stm["porta"]."|Permiss&atilde;o negada.";
		exit();
	}
	
	// Conex&atilde;o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "ligado") {
	
	// Desliga o autodj caso esteja ligado
	$status_autodj = $ssh->executar("nice --adjustment=-20 nmap -sT -p ".$dados_stm["porta_dj"]." localhost | grep open | wc -l");
	
	if($status_autodj == 1) {
	$ssh->executar("/home/streaming/desligar_autodj ".$dados_stm["porta"]." ".$dados_stm["porta_dj"]."");
	}

	$resultado = $ssh->executar("/home/streaming/desligar_streaming ".$dados_stm["porta"]."");
		
	$resultado = str_replace("\n","",$resultado);
	
	} else {
	$resultado = "ok";
	}
	
	if($resultado == "ok") {
	
	$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
	
	if($status_streaming == "desligado") {
	
	// Desbloqueia o streaming no servidor
	$porta = $dados_stm["porta"];
	$porta_ouvinte = $dados_stm["porta"]+1;
	$porta_dj = $dados_stm["porta_dj"];
	
	$ssh->executar("iptables -D INPUT -p tcp --dport ".$porta." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_ouvinte." -j DROP;iptables -D INPUT -p tcp --dport ".$porta_dj." -j DROP;service iptables save;echo ok");
	
	$ssh->executar("rm -rf /home/streaming/".$dados_stm["porta"]." /home/streaming/configs/*".$dados_stm["porta"]."* /home/streaming/logs/*".$dados_stm["porta"]."* /home/streaming/playlists/".$dados_stm["porta"]."-*.pls;echo ok");
	
	mysql_query("Delete From streamings where codigo = '".$dados_stm["codigo"]."'");
	
	// Remove as playlists
	$query_playlists = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'");
	while ($dados_playlist = mysql_fetch_array($query_playlists)) {
	
	mysql_query("Delete From playlists where codigo = '".$dados_playlist["codigo"]."'");
	mysql_query("Delete From playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'");
	
	}
	
	// Remove as estatisticas
	mysql_query("Delete From estatisticas where codigo_stm = '".$dados_stm["codigo"]."'");

	// Remove os DJs
	mysql_query("Delete From djs where codigo_stm = '".$dados_stm["codigo"]."'");
	
	// Remove os Agendamentos
	mysql_query("Delete From playlists_agendamentos where codigo_stm = '".$dados_stm["codigo"]."'");
	
	// Loga a a��o executada
    mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('".$acao."',NOW(),'".$_SERVER['REMOTE_ADDR']."','Remo��o do streaming ".$dados_stm["porta"]." ".$status_log."')");
	
	// Desativa o relay no servidor RTMP	
	if($dados_stm["aacplus"] == 'sim') {
	
	$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
	
	// Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor_aacplus["ip"],$dados_servidor_aacplus["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor_aacplus["senha"],"D"));

	$ssh->executar("/usr/local/WowzaMediaServer/desativar-aacplus ".$dados_stm["porta"]."");
	
	}
	
	// Loga a a��o executada
	mysql_query("INSERT INTO logs (acao,data,ip,log) VALUES ('remover_streaming_whmcs',NOW(),'".$_SERVER['REMOTE_ADDR']."','Remo��o do streaming ".$dados_stm["porta"]." pela revenda ".$dados_revenda["nome"]."')");
	
	echo "1|".$dados_stm["porta"]."|Streaming removido com sucesso.";
	
	} else {
	
	echo "0|".$dados_stm["porta"]."|Erro desconhecido.";
	}
	
	} else {
	echo "0|".$dados_stm["porta"]."|".$resultado."";
	}
	
	exit();
}
?>