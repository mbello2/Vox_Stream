<?php
require_once("inc/protecao-admin.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax.js"></script>
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>
<div id="topo">
<div id="topo-conteudo" style="background:url(/admin/img/img-logo-painel.gif) no-repeat left;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
  		<li>&nbsp;&nbsp;&nbsp;</li>
        <li><a href="/admin/admin-cadastrar-streaming" class="texto_menu">Cadastrar Streaming</a></li>
  		<li><em></em><a href="/admin/admin-streamings" class="texto_menu">Streamings</a></li>
  		<li><em></em><a href="/admin/admin-cadastrar-revenda" class="texto_menu">Cadastrar Revenda</a></li>
  		<li><em></em><a href="/admin/admin-revendas" class="texto_menu">Revendas</a></li>
        <li><em></em><a href="/admin/admin-cadastrar-servidor" class="texto_menu">Cadastrar Servidor</a></li>
        <li><em></em><a href="/admin/admin-servidores" class="texto_menu">Servidores</a></li>
        <li><em></em><a href="/admin/admin-configuracoes" class="texto_menu">Configura��es</a></li>
        <li><em></em><a href="/admin/sair" class="texto_menu">Sair</a></li>
  	</ul>
</div>
</div>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
<form style="padding:0; margin:0" onsubmit="buscar_revenda(document.getElementById('chave').value);return false;">
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px;">
    <tr>
      <td width="30" align="center" class="texto_padrao_destaque" scope="col"><img src="/admin/img/icones/img-icone-cadastrar.png" alt="Cadastrar" width="16" height="16" /></td>
      <td width="300" align="left" scope="col"><a href="/admin/admin-cadastrar-revenda" class="texto_padrao_destaque">Cadastrar Revenda</a></td>
      <td width="520" align="right" class="texto_padrao_destaque" scope="col">
      Buscar por
        <input name="chave" type="text" id="chave" />
        <input type="button" class="botao_padrao" value="Buscar" onclick="buscar_revenda(document.getElementById('chave').value);" />      </td>
    </tr>
  </table>
</form>
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="350" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Responsavel</td>
      <td width="280" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Configura��o</td>
      <td width="90" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Streamings</td>
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;A��es</td>
    </tr>
<?php
if(query_string('2') == 'resultado') {

$cat = (preg_match("/@/i",query_string('3'))) ? "email" : "nome";

$query = "SELECT * FROM revendas where ".$cat." like '%".query_string('3')."%'";
$pagina_atual = query_string('4');

} else {
$query = "SELECT * FROM revendas";
$pagina_atual = query_string('4');
}

$sql = mysql_query("".$query."");
$lpp = 500; // total de registros por p&aacute;gina
$total = mysql_num_rows($sql);
$paginas = ceil($total / $lpp); 
if(!isset($pagina_atual)) { $pagina_atual = 0; }
$inicio = $pagina_atual * $lpp;
$sql = mysql_query("".$query." ORDER by nome ASC LIMIT $inicio, $lpp");

while ($dados_revenda = mysql_fetch_array($sql)) {

$total_stm = mysql_num_rows(mysql_query("SELECT * FROM streamings where codigo_cliente = '".$dados_revenda["codigo"]."'"));

$responsavel = (strlen($dados_revenda["nome"]) > 45) ? substr($dados_revenda["nome"], 0, 40)."..." : $dados_revenda["nome"];

$cor_status = ($dados_revenda["status"] == 1) ? "#FFFFFF" : "#FFB3B3";

$revenda_code = code_decode($dados_revenda["codigo"],"E");

list($nome_revenda_personalizado_financeiro, $codigo_revenda_personalizado_financeiro) = explode("-",$dados_revenda["nome"]);

echo "<tr style='background-color:".$cor_status.";'>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$responsavel."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_revenda["streamings"]." stm. / ".$dados_revenda["ouvintes"]." ouvin. / ".$dados_revenda["bitrate"]." Kbps / ".$dados_revenda["espaco"]." Mb</td>
<td height='25' align='center' scope='col' class='texto_padrao'>&nbsp;".$total_stm."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>
<select style='width:100%' id='".$revenda_code."' onchange='executar_acao_revenda(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <optgroup label='Administra��o'>
  <option value='bloquear'>Bloquear</option>
  <option value='desbloquear'>Desbloquear</option>
  <option value='configurar'>Alterar Configura��es</option>
  <option value='remover'>Remover</option>
  </optgroup>
  <optgroup label='Streamings'>
  <option value='listar-streamings'>Listar Streamings</option>
  <option value='alterar-servidor'>Alterar Servidor</option>
  <option value='exportar-lista-streamings'>Exportar Lista de Streamings</option>
  </optgroup>
</select>
</td>
</tr>";

}
?>
  </table>
  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0" style=" border:#D5D5D5 1px solid;">
    <tr>
      <td height="20" align="center"><?php
$total_registros = mysql_num_rows(mysql_query("".$query.""));

if($total_registros == 0) {
echo "<span class=\"texto_padrao_destaque\">Nenhuma revenda encontrada.</span>";
} else {

$pagina_atual = query_string('2');
	
	for($i = 0; $i < $paginas; $i++) {
      $linksp = $i + 1;
      if ($pagina_atual == $i) {
              echo " <span class=\"texto_padrao_destaque\" title=\"P&aacute;gina $linksp\">$linksp</span>";
      } else {
              $url = "/admin/admin-revendas/".query_string('2')."/".query_string('3')."/$i";
              echo " <a href=\"$url\" class=\"texto_padrao\" title=\"Ir para p&aacute;gina $linksp\">$linksp</a></span>";
      }
	}

}
?>      </td>
    </tr>
  </table>
</div>

<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"><img src="/admin/img/ajax-loader.gif" /></div>
</div>
<!-- Fim div log do sistema -->
</body>
</html>
