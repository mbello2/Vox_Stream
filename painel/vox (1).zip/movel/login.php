<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link href="../admin/inc/estilo-movel.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form method="post" action="/movel/login-autentica" style="margin:0px; padding:0px;">
  <table width="270" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="margin-top:15%; border:#CCCCCC 1px solid;">
    <tr>
      <td width="134" rowspan="5" align="center" class="texto_titulo" scope="col">Gerenciar Streaming<br />
        <span class="texto_padrao_pequeno">Vers&atilde;o para Celular</span></td>
      <td width="134" height="25" align="left" class="texto_padrao_destaque" scope="col">Porta</td>
    </tr>
    <tr>
      <td class="texto_padrao2" scope="col" align="left"><input name="porta" type="text" id="porta" size="10" />      </td>
    </tr>
    <tr>
      <td height="25" class="texto_padrao_destaque" align="left" scope="col">Senha</td>
    </tr>
    <tr>
      <td class="texto_padrao2" align="left"><input name="senha" type="password" id="senha" size="10" />      </td>
    </tr>
    <tr>
      <td height="40" align="left"><input name="submit" type="submit" class="botao" style="width:100px" value="Acessar" /></td>
    </tr>
    <tr>
      <td align="center" colspan="4" scope="col"><?php echo $_SESSION[status_login]; unset($_SESSION[status_login]); ?></td>
    </tr>
  </table>
</form>
</body>
</html>
