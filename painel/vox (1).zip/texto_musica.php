<?php
$porta = code_decode(query_string('1'),"D");
$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));

?>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script language="javascript" src="/js/jquery-1.9.1.min.js"></script>
<script language="javascript" src="/js/jquery.timers-1.0.0.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   var j = jQuery.noConflict();
	j(document).ready(function()
	{
		j(".refresh").everyTime(10000,function(i){
			j.ajax({
			  url: "/texto_musica_config/<?=$dados_stm["porta"];?>/vai",
			  cache: false,
			  success: function(html){
				j(".refresh").html(html);
			  }
			})
		})
	});
   j(".refresh").css({color:"white"});
});
</script>
<style type="text/css">
body
{
   margin: 0;
   padding: 0;
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<div class="refresh"><span style="color:#006400;font-family:Tahoma;font-size:10px;">Carregando...</span></div>