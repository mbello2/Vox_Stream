<?php
require_once("admin/inc/protecao-final.php");
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$sql_pesquisa = mysql_query("SELECT nome FROM playlists WHERE codigo = '$dados_stm[ultima_playlist]'");
$result_playlist = mysql_fetch_array($sql_pesquisa);
$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";
$porta_code = code_decode($dados_stm["porta"],"E");
$dados_revenda["RTMP"];
$dados_revenda["email"];
$dados_revenda["video"];
$playlist_atual = "Sem playlist";

$porta = "$dados_stm[porta]";
$dados_administradores = mysql_fetch_array(mysql_query("SELECT * FROM administradores WHERE codigo = '1'"));
$dados_administradores["avisos"];
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
$url = "http://" . $_SERVER['HTTP_HOST'] . "/" . $_SERVER['PHP_SELF'] . "/" . $_SERVER['QUERYSTRING'] . "/";
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
if($status_streaming == "ligado"){
	$openu = fsockopen("$dados_servidor[ip]","$dados_stm[porta]");
	if($openu){ 
		fputs($openu,"GET /7.html HTTP/1.1\nUser-Agent:Mozilla\n\n"); 
		$readu = fread($openu,1000); 
		$textu = explode("content-type:text/html",$readu); 
		$textu = explode(",",$textu[1]); 
	}else{
		$er="Connection Refused!";
	}
	if($textu[1]==1){$stateu = "Up";}else{$stateu = "Down";} 
	if($er){echo $er; exit;}
}


?>

<!--
<?php


 
    shell_exec('mkdir -p {teste/,upload/savefiles/$porta/} ');
 
?>--!>




<?php 
//PORTUGU�S.
if($dados_stm["idioma"] == 'streaming-br') { ?>
<?
include_once "idioma/streaming-br.php";
?>
<?php } else { ?>
<?php } ?>
<?php 
//INGL�S.
if($dados_stm["idioma"] == 'streaming-en') { ?>
<?
include_once "idioma/streaming-en.php";
?>
<?php } else { ?>
<?php } ?>
<?php
//ESPANHOL.
 if($dados_stm["idioma"] == 'streaming-es') { ?>
<?
include_once "idioma/streaming-es.php";
?>
<?php } else { ?>
<?php } ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo "$Config_titulo";?></title><center><?php if($dados_stm["status"] == '1') { ?>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
<link href="/admin/inc/estilo-menu.css" rel="stylesheet" type="text/css" /> <!-- Fun��o para o menu superior --!>
<link href="admin/css/estilo-streaming.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
<link href="/admin/css/estilo-menu.css" rel="stylesheet" type="text/css" />
<link href="/admin/css/estilo-streaming.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/idioma/<?php echo $dados_stm["idioma"]; ?>/ajax-streaming.js"></script>
<script type="text/javascript" src="/idioma/<?php echo $dados_stm["idioma"]; ?>/javascript.js"></script>
<script type="text/javascript" src="/idioma/<?php echo $dados_stm["idioma"]; ?>/sorttable.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
</head>
 <body>
<div id="topo">
<div id="topo-conteudo-cliente" style="background:url(<?php echo $url_logo; ?>) center center no-repeat;"></div>
</div>
<div id="menu">
<div id="menu-links">
  	<ul>
        <li style="width:250px">&nbsp;</li>
        <li><a href="/streaming" class="texto_menu"><?php echo "$menu_streaming";?></a></li>
        <li><a href="/api-streaming" class="texto_menu"><?php echo "$menu_api";?></a></li>
        <li><em></em><a href="/config"class="texto_menu"><?php echo "$menu_configuracoes";?></a></li>
        <li><em></em><a href="/sair"class="texto_menu"><?php echo "$menu_sair";?></a></li>
  	</ul>


</div>
</div>
<div id="conteudo"><center>
<?php
//P�ginas...
if($dados_stm["app_status"] == '1') { ?>


<div id="quadro">
<div id="quadro-topo"> <strong>Instru��es</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;">
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Siga as instru��es abaixo de cada campo para evitar erros na cria��o e layout do seu app.</p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">A logomarca e o �cone devem ter fundo transpar�nte e ser uma imagem PNG.</p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Se for usar um fundo colorido teste antes colocando a logomarca em cima do fundo(em um editor de imagem) para ver se fica com contraste bom.</p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">N�o use medidas menores ou maiores do que as espec�ficadas abaixo de cada campo.</p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Se n�o tiver facebook ou twitter, deixe estes campos totalmente em branco que ser� usado a URL do site no lugar deles.</p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">O App ser� criado e disponibilizado para download no mesmo instante da solicita��o caso n�o haja nenhum erro.</p></span>
</table></div></div><br>

<div id="quadro">
<div id="quadro-topo"> <strong>UPLOAD DA LOGOMARCA</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:20px;"><center>
<p><img src="/imagem/icon-android.png" id="Image1" alt="" style="width:37px;height:37px;"><b>Logomarca</b> (Deve ter exatamente <b>235x235 pixels</b>, fundo transparente e ser PNG)</span><p>

<?php require_once "phpuploader/include_phpuploader.php" ?>
<?php session_start(); ?>

<div>
	<?php
		$uploader=new PhpUploader();

		$uploader->FilesUpload=true;
		$uploader->InsertText="Selecione a Logomarca";
		
		$uploader->MaxSizeKB=350;
		$uploader->AllowedFileExtensions="*.png";
		
		$uploader->UploadUrl="upload/logomarca_upload.php?porta=$porta";
		
		$uploader->Render();
	?>
	
	
	

</div></center>
</div></span>

</table>
<br><tr>
<form method="post" action="/app_android_passos" style="padding:0px; margin:0px">
<input type="hidden" name="senha" value="<?php echo $dados_stm["senha"]; ?>" />
<input type="hidden" name="app_status" value="2" />
<input type="hidden" name="app_infor" value="Processando..." />
</div><br>
<div id="quadro">
<div id="quadro-topo"> <strong>O que deseja fazer?</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;">




<center>
<br>
<input type="submit" class="botao" value="Continuar" />
<input type="button" class="botao" value="Cancelar solicita��o" onclick="window.location = '/streaming';" /></td>
</tr><br>
</form>
</table></center>


<?php } else { ?>
<?php } ?>
<?php
//P�ginas...
if($dados_stm["app_status"] == '2') { ?>
<div id="quadro">
<div id="quadro-topo"> <strong>UPLOAD DO �CONE</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:20px;"><center>
<p><img src="/imagem/icon-android.png" id="Image1" alt="" style="width:37px;height:37px;"><b>�cone</b>     (Deve ter exatamente <b>144x144 pixels</b>, fundo transparente e ser PNG)</p>

<?php require_once "phpuploader/include_phpuploader.php" ?>
<?php session_start(); ?>

<div>
	<?php
		$uploader=new PhpUploader();

		$uploader->FilesUpload=true;
		$uploader->InsertText="Selecione o �cone";
		
		$uploader->MaxSizeKB=150;
		$uploader->AllowedFileExtensions="*.png";
		
		$uploader->UploadUrl="upload/icone_upload.php?porta=$porta";
		
		$uploader->Render();
	?>
	
	
	</div>


</div></span></center>

</table>
<br><tr>
<form method="post" action="/app_android_passos" style="padding:0px; margin:0px">
<input type="hidden" name="senha" value="<?php echo $dados_stm["senha"]; ?>" />
<input type="hidden" name="app_status" value="3" />
</div><br>
<div id="quadro">
<div id="quadro-topo"> <strong>O que deseja fazer?</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;">


<center>
<br>
<input type="hidden" name="app_infor" value="Processando..." />
<input type="submit" class="botao" value="Continuar" />
<input type="button" class="botao" value="Cancelar solicita��o" onclick="window.location = '/streaming';" /></td>
</tr><br>
</form>
</table></center>


<?php } else { ?>
<?php } ?>
<?php
//P�ginas...
if($dados_stm["app_status"] == '3') { ?>



<div id="quadro">
<div id="quadro-topo"> <strong>UPLOAD DO FUNDO</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:20px;"><center>
<p><img src="/imagem/icon-android.png" id="Image1" alt="" style="width:37px;height:37px;"><b>Fundo</b>     (Deve ter exatamente <b>640 pixels</b> de largura e <b>1136 pixels</b> de altura e ser JPEG)</p>

<?php require_once "phpuploader/include_phpuploader.php" ?>
<?php session_start(); ?>

<div>
	<?php
		$uploader=new PhpUploader();

		$uploader->FilesUpload=true;
		$uploader->InsertText="Selecione o Fundo";
		
		$uploader->MaxSizeKB=350;
		$uploader->AllowedFileExtensions="*.jpeg,*.jpg";
		
		$uploader->UploadUrl="upload/fundo_upload.php?porta=$porta";
		
		$uploader->Render();
	?>
	
	
	</div>


</div></span></center>

</table>
<br><tr>
<form method="post" action="/app_android_passos" style="padding:0px; margin:0px">
<input type="hidden" name="senha" value="<?php echo $dados_stm["senha"]; ?>" />
<input type="hidden" name="app_infor" value="Processando..." />
<input type="hidden" name="app_status" value="4" />
</div><br>
<div id="quadro">
<div id="quadro-topo"> <strong>O que deseja fazer?</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;"><center>
<br>
<input type="submit" class="botao" value="Continuar" />
<input type="button" class="botao" value="Cancelar solicita��o" onclick="window.location = '/streaming';" /></td>
</tr><br>
</form>
</table></center>


<?php } else { ?>
<?php } ?>
<?php
//P�ginas...
if($dados_stm["app_status"] == '4') { ?>
<div id="quadro">
<div id="quadro-topo"> <strong>Informa��es da R�dio</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;">
</center>
<form method="post" action="/app_android_passos" style="padding:0px; margin:0px">
   
      <tr>
        <td width="750" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Nome</td>
        <td width="750" align="left" class="texto_padrao_pequeno">&nbsp;&nbsp;<input name="app_nome" type="text" class="input" id="app_nome" style="width:750px;" value="" /><br>(M�ximo 30 caracteres, regra do Google Play)</br>          
        
          </td>
      </tr>
      <tr><tr>
        <td width="750" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Site</td>
        <td width="750" align="left" class="texto_padrao_pequeno">&nbsp;&nbsp;<input name="app_site" type="text" class="input" id="app_site" style="width:750px;" value="http://" /><br>(Digite a URL completa com http:// do site da radio)</br>          
        
          </td>
      </tr>

     </tr>
      <tr><tr>
        <td width="750" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Facebook</td>
        <td width="750" align="left" class="texto_padrao_pequeno">&nbsp;&nbsp;<input name="app_face" type="text" class="input" id="app_face" style="width:750px;" value="http://" /><br>(Digite a URL completa com http:// da p�gina ou perfil no facebook, se deixar em branco ser� usado endere�o do site)</br>          
        
          </td>
      </tr>

</tr>
      <tr><tr>
        <td width="750" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Twitter</td>
        <td width="750" align="left" class="texto_padrao_pequeno">&nbsp;&nbsp;<input name="app_twitter" type="text" class="input" id="app_twitter" style="width:750px;" value="http://" /><br>(Digite a URL completa com http:// da p�gina ou perfil no facebook, se deixar em branco ser� usado endere�o do site)</br>          
        
          </td>
      </tr>

</tr>
      <tr><tr>
        <td width="750" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Descri��o</td>
        <td width="750" align="left" class="texto_padrao_pequeno">&nbsp;&nbsp;<textarea name="app_sobre" id="TextArea1" style="width:750px;height:80px;z-index:0;" rows="5" cols="47"></textarea><br>(Deixe aqui uma breve descri��o sobre sua r�dio)</br>          
        
          </td>
      </tr>


      <tr>
     
    </table>
  


</div><br></span>

</table>

<?
//DETERMINA OS CARACTERES QUE CONTER�O A SENHA
$caracteres = "abcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywz
abcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywvzmnopqrabcdefghijlmnopqrztuabcdefgabcdefghiabcdabcdefghijlmnopqrztuvxywzefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywzjlmnopabcdabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvabcdefghijlmnopqrztuvxywzxywzxywzefghijlmnopqrztuvxywzqrztuvxywzhijlmnopqrztuvxywzabcdefghiabcdefghijlmnopqrztuvxywzjlmnopqrztuabcdefghijlmnopqrztuvxywzvxywzvxabcdefghijlabcdefghijabcdefghijlmnopqrztuvxywzlmnopqrztuvxyabcdefghijlmnopqrztuvxywzwzmnopqrztuvxywzywzztuvxywzabcdefghijlmnopqrztuvxywzabcdefghijlmnopqrztuvxywz";
//EMBARALHA OS CARACTERES E PEGA APENAS OS 10 PRIMEIROS
$nome_pacote = substr(str_shuffle($caracteres),0,4);
//EXIBE O RESULTADO

 
?>


</div><br>
<div id="quadro">
<div id="quadro-topo"><strong>Cria��o do App</strong></div><br>

<tr>
        <td height="40"><input name="alterar_dados" type="hidden" id="alterar_dados" value="sim" /></td>
        <td align="left">
          <input type="hidden" name="senha" value="<?php echo $dados_stm["senha"]; ?>" />
          <input type="hidden" name="app_status" value="5" />
          <input type="hidden" name="app_infor" value="Aguardando aprova��o" />
          <input type="hidden" name="app_pacote" value="<?php echo $nome_pacote; ?>" />
          <input type="submit" class="botao" value="Criar App" />
          <input type="button" class="botao" value="Cancelar solicita��o" onclick="window.location = '/streaming';" /></td>
      </tr>
</form>
</table>

<?php } else { ?>
<?php } ?>

<?php
//paginas...
if($dados_stm["app_status"] == '5') { ?>


<div id="quadro">
<div id="quadro-topo"> <strong>Constru��o do APP</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;"><img src="/imagem/img-criando_app.gif" id="criando app" alt="" style="width:74px;height:66px;">
<br><center><img src="/imagem/img-android-carregando.gif" id="Image3" alt="" style="width:197px;height:197px;"><br><br>
<div id="wb_JavaScript1" style="width:505px;height:49px;z-index:0;">
<script type="text/javascript">
var message="Logs:  Seu aplicativo est� (  <?php echo $dados_stm["app_infor"]; ?> )";
var flashspeed=100;
var n=0;

document.write('<font style="color:#000000;font-family:Arial;font-size:14px;font-weight:normal;font-style:normal;text-decoration:none;">');
for (m=0;m<message.length;m++)
   document.write('<span id="neonlight'+m+'">'+message.charAt(m)+'<\/span>');
document.write('<\/font>');

function crossref(number)
{
   var crossobj = document.getElementById("neonlight"+number);
   return crossobj;
}
function neon()
{
   if (n==0)
   {
      for (m=0;m<message.length;m++)
         crossref(m).style.color="#000000";
   }

   crossref(n).style.color="#FF0000";

   if (n<message.length-1)
   {
      n++;
   }
   else
   {
      n=0;
      clearInterval(flashing);
      setTimeout("StartNeon()", 1500);
      return;
   }
}
function StartNeon()
{
   if (document.all||document.getElementById)
      flashing=setInterval("neon()", flashspeed)
}
StartNeon();
</script></div><br>
<?php
//paginas...
if($dados_stm["app_infor"] == 'CANCELADO **Erro nas imagens enviadas**') { ?>
<span style="color:#000000;font-family:Arial;font-size:13px;"><b>OBSERVA��O:</b> Veja se voc� selecionou todas as imagens: <b>logo</b>,<b>�cone</b> e <b>fundo</b> que ser�o necess�rias para que o app seja constru�do corretamente!<p>

<?php } else { ?>
<?php } ?>

<script type="text/javascript" src="http://<?php echo $_SERVER["HTTP_HOST"]; ?>/wwb9.min.js"></script>
<?php
//paginas...
if($dados_stm["app_infor"] == 'Aguardando aprova��o') { ?>
<font style="color:#000000;font-family:Arial;font-size:18px;font-weight:normal;font-style:normal;text-decoration:none;"><a href="javascript:popupwnd('http://<?php echo $_SERVER["HTTP_HOST"]; ?>/visualizar_app_demo?porta=<?=$dados_stm["porta"];?>','no','no','no','no','no','no','','','210','500')" target="_self">Pr�-visualiza��o do APP</a></span><br>
</div></font> O download ser� disponibilizado em breve!<br><br>

<div id="wb_Text2">
<span style="color:#000000;font-family:Arial;font-size:13px;">Veja como seu app esta ficando clicando em "<b>Pr�-visualiza��o do APP</b>" acima,caso n�o goste voc� pode recome�ar clicando em "<b>Fazer um novo APP</b>" <p>

<?php } else { ?>
<?php } ?>
<?php
//paginas...
if($dados_stm["app_infor"] == 'Aguardando aprova��o') { ?>
<font style="color:#000000;font-family:Arial;font-size:14px;font-weight:normal;font-style:normal;text-decoration:none;">
<b>Aten��o:</b> Esse processo de cria��o pode demorar at� 24 horas, voc� pode sair dessa p�gina com seguran�a, seu pedido j� esta sendo processado volte aqui mais tarde para baixar seu aplicativo.<br><p></span>
<?php } else { ?>
<?php } ?>




</span>

</div><br>
</table>
</div></div><br>

<div id="quadro">
<div id="quadro-topo"> <strong>O que deseja fazer?</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;"><center><br>


          <form method="post" action="/app_android_passos" style="padding:0px; margin:0px">
          <input type="hidden" name="senha" value="<?php echo $dados_stm["senha"]; ?>" />
          <input type="hidden" name="app_status" value="1" />
          <input type="hidden" name="app_infor" value="N�o solicitado" />
          <input name="alterar_dados" type="hidden" id="alterar_dados" value="sim" />
          <input type="submit" class="botao" value="Cancelar solicita��o" />
          <input type="submit" class="botao" value="Fazer um novo APP" />

<?php
//CANCELADO **Erro nas imagens enviadas**
if($dados_stm["app_infor"] == 'CANCELADO **Erro nas imagens enviadas**') { ?>
          <input type="submit" class="botao" value="Solicitar novamente" />

<?php } else { ?>
<?php } ?>
<input type="button" class="botao" value="Voltar para o Streaming" onclick="window.location = '/streaming';" /></td>
      </tr>
</form></center>







</span>

</table>

<?php } else { ?>
<?php } ?>


<?php
//paginas...
if($dados_stm["app_status"] == '6') { ?>



<div id="quadro">
<div id="quadro-topo"> <strong>Baixe o seu aplicativo</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;"><center>
<img src="/imagem/img-android-concluido.jpg" id="Image3" alt="" style="width:300px;height:225px;">


<br><br>
<a href="http://<?php echo $_SERVER["HTTP_HOST"]; ?>/upload/apk/<?=$dados_stm["app_modelo"];?>.apk" target="_self"><img src="/imagem/img-baixar-app.png" id="Aguardando download" alt="" style="width:168px;height:70px;"></a></center>
</span>

</div><br>
</table>
</div></div><br>

<div id="quadro">
<div id="quadro-topo"> <strong>O que deseja fazer?</strong></div>
<div class="texto_medio" id="quadro-conteudo">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr></span> <span style="color:#000000;font-family:Arial;font-size:12px;"></center><br>


<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Baixar o App e instalar manualmente no meu celular <a href="http://<?php echo $_SERVER["HTTP_HOST"]; ?>/upload/apk/<?=$dados_stm["app_modelo"];?>.apk" target="_self">Baixar</a></p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Publicar o App no Google Play Store <a href="https://play.google.com/apps/publish/signup/" target="_blank">Acessar</a></p>
<p><img src="/phpuploader/resources/uploadok.png" style="width:16px;height:16px;">Publicar no Amazon Market <a href="https://developer.amazon.com/public/" target="_blank">Acessar</a></p>






</span>

</table>

<?php } else { ?>
<?php } ?>



<script type="text/javascript">

// Checar o status dos streamings

checar_status_streamings('<?php echo $dados_stm["porta"]."|"; ?>');

</script>
 <?php } else { ?>
<span class="texto_status_erro">&nbsp;<br><br><br><img src="Streaming_files/Bloqueado.png" id="Image1" alt="" border="0" </style="width:696px;height:80px;"></span><br><span style="color:#000000;font-family:Arial;font-size:13px;">Entre em contato para mais informa��es atrav�s do email <?php echo $dados_revenda["email"]; ?></span></strong></span><br><br><br>
<?php } ?><br><br></div><br><? include "rodape.php"; ?>
<br><br>
</html>


        