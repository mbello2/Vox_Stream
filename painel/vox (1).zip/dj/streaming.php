<?php
require_once("../admin/inc/protecao-final-dj.php");

list($codigo_stm, $login_dj, $senha_dj) = explode("|",$_SESSION["dj_logado"]);

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$codigo_stm."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));

if($dados_stm["status"] == 1 && $dados_servidor["status"] == "on") {
$info = shoutcast_info($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);
}

$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";

if($dados_stm["aacplus"] == 'sim') {
$formato = "AAC+ sem Plugin(rtmp)";
} elseif($dados_stm["aacplus"] == 'nao' && $dados_stm["encoder"] == 'aacp') {
$formato = "AAC+ simples";
} else {
$formato = "MP3";
}

$porta_code = code_decode($dados_stm["porta"],"E");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link href="../admin/inc/estilo-movel.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="../admin/inc/javascript.js"></script>
<script type="text/javascript" src="../admin/inc/sorttable.js"></script>
</head>

<body>
<div id="conteudo">
<?php if($dados_servidor["status"] == "on") { ?>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" height="5"></td>
  </tr>
  <tr>
    <td align="center">
    <div id="quadro">
       	  <div id="quadro-topo"> <strong>Informa&ccedil;&otilde;es do Streaming</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
					  <table width="290" border="0" cellpadding="0" cellspacing="0">
   						<tr>
						  <td width="85" height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Porta</td>
      							<td width="205" align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $dados_stm["porta"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Porta DJ</td>
      							<td align="left" class="texto_padrao"><?php echo $dados_stm["porta_dj"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;IP</td>
      							<td align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $dados_servidor["ip"]; ?></td>
   						</tr>
   						<tr>
						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Configura��o</td>
      							<td align="left" class="texto_padrao"><?php echo $dados_stm["ouvintes"]; ?> ouvin. / <?php echo $dados_stm["bitrate"]; ?>&nbsp;<span class="texto_padrao_pequeno">Kbps</span> / <?php echo tamanho($dados_stm["espaco"]); ?></td>
   						</tr>
                            <tr>
      							<td height="25" align="left" class="texto_padrao_destaque">&nbsp;ShoutCast</td>
      							<td align="left" class="texto_padrao"><a href="http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>" target="_blank">http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?></a></td>
    						</tr>
                            <?php if($dados_stm["aacplus"] == 'sim') { ?>
                            <tr>
      							<td height="25" align="left" class="texto_padrao_destaque">&nbsp;RTMP(AAC+)</td>
      							<td align="left" class="texto_padrao">rtmp://<?php echo $dados_servidor_aacplus["ip"]; ?>:1935/<?php echo $dados_stm["porta"]; ?></td>
    						</tr>
                            <?php } ?>
					  </table>
		  </div>
      </div>    </td>
  </tr>
  <tr>
    <td align="center" height="5"></td>
  </tr>
  <tr>
    <td align="center">
    <div id="quadro">
            	<div id="quadro-topo"> <strong>Informa&ccedil;&otilde;es de Uso</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
					  <table width="290" border="0" cellpadding="0" cellspacing="0">
			  <tr>
				<td width="85" height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Status</td>
      				<td width="205" height="25" align="left" bgcolor="#F8F8F8" scope="col" class="texto_padrao"><span id="<?php echo $dados_stm["porta"]; ?>" style="cursor:pointer" onclick="status_streaming('<?php echo $dados_stm["porta"]; ?>')"></span></td>
   						</tr>
    						<tr>
                              <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Ouvintes</td>
    						  <td align="left" class="texto_padrao"><span id="estatistica_uso_plano_ouvintes" style="cursor:pointer" onclick="estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes','sim','nao');"></span></td>
  						  </tr>
    						<tr>
                              <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Espa&ccedil;o FTP</td>
                              <td align="left" bgcolor="#F8F8F8" class="texto_padrao"><span id="estatistica_uso_plano_ftp" style="cursor:pointer" onclick="estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','nao');"></span></td>
  						  </tr>
    						<tr>
                              <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Playlists</td>
    						  <td align="left" class="texto_padrao"><?php echo $total_playlists; ?></td>
  						  </tr>
    						<tr>
    						  <td height="25" align="left" bgcolor="#F8F8F8" class="texto_padrao_destaque">&nbsp;Formato</td>
    						  <td align="left" bgcolor="#F8F8F8" class="texto_padrao"><?php echo $formato; ?></td>
  						  </tr>
                          <tr>
                              <td height="25" align="left" class="texto_padrao_destaque">&nbsp;Bitrate Atual</td>
    						  <td align="left" class="texto_padrao"><?php echo $dados_stm["bitrate"]; ?>&nbsp;<span class="texto_padrao_pequeno">Kbps</span></td>
  						  </tr>
                          <tr>
    						  <td height="25" align="left" class="texto_padrao_destaque">&nbsp;M�sica Atual</td>
    						  <td align="left" class="texto_padrao"><?php echo (strlen($info["musica"]) > 30) ? substr($info["musica"], 0, 26)."..." : $info["musica"]; ?></td>
  						  </tr>
					  </table>
                      <br />
                      <center>
					  <?php if($dados_stm["aacplus"] == 'sim') { ?>
					  		<embed src="http://<?php echo $_SERVER['HTTP_HOST']; ?>/player-aacplus.swf" width="200" height="20" allowscriptaccess="always" allowfullscreen="true" flashvars="file=rtmp://<?php echo $dados_servidor_aacplus["ip"].':'.$dados_stm["porta"]; ?>/<?php echo $dados_stm["porta"]; ?>&id=<?php echo $dados_stm["porta"]; ?>.stream&autostart=true" type="application/x-shockwave-flash" /></embed>		  
					  <?php } else { ?>
					  		<embed height="20" width="200" flashvars="file=http://<?php echo $dados_servidor["ip"].':'.$dados_stm["porta"]; ?>/;type=mp3&volume=100&bufferlength=10&autostart=true" allowscriptaccess="always" quality="high" src="http://<?php echo $_SERVER['HTTP_HOST']; ?>/player.swf" type="application/x-shockwave-flash"></embed>			  
					  <?php } ?>
                      </center>
		  </div>
      </div>      </td>
  </tr>
  <tr>
    <td align="center" height="5"></td>
  </tr>
</table>
  <?php } else { ?>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; background-color:#FFFF66; border:#DFDF00 1px dashed">
  <tr>
        <td width="30" height="30" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="270" align="left" class="texto_status_erro_pequeno" scope="col"><?php echo $dados_servidor["mensagem_manutencao"];?></td>
    </tr>
    </table>
  <?php } ?>
</div>
<br />
<br />
<br />
<br />
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="../admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
status_streaming('<?php echo $dados_stm["porta"]; ?>');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes','nao');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','nao');
</script>
</body>
</html>
