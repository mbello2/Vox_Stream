<?php
require_once("admin/inc/protecao-final.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$total_pontos = mysql_num_rows(mysql_query("SELECT * FROM multpoints where codigo_stm = '".$dados_stm["codigo"]."'"));


$qtd_multpoint = 3+$qtd_multpoint++;
if($_POST["cadastrar"]) {

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));

list($dia,$mes,$ano) = explode("/",$_POST["data"]);
$data = $ano."-".$mes."-".$dia;

if(count($_POST["dias"]) > 0){
	$dias = implode(",",$_POST["dias"]);
}

//mysql_query("INSERT INTO multpoints (codigo_stm,frequencia,ponto,bitrate,url,encoder) VALUES ('".$dados_stm["codigo"]."','".$_POST["frequencia"]."','".$_POST["ponto"]."','".$_POST["bitrate"]."','".$_POST["url"]."','".$_POST["encoder"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Multpoint adicionado com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Multpoint adicionado com sucesso,agora reinicie o auto dj.","alerta");

}

?>
<?php 
//PORTUGU�S.
if($dados_stm["idioma"] == 'streaming-br') { ?>
<?
include_once "idioma/streaming-br.php";
?>
<?php } else { ?>
<?php } ?>
<?php 
//INGL�S.
if($dados_stm["idioma"] == 'streaming-en') { ?>
<?
include_once "idioma/streaming-en.php";
?>
<?php } else { ?>
<?php } ?>
<?php
//ESPANHOL.
 if($dados_stm["idioma"] == 'streaming-es') { ?>
<?
include_once "idioma/streaming-es.php";
?>
<?php } else { ?>
<?php } ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Gerenciar Multi Point</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/MultiPoint/ajax-streaming.js"></script>
<script type="text/javascript" src="/admin/inc/MultiPoint/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/MultiPoint/sorttable.js"></script>
</script>
<link rel="stylesheet" href="../cupertino/jquery.ui.all.css" type="text/css">
<style type="text/css">
#jQueryDatePicker1
{
   border: 1px #C0C0C0 solid;
   background-color: #FFFFFF;
   color :#000000;
   font-family: Arial;
   font-size: 13px;
   text-align: left;
   vertical-align: middle;
}
.ui-datepicker
{
   font-family: Arial;
   font-size: 13px;
   z-index: 1003 !important;
   display: none;
}
</style>
<script type="text/javascript" src="../jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="../jquery.ui.core.min.js"></script>
<script type="text/javascript" src="../jquery.ui.widget.min.js"></script>
<script type="text/javascript" src="../jquery.ui.datepicker.min.js"></script>
<script type="text/javascript" src="../jquery.ui.datepicker-pt-BR.js"></script>
<script type="text/javascript" src="jquery.ui.datepicker-pt-BR.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
   var jQueryDatePicker1Opts =
   {
      dateFormat: 'dd/mm/yy',
      changeMonth: false,
      changeYear: false,
      showButtonPanel: false,
      showAnim: 'show'
   };
   $("#data").datepicker(jQueryDatePicker1Opts);
   $("#data").datepicker("setDate", "new Date()");
   $("#data").datepicker("option", $.datepicker.regional['pt-BR']);
});
</script>
</head>
<form method="post" action="/multpoint_cadastra/<?=$porta_code;?>" style="padding:0px; margin:0px" name="agendamentos">
  <table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;; border-bottom:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="120" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Encoder</td>
      <td width="120" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Bit-rate</td>
      <td width="200" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Url do Player</td>
      <td width="120" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;<?php echo "$AutoDJ_agendamento5";?></td>
    </tr>
<?php
$total_agendamentos = mysql_num_rows(mysql_query("SELECT * FROM multpoints where codigo_stm = '".$dados_stm["codigo"]."' ORDER by data"));

if($total_agendamentos > 0) {

$sql = mysql_query("SELECT * FROM multpoints where codigo_stm = '".$dados_stm["codigo"]."' ORDER by data");
while ($dados_agendamento = mysql_fetch_array($sql)) {

$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'"));
list($ano,$mes,$dia) = explode("-",$dados_agendamento["data"]);
$data = $dia."/".$mes."/".$ano;

if($dados_agendamento["frequencia"] == "1") {
$url = "".$dados_servidor["nome"]."";

$encoder = "".$dados_agendamento["encoder"]."";
$bitrate = "".$dados_agendamento["bitrate"]." kbps";
$ponto =   "".$dados_agendamento["ponto"]."";

$qtd_multpoint = 2+$NumAtual++;

} elseif($dados_agendamento["frequencia"] == "2") {
$descricao = "".$dados_agendamento["encoder"]."";
} elseif($dados_agendamento["frequencia"] == "5") {
// Captura a hora atual
        $hora = "".$dados_agendamento["hora"]."";
        // Captura o minuto atual
        $minuto = "".$dados_agendamento["minuto"]."";
        // Ajustar a hora atual 
        $novo_horario = mktime($hora + 0, $minuto + 3);
$descricao = "Ser� executada aproximadamente as  ".date("H", $novo_horario).":".date("i", $novo_horario).":00";
} else {

$array_dias = explode(",",$dados_agendamento["dias"]);

foreach($array_dias as $dia) {

if($dia == "1") {
$dia_nome = "$AutoDJ_agendament_dom";
} elseif($dia == "2") {
$dia_nome = "$AutoDJ_agendament_seg";
} elseif($dia == "4") {
$dia_nome = "$AutoDJ_agendament_ter";
} elseif($dia == "8") {
$dia_nome = "$AutoDJ_agendament_qua";
} elseif($dia == "16") {
$dia_nome = "$AutoDJ_agendament_qui";
} elseif($dia == "32") {
$dia_nome = "$AutoDJ_agendament_sex";
} elseif($dia == "64") {
$dia_nome = "$AutoDJ_agendament_Sab";
}

$lista_dias .= "".$dia_nome.", ";

}

$descricao = "$AutoDJ_agendament40 ( ".substr($lista_dias, 0, -2)." as ".$dados_agendamento["hora"].":".$dados_agendamento["minuto"].")";
$encoder = "".$dados_agendamento["encoder"].")";
}

$repetir = ($dados_agendamento["repetir"] == 1) ? "$AutoDJ_agendamento9" : "$AutoDJ_agendamento8";

$ordem_musical = ($dados_agendamento["shuffle"] == 1) ? "$AutoDJ_agendament10" : "$AutoDJ_agendament11";

$agendamento_code = code_decode($dados_agendamento["codigo"],"E");

echo "<tr>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$encoder."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$bitrate."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;http://".$url.":".$dados_stm["porta"]."/stream/".$qtd_multpoint."/</td>
<td height='25' align='left' scope='col' class='texto_padrao'>";

echo "<select style='width:100%' id='".$agendamento_code."' onchange='executar_acao_streaming(this.id,this.value);'>
  <option value='' selected='selected'>Selecione</option>
  <option value='remover-multpoint'>Remover</option>
</select>";

echo "</td>
</tr>";

unset($lista_dias);
unset($dia_nome);
}

} else {

echo "<tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'>Nenhum Multi Point cadastrado</td>
  </tr>";

}
?>

<?php 
if($dados_stm["shoutcast"] == 'mp3' ){ ?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px;">
  <tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'></td>
  </tr>
  <tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'>Identificamos que voc� esta usando a ves�o <b>SHOUTcast V1.9.8</b>, para usar este recurso,por favor, atualize a vers�o para <b>SHOUTcast v2.4.7.256</b></td>
  </tr>
</table>

<?php } else { ?>

<?php 
//Multpoint1
if($total_pontos == '4' ) {  ?>

<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px;">
  <tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'></td>
  </tr>
  <tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'><b>Limite de Multi Point atingido, para criar um novo � preciso excluir um existente.</b></td>
  </tr>
</table>

<?php } else { ?>

<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:20px;">
<tr>
        <td width="130" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Bit-rate</td>
        <td width="520" align="left">
        <select name="bitrate" id="bitrate" style="width:250px;">
        <?php
		   foreach(array("20","24","32","36","42","48","52","56","64","68","72","78","82","86","94","96","103","116","128") as $bitrate){
		   
		   if($bitrate <= $dados_stm["bitrate"]) {
		   
		   if($bitrate == $dados_stm["bitrate"]) {
		   
		   if($bitrate == $dados_stm["bitrate_autodj"]) {
		   echo "<option value=\"".$bitrate."\" selected=\"selected\">".$bitrate." Kbps($Gerenciar_maximo_enconder)</option>\n";
		   } else {
		   echo "<option value=\"".$bitrate."\">".$bitrate." Kbps (�ltimo)</option>\n";
		   }
		   
		   } else {
		   
		   if($bitrate == $dados_stm["bitrate_autodj"]) {
		   echo "<option value=\"".$bitrate."\" selected=\"selected\">".$bitrate." Kbps</option>\n";
		   } else {
		   echo "<option value=\"".$bitrate."\">".$bitrate." Kbps</option>\n";
		   }
		   
		   }	   
		   
		   }
		    
		   }
		  ?>
        
        </select>
        
      </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Encoder</td>
        <td align="left">
        <select name="encoder" id="encoder" style="width:250px;">
          <option value="mp3" selected="selected">MP3</option>
          <option value="aacp">AccPlus +</option>
        </select>
        </td>
      </tr>
      
        <td height="40">&nbsp;</td>
        <td align="left">
          
          <input name="frequencia" type="hidden" id="cadastrar" value="1" />
          <input name="url" type="hidden" id="cadastrar" value="www" />
          <input type="submit" class="botao" value="Criar Multpoint" />
          <input type="button" class="botao" value="Voltar"onclick="window.location = '/informacoes';">
          <?php
           if($dados_stm["shoutcast"] == 'aacp') { ?>
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />         </td>
          <?php
           } else { ?>
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />         </td>
          <?php
           } ?>
      </tr>
  </form>
<?php } ?>
<?php } ?>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="../Streaming_files/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
</table>
    <table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px;">
      <tbody><tr>
        <td height="30" align="left" class="texto_padrao_destaque">
        <div id="quadro">
            	<div id="quadro-topo"> <strong><?php echo "$AutoDJ_agendament31";?></strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td height="25" class="texto_padrao_pequeno"><br>
    </b>O Multi Point s� funciona com vers�o do SHOUTcast Server v2.4.7.256<p>
    </b>Com o Multi Point voc� pode cadastrar pontos adicionais e transmitir em diferentes bitrates simult�neamente.<br>
    </span></td>
    </tr>
</tbody></table>
    </div>
      </div>
        </td>
      </tr>
    </tbody></table>
    <br>
  </form>
</div>
</html>