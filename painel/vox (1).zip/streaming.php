<?php
require_once("admin/inc/protecao-final.php");
require_once("admin/inc/conecta.php");
require_once("admin/inc/funcoes.php");
require_once("admin/inc/classe.ssh.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_stm["ultima_playlist"]."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));



if($dados_stm["aacplus"] == 'sim') {
$formato = "AAC+ sem Plugin(rtmp)";
} elseif($dados_stm["aacplus"] == 'nao' && $dados_stm["encoder"] == 'aacp') {
$formato = "AAC+ simples";
} else {
$formato = "MP3";
}

$porta_code = code_decode($dados_stm["porta"],"E");

$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
if($status_streaming == "ligado"){
// INICIO shoutcast XML //
$ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, "http://".$dados_servidor["ip"].":".$dados_stm["porta"]."/admin.cgi?sid=1&pass=dj".$dados_stm["senha"]."&mode=viewxml");
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
 curl_setopt($ch, CURLOPT_TIMEOUT, 5);
 $resultado = curl_exec($ch);
 curl_close($ch);
 $xml = @simplexml_load_string(utf8_encode($resultado));
 $musica_atual = $xml->SONGTITLE;
 $ouvinte_aovivo = $xml->CURRENTLISTENERS;
 $ouvinte_maximo = $xml->MAXLISTENERS;
 $texto = "$musica_atual";
 

  // FIM shoutcast XML //

} else {

$ouvinte_aovivo = "0";
$ouvinte_maximo = "".$dados_stm["ouvintes"]."";
}

?>


<?php
//CALCULA ESPA�O USADO NO STREAMING PELO CLIENTE
require_once("admin/inc/classe.ssh.php");
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
$espaco_usado = $ssh->executar("du -csh /home/streaming/$dados_stm[porta] | awk {'print $1'}");
if (stristr($espaco_usado,"M")) {
	$quota1 = explode("M",$espaco_usado);
	$quota = "$quota1[0]";
}
if (stristr($espaco_usado,"G")) {
	$quota1 = explode("G",$espaco_usado);
	$quota = "$quota1[0]";
	$quota = $quota * 1024;
}
?>
<?php
						
//AQUI PEGA O ESPA�O USADO DO STREAMING E DIVIDE PELO ESPA�O TOTAL E MUTIPLICA POR 100.
$espaco_total = $dados_stm[espaco];
$resultado_ftp = ($quota / $espaco_total) * 100;

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title><?php echo $dados_stm["porta"]; ?> Gerenciamento de Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon" />
<link href="inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="./index.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="./wwb10.min.js"></script>
<?php if($dados_stm["status"] == 1) { ?>
<script type="text/javascript" src="admin/inc/ajax-stm.js"></script>
<script type="text/javascript" src="admin/inc/javascript.js"></script>
<script type="text/javascript" src="admin/inc/sorttable.js"></script>
<meta http-equiv="refresh" content="180; URL=./streaming">
<?php } else { ?>
<?php } ?>
<style>
body {
	overflow: hidden;
}
</style>
<style type="text/css">
#conteudo
{
   border: 4px #C0C0C0 solid;
}
</style>
</head>

<body>
<div id="topo">
<div id="topo-logo"><img src="img/img-logo-topo.png" id="topo-logo-imagem" border="0" /></div>
<div id="topo-botao-ligar">
<img src="img/icones/img-icone-ligar-64x64.png" title="Ligar" width="64" height="64" style="cursor:pointer" onclick="ligar_streaming('<?php echo $porta_code;?>');" />
</div>
<div id="topo-botao-desligar">
<img src="img/icones/img-icone-desligar-48x48.png" title="Desligar" width="48" height="48" style="cursor:pointer" onclick="desligar_streaming('<?php echo $porta_code;?>');" />
</div>
<div id="topo-botao-reiniciar">
<img src="img/icones/img-icone-reiniciar-48x48.png" title="Reiniciar" width="48" height="48" style="cursor:pointer" onclick="reiniciar_streaming('<?php echo $porta_code;?>');" />
</div>
<div id="topo-menu" class="texto_padrao_pequeno"><strong>Executar A��o</strong><br /><br />
<form id="GoMenu1" action="">
   <select id="GoMenu1_select" name="GoMenu1" onchange="OnGoMenuFormLink(this)">
      <option class="_self" value="#" selected>Escolha uma a��o</option>
      <optgroup label="Streaming">
      <option class="conteudo" value="./informacoes">Informa��es</option>
      <option class="conteudo" value="./configurar-streaming/<?php echo $dados_stm["porta_code"]; ?>">Configura��o</option>
      </optgroup>
      <optgroup label="Auto DJ">
      <option class="conteudo" value="./gerenciar-playlists/<?php echo $dados_stm["porta_code"]; ?>">Gerenciar Playlists</option>
      <option class="conteudo" value="./gerenciar-musicas/<?php echo $dados_stm["porta_code"]; ?>">Gerenciar M�sicas</option>
      <option class="conteudo" value="./gerenciar-agendamento-playlists/<?php echo $dados_stm["porta_code"]; ?>">Gerenciar Agendamento</option>
      <option class="conteudo" value="./gerenciar-hora_certa/<?php echo $dados_stm["porta_code"]; ?>">Gerenciar Hora Certa</option>
      <option class="conteudo" value="./gerenciar-djs/<?php echo $dados_stm["porta_code"]; ?>">Gerenciar Djs</option>
      </optgroup>
      <optgroup label="Configura��es">
      <option class="conteudo" value="./player-facebook/<?php echo $dados_stm["porta_code"]; ?>">Player Facebook</option>
      <option class="conteudo" value="./configurar-shoutcast/<?php echo $dados_stm["porta_code"]; ?>">Vers�o Shoutcast</option>
      </optgroup>
</select>
</form>
</div>
<div id="topo-estatisticas">

<div id="topo-estatisticas-espectadores" class="texto_padrao_pequeno"><strong>Ouvintes Conectados</strong><br /><br />
<span id="estatistica_uso_plano_espectadores" class="texto_padrao_pequeno"><?php echo $ouvinte_aovivo; ?> de <?php echo $ouvinte_maximo; ?>


<script type="text/javascript">
	var progresso = new Number();
	var maximo = new Number();
	var progresso = <?php echo $ouvinte_aovivo; ?>00;
	var maximo = <?php echo $dados_stm["ouvintes"]; ?>00;
	function start(){
		if((progresso + 1) < maximo){
			progresso = progresso + 1;
			document.getElementById("pg").value = progresso;
			setTimeout("start();", 50);
		}
	}
</script>

<body onload="start();">
	
   &nbsp;&nbsp;&nbsp;&nbsp;<progress max="<?php echo $dados_stm["ouvintes"]; ?>00" id="pg"></progress>
   
</body>






</span>
</div>

<div id="topo-estatisticas-ftp" class="texto_padrao_pequeno"><strong>M�sica atual</strong><br /><br />
<span id="estatistica_uso_plano_espectadores" class="texto_padrao_pequeno"><iframe name="musica" id="musica" style="width:310px;height:18px;" src="../texto_musica/<?=$porta_code;?>" scrolling="no" frameborder="0"></iframe></span>

</div>
</div>

<div id="topo-botao-suporte-sair">
<img src="img/icones/img-icone-fechar.png" title="Sair" width="24" height="24" style="cursor:pointer" onclick="window.location = '/sair'" />

</div>

<div id="topo-status" class="texto_padrao">
<span style="font-size:30px;"id="<?php echo $dados_stm["porta"]; ?>" style="cursor:pointer" onclick="status_streaming('<?php echo $dados_stm["porta"]; ?>')"></span></span>
</div>

</div>
<!-- In�cio iframe conte�do -->
<iframe name="conteudo" id="conteudo" src="/informacoes" frameborder="0" width="100%" height="500"></iframe>
<!-- Fim iframe conte�do -->
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
status_streaming('<?php echo $dados_stm["porta"]; ?>');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ouvintes','sim','nao');
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','sim','nao');
</script>
</body>
</html>