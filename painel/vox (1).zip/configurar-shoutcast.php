<?php
require_once("admin/inc/protecao-final.php");
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="/admin/inc/estilo_config.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo_config.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="admin/inc/ajax-stm.js"></script>
<script type="text/javascript" src="admin/inc/javascript.js"></script>
<script type="text/javascript" src="admin/inc/sorttable.js"></script>
<link href='http://fonts.googleapis.com/css?family=Coda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald:300' rel='stylesheet' type='text/css'>

</head>

<body>
<div><br>
<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="580" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <form method="post" action="/configura-shoutcast" style="padding:0px; margin:0px">
   <div id="quadro">
<div id="quadro-topo"></div>
 <div class="texto_medio" id="quadro-conteudo">
    <table width="575" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid;">
      
      
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Server</td>
        <td align="left">
        <select name="shoutcast" class="input" id="encoder" style="width:255px;">
          <option value="mp3"<?php if($dados_stm["shoutcast"] == "mp3") { echo ' selected="selected"'; } ?>>(SHOUTcast Server Version 1.9.8)</option>
          <option value="aacp"<?php if($dados_stm["shoutcast"] == "aacp") { echo ' selected="selected"'; } ?>>(SHOUTcast Server v2.4.7.256)</option>
         </select>
        <img src="/admin/img/icones/ajuda.gif" title="Ajuda sobre este item." width="16" height="16" onclick="alert('Formato de transmiss�o do \n\nEscolha entre MP3 e AACP.\n\nRecomendamos o uso do formato MP3 que � comp�tivel com qualquer player.');" style="cursor:pointer" />
        </td>
      </tr>
      
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="submit" class="botao" value="Alterar Dados" />
          <input type="button" class="botao" value="Voltar" onclick="window.location = '/informacoes';" />
        </td>
      </tr>
    </table>
    </div></div>
  </form>
</div>
</body>
</html>
