﻿<?php
require_once("admin/inc/conecta.php");
require_once("admin/inc/funcoes.php");

$porta = code_decode($_GET["porta"],"D");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));

// Standard inclusions 
include("admin/inc/pchart/pChart/pData.class");
include("admin/inc/pchart/pChart/pChart.class");

// Dataset definition 
$DataSet = new pData;

sql_players = mysql_query("SELECT distinct(player) as player, count(player) as total FROM estatisticas_players where codigo_stm = '".$dados_stm["codigo"]."' GROUP by player ORDER by total DESC");
while ($dados_player = mysql_fetch_array($sql_players)) {

if($dados_pais_ip["total"] > 1) {

$paises[] = $dados_pais_ip["total"];
$totais[] = $dados_pais_ip["pais"]."(".$dados_pais_ip["total"].")";

}

}

$DataSet->AddPoint($paises,"País");
$DataSet->AddPoint($totais,"total");

$DataSet->AddAllSeries();
$DataSet->SetAbsciseLabelSerie("total");

// Initialise the graph
$Test = new pChart(500,300);
$Test->drawFilledRoundedRectangle(7,7,493,293,5,240,240,240);  
$Test->drawRoundedRectangle(5,5,495,295,5,230,230,230); 

// Draw the pie graph
$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",8);
$Test->drawPieGraph($DataSet->GetData(),$DataSet->GetDataDescription(),170,150,110,PIE_PERCENTAGE,TRUE,50,20,5);
$Test->drawPieLegend(340,100,$DataSet->GetData(),$DataSet->GetDataDescription(),250,250,250);

// Finish the graph
$Test->setFontProperties("admin/inc/pchart/Fonts/tahoma.ttf",10);
$Test->setColorPalette(0,0,0,0);
$Test->drawTitle(-200,30,"Países com mais acessos ao Streaming ".$dados_stm["porta"]."",50,50,50,705);
$Test->Stroke();
?>