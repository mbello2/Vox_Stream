<?php
session_start();

//require_once("admin/inc/classe.celular.php");

//mobile_device_detect(true,true,true,true,true,true,true,'http://'.$_SERVER['HTTP_HOST'].'/movel',false);

require_once("admin/inc/conecta.php");
require_once("admin/inc/funcoes.php");

// Navega��o
$pagina = query_string('0');

if($pagina == "sair") {

$pagina = "login";

unset($_SESSION["porta_logada"]);
}

if ($pagina == "") {
require("login.php");
} elseif (!file_exists($pagina.".php")) {
require("login.php");
} else {
require("".$pagina.".php");
}
?>