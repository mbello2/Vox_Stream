<?php

$_POST["porta"] = str_replace("'='","",$_POST["porta"]);
$_POST["senha"] = str_replace("'='","",$_POST["senha"]);
$_POST["login"] = str_replace("'='","",$_POST["login"]);


if($_POST["porta"] == '' || $_POST["senha"] == '') {

$_SESSION[status_login] = '<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td width="100%" height="25" bgcolor="#F2BBA5" class="texto_log_sistema_alerta" style="padding-left: 5px;" scope="col" align="left">
<img src="img/icones/atencao.png" align="absmiddle">&nbsp;<strong>Por favor informe a porta/senha de acesso</strong>
  </td>
</tr>
</table>';
unset($_SESSION["porta_logada"]);
header("Location: http://".$_SERVER['HTTP_HOST']."/login");
exit;
}

$valida_usuario = mysql_num_rows(mysql_query("SELECT * FROM streamings WHERE porta = '".$_POST["porta"]."' AND senha = '".$_POST["senha"]."'"));

if($valida_usuario == 1) {
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_POST["porta"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$porta_ftp = "21";
$porta_sftp = "22";
$porta_pasv = "1";
$lang = "pt_br";
$skin = "ocean";
$ftpDir = "";
$_SESSION["porta_logada"] = $_POST["porta"];
$_SESSION["senha"] = $dados_stm["senha"];
$_SESSION["servidor_ftp"] = $dados_servidor["nome"];
$_SESSION["user_ip"]           = "";
    
    // Sess�o destruir do hist�rico

    $_SESSION["loggedin"]          = "";
    $_SESSION["win_lin"]           = "";
    $_SESSION["login_error"]       = "";
    $_SESSION["login_fails"]       = "";
    $_SESSION["login_lockout"]     = "";
    $_SESSION["ftp_host"]          = "";
    $_SESSION["ftp_user"]          = "";
    $_SESSION["ftp_pass"]          = "";
    $_SESSION["ftp_port"]          = "";
    $_SESSION["ftp_pasv"]          = "";
    $_SESSION["interface"]         = "";
    $_SESSION["dir_current"]       = "";
    $_SESSION["dir_history"]       = "";
    $_SESSION["clipboard_chmod"]   = "";
    $_SESSION["clipboard_files"]   = "";
    $_SESSION["clipboard_folders"] = "";
    $_SESSION["clipboard_rename"]  = "";
    $_SESSION["copy"]              = "";
    $_SESSION["errors"]            = "";
    $_SESSION["upload_limit"]      = "";

    $_SESSION["server_sshd"]       = "";
    $_SESSION["codigo_servidor"]   = "";
    $_SESSION["ouvintes"]          = "";
    $_SESSION["senha"]             = "";
    $_SESSION["bitrate"]           = "";
    
    
     // Sess�o salvar no hist�rico
    $_SESSION["loggedin"]          = "1";
    $_SESSION["win_lin"]           = "lin";
    $_SESSION["login_error"]       = "";
    $_SESSION["login_fails"]       = "0";
    $_SESSION["login_lockout"]     = "";
    $_SESSION["ftp_host"]          = "".$dados_servidor["nome"]."";
    $_SESSION["ftp_user"]          = "".$dados_stm["porta"]."";
    $_SESSION["ftp_pass"]          = "".$dados_stm["senha"]."";
    $_SESSION["ftp_port"]          = "21";
    $_SESSION["ftp_pasv"]          = "1";
    $_SESSION["interface"]         = "adv";
    $_SESSION["dir_current"]       = "~";
    $_SESSION["dir_history"]       = "Array";
    $_SESSION["clipboard_chmod"]   = "";
    $_SESSION["clipboard_files"]   = "";
    $_SESSION["clipboard_folders"] = "";
    $_SESSION["clipboard_rename"]  = "";
    $_SESSION["copy"]              = "";
    $_SESSION["errors"]            = "";
    $_SESSION["upload_limit"]      = "268435456";
    $_SESSION["url"]      = "http://".$_SERVER['HTTP_HOST']."";

    // Sess�o salvar no hist�rico ajax
    
    $_SESSION["server_sshd"]          = "".$dados_servidor["porta_ssh"]."";
    $_SESSION["codigo_servidor"]      = "".$dados_stm["codigo_servidor"]."";
    $_SESSION["ouvintes"]             = "".$dados_stm["ouvintes"]."";
    $_SESSION["senha"]                = "".$dados_stm["senha"]."";
    $_SESSION["bitrate"]              = "".$dados_stm["bitrate"]."";
    
    
    mysql_query("Update streamings set url = 'streaming' where porta = '".$_POST["porta"]."'");
    mysql_query("Update streamings set ip_conexao = '".$dados_servidor["ip"]."' where porta = '".$_POST["porta"]."'");

header("Location: http://".$_SERVER['HTTP_HOST']."/streaming");
exit;

} else {

$_SESSION[status_login] = '<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td width="100%" height="25" bgcolor="#969696" class="texto_log_sistema_erro" style="padding-left: 5px;" scope="col" align="left"><img src="img/icones/atencao.png" align="absmiddle">&nbsp;<strong>Porta ou senha inv�lida,tente novamente!</strong>
  </td>
</tr>
</table>';

unset($_SESSION["porta_logada"]);
header("Location: http://".$_SERVER['HTTP_HOST']."/".$_POST["login"]."");
exit;
}
?>

teste