<?php
//Pegando URL
 $dominio = $_SERVER['HTTP_HOST'];
require_once("admin/inc/protecao-final.php");
$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_play = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'");
$cor_status = ($dados_stm["status"] == 1) ? "#FFFFFF" : "#FFB3B3";
$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playlist."'"));
$total_playlists = mysql_num_rows(mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."'"));
$porta_code = code_decode($dados_stm["porta"],"E");
$porta = code_decode(query_string('3'),"D");
$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="http://<?php echo $dominio; ?>/favicon.ico" type="image/x-icon">
<link href="http://<?php echo $dominio; ?>/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://<?php echo $dominio; ?>/admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="http://<?php echo $dominio; ?>/admin/inc/javascript.js"></script>
<script type="text/javascript" src="http://<?php echo $dominio; ?>/admin/inc/sorttable.js"></script>
<script src="http://<?php echo $dominio; ?>/elementos/js/jquery-1.8.3.min.js"></script>
<script src="http://<?php echo $dominio; ?>/elementos/js/jquery-ui-1.10.0.custom.min.js"></script>

<script type="text/javascript">
$.noConflict();
jQuery( document ).ready(function( $ ) {
   $('#frequencia').change(function () {
   var frequencia = $('#frequencia').val();
    //$("#weekday").attr("disabled",true);
	
	if(frequencia == "2") {
document.getElementById("weekday").disabled = true;
}

if(frequencia == "3") {

document.getElementById("weekday").disabled = false;

}
	
});

$('#cadastrar').click(function () {

//alert($(this).val());


  $.post("/configura-agendamento",
  {
  playlist:$("#playlist").val(),
	frequencia:$("#frequencia").val(),
	mes:$("#mes").val(),
	dia:$("#dia").val(),
  minuto:$("#minuto").val(),
  weekday:$("#weekday").val(),
  hora:$("#hora").val()

  },
  function(resu){
    if(resu == 1){
		alert("Cadastrado com sucesso!");
		 location.reload();
	}else{
		alert("Opsss! ocorreu um erro, contacte o suporte");
		//alert(resu);
		}
  });

 return false;
  
});


$('.remover').change(function () {

//alert($(this).val());
if($(this).val() == 0){
alert("Opcao Invalida, selecione outro agendamento!");
return false;
}

  $.post("/excluircron",
  {
    id:$(this).val()

  },
  function(resu){
    if(resu == 1){
		alert("Excluido com sucesso!");
		 location.reload();
	}else{
	     location.reload();
		//alert("Opsss! ocorreu um erro, contacte o suporte");
		//alert(resu);
		}
  });
 
  
});
});
  
   
   
</script>
<link type="text/css" rel="stylesheet" href="http://<?php echo $dados_config["ip_painel"]; ?>/admin/inc/style.css">
</head>

<body screen_capture_injected="true">
<div id="sub-conteudo">

  <form method="post" action="#" style="padding:0px; margin:0px" name="agendamentos">
  <table width="850" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;; border-bottom:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tbody><tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="200" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Playlist</td>
      <td width="500" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Horário Agendado</td>
      <td width="150" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;Ação</td>
    </tr>
<tr>

<?php
$agendamento = mysql_query("SELECT * FROM agendarplaylist where codigo = '".$dados_stm["codigo"]."'"); 
if(mysql_num_rows($agendamento) == 0){
?>

    <td height="23" colspan="3" align="center" class="texto_padrao">Nenhum registro encontrado para exibição.</td>
<?php 
}else{

while ($campoa = mysql_fetch_array($agendamento)){
?>	
	<tr>
<td height="25" align="left" scope="col" class="texto_padrao"><span style="margin-left:10px;">
<?php 
$playls = $campoa['playlist'];
$dados_pl = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$playls."'"));

echo $dados_pl['nome'];


 ?>
 
 </span>
</td>
<td height="25" align="left" scope="col" class="texto_padrao">
<?php 

if($campoa['tipo_agendamento'] == 1){
	echo "Executar no dia: ". $campoa['cron_agendado'];
}
if($campoa['tipo_agendamento'] == 2){
	echo "Executar diariamente ás: ". $campoa['cron_agendado'];
}
if($campoa['tipo_agendamento'] == 3){
	echo "Executar: ". $campoa['cron_agendado'];
}

?>

 
</td>
<td height="25" align="left" scope="col" class="texto_padrao"><select style="width:100%" id="remover" class="remover" name="remover">
  <option value="" selected="selected">Escolha uma ação</option>
  <option value="<?php echo $campoa['id']; ?>">Remover</option>
</select></td>
</tr>

<?php } ?>

<?php } ?>
  </tr>  </tbody></table>
    <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:20px;">
      <tbody><tr>
        <td width="130" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Playlist</td>
        <td width="520" align="left">
		
       <select name="playlist" id="playlist" style="width:300px;">
	   <optgroup label="Playlists">
	   <?php 
	   while ($campo = mysql_fetch_array($dados_play)){
	   ?>
	   <option value="<?php echo $campo['codigo']; ?>"><?php echo $campo['nome']; ?></option>
	   <?php 
	   }
	   
	   
	   ?>
	   
	   </optgroup>
	   
	   </select>
				
		  </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Frequência</td>
        <td align="left">
        <select name="frequencia" id="frequencia" style="width:250px;" onchange="valida_opcoes_frequencia(this.value);">
          <option value="1" selected="selected">Executar em uma data específica</option>
          <option value="2">Executar diariamente</option>
          <option value="3">Executar em dias da semana</option>
        </select>        </td>
      </tr>
	   <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Mes de Início</td>
        <td align="left"><select style="width: 175px" id="mes" name="mes" >
					
					<option value="*" selected="selected">Todos os meses (*)</option>
					<option value="*/2">A cada dois meses (*/2)</option>
					<option value="*/4">A cada 3 meses (*/4)</option>
					<option value="1,7">A cada 6 meses (1,7)</option>
					<option value="1">Janeiro (1)</option>
					<option value="2">Fevereiro (2)</option>
					<option value="3">Mar&Atilde;&sect;o (3)</option>
					<option value="4">Abril (4)</option>
					<option value="5">Maio (5)</option>
					<option value="6">Junho (6)</option>
					<option value="7">Julho (7)</option>
					<option value="8">Agosto (8)</option>
					<option value="9">Setembro (9)</option>
					<option value="10">Outubro (10)</option>
					<option value="11">Novembro (11)</option>
					<option value="12">Dezembro (12)</option>
				</select></td>
	   </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Dia de Início</td>
        <td align="left"><input name="dia" type="text" id="dia" value="01" maxlength="10"  style="width:25px;"></td>
      </tr>
	  
	 
	  
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Horário de Início</td>
        <td align="left" class="texto_padrao_pequeno">
        <select name="hora" id="hora" style="width:50px;">
          <option value="01">01</option>
          <option value="02">02</option>
          <option value="03">03</option>
          <option value="04">04</option>
          <option value="05">05</option>
          <option value="06">06</option>
          <option value="07">07</option>
          <option value="08">08</option>
          <option value="09">09</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
        </select>
          <span class="texto_padrao_titulo">:</span>&nbsp;
          <select name="minuto" id="minuto" style="width:50px;">
            <option value="00">00</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option><option value="32">32</option><option value="33">33</option><option value="34">34</option><option value="35">35</option><option value="36">36</option><option value="37">37</option><option value="38">38</option><option value="39">39</option><option value="40">40</option><option value="41">41</option><option value="42">42</option><option value="43">43</option><option value="44">44</option><option value="45">45</option><option value="46">46</option><option value="47">47</option><option value="48">48</option><option value="49">49</option><option value="50">50</option><option value="51">51</option><option value="52">52</option><option value="53">53</option><option value="54">54</option><option value="55">55</option><option value="56">56</option><option value="57">57</option><option value="58">58</option><option value="59">59</option>          </select></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Dias da Semana</td>
        <td align="left" valign="middle" class="texto_padrao"><select style="width: 175px" id="weekday" name="weekday" disabled="disabled">
					<option value="*">Todos os dias úteis (*)</option>
					<option value="1-5">Seg a Sex (1-5)</option>
					<option value="0,6">Sab e Dom (6,0)</option>
					<option value="1,3,5">Seg, Qua, Sex (1,3,5)</option>
					<option value="2,4">Ter, Qui (2,4)</option>
					<option value="0">Apenas no Domingo (0)</option>
					<option value="1">Apenas as Segunda-feira (1)</option>
					<option value="2">Apenas as  Terça-feira (2)</option>
					<option value="3">Apenas as Quarta-feira (3)</option>
					<option value="4">Apenas as  Quinta-feira (4)</option>
					<option value="5">Apenas as Sexta-feira (5)</option>
					<option value="6">Apenas no Sabado (6)</option>
		  </select></td>
      </tr>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="submit" class="botao" value="Cadastrar" id="cadastrar">
          <input name="porta" type="hidden" id="porta" value="<?php echo $porta_code; ?>">  </td>
      </tr>
    </tbody></table>
    <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px;">
      <tbody><tr>
        <td height="30" align="left" class="texto_padrao_destaque">
        <div id="quadro">
            	<div id="quadro-topo"> <strong>Informações Importantes</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td height="25" class="texto_padrao_pequeno">-Para iníciar os agendamentos, ligue o AutoDJ selecionando qualquer playlist e aguarde a grade programada iniciar. Você pode cadastrar os agendamentos com o AutoDJ ligado sem a necessidade de desliga-lo.<br><br>-A troca de playlists é feita somente após a música atual ser concluída, o que pode levar alguns minutos dependendo da duração da músca atual.<br><br>-A ordem das músicas será de acordo com a opção escolhida ao ligar o AutoDJ.<br><br>-A playlist se repetirá até que uma outra playlist agendada seja iniciada. Por exemplo se você definir uma playlist para iniciar as 12:00 ela será executada das 12:00 até a hora que outra playlist for iniciada, se não houver outra playlist ela será executada repetidamente.<br><br>-Agendamentos com a frequencia Executar em uma data específica serão removidos do painel após serem executados.<br><br>-O novo gerenciador de agendamentos esta em fase de testes e imprevistos podem ocorrer, caso note algum comportamento extrato, aviso nosso suporte para que possamos analizar. Futuramente novas opções e configurações serão adicionadas.</td>
    </tr>
</tbody></table>
    </div>
      </div>
        </td>
      </tr>
    </tbody></table>
    <br>
  </form>
</div>
<!-- Início div log do sistema -->
<div id="log-sistema-fundo" style="display: none;"></div>
<div id="log-sistema" style="display: none;">
<div id="log-sistema-botao"><img src="./gerenciar-agendamentos_files/img-icone-fechar.png" onclick="document.getElementById(&#39;log-sistema-fundo&#39;).style.display = &#39;none&#39;;document.getElementById(&#39;log-sistema&#39;).style.display = &#39;none&#39;;" style="cursor:pointer" title="Fechar"></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->


</body></html>