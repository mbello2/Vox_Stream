<?php
require_once("admin/inc/protecao-final.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];

if($_POST["cadastrar"]) {

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));

list($dia,$mes,$ano) = explode("/",$_POST["data"]);
$data = $ano."-".$mes."-".$dia;

if(count($_POST["dias"]) > 0){
	$dias = implode(",",$_POST["dias"]);
}

mysql_query("INSERT INTO playlists_agendamentos (codigo_stm,codigo_playlist,frequencia,data,hora,minuto,duracao_hora,duracao_minuto,dias,repetir,shuffle) VALUES ('".$dados_stm["codigo"]."','".$_POST["codigo_playlist"]."','".$_POST["frequencia"]."','".$data."','".$_POST["hora"]."','".$_POST["minuto"]."','".$_POST["duracao_hora"]."','".$_POST["duracao_minuto"]."','".$dias."','".$_POST["repetir"]."','".$_POST["shuffle"]."')");

// Cria o sess�o do status das a��es executadas e redireciona.
$_SESSION["status_acao"] .= status_acao("Agendamento adicionado com sucesso.","ok");
$_SESSION["status_acao"] .= status_acao("Para in&iacute;ciar os agendamentos, ligue o AutoDJ selecionando qualquer playlist e aguarde a grade programada iniciar.","alerta");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ag/ajax-streaming.js"></script>
<script type="text/javascript" src="/admin/inc/ag/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/ag/sorttable.js"></script>
</head>

<body>

<div id="conteudo">
<?php
if($_SESSION['status_acao']) {

$status_acao = stripslashes($_SESSION['status_acao']);

echo '<table width="890" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:5px">'.$status_acao.'</table>';

unset($_SESSION['status_acao']);
}
?>
  <form method="post" action="/gerenciar-agendamento-playlists" style="padding:0px; margin:0px" name="agendamentos">
  <table width="890" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;; border-bottom:#D5D5D5 1px solid;" id="tab" class="sortable">
    <tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
      <td width="180" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Playlist</td>
      <td width="420" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Hor&aacute;rio Agendado</td>
      <td width="50" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Repetir</td>
      <td width="100" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Ordem Musical</td>
      <td width="100" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid;">&nbsp;A�&atilde;o</td>
    </tr>
<?php
$total_agendamentos = mysql_num_rows(mysql_query("SELECT * FROM playlists_agendamentos where codigo_stm = '".$dados_stm["codigo"]."' ORDER by data"));

if($total_agendamentos > 0) {

$sql = mysql_query("SELECT * FROM playlists_agendamentos where codigo_stm = '".$dados_stm["codigo"]."' ORDER by data");
while ($dados_agendamento = mysql_fetch_array($sql)) {

$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$dados_agendamento["codigo_playlist"]."'"));

list($ano,$mes,$dia) = explode("-",$dados_agendamento["data"]);
$data = $dia."/".$mes."/".$ano;

if($dados_agendamento["frequencia"] == "1") {
$descricao = "Executar uma vez em ".$data." as ".$dados_agendamento["hora"].":".$dados_agendamento["minuto"]."";
} elseif($dados_agendamento["frequencia"] == "2") {
$descricao = "Executar diariamente as ".$dados_agendamento["hora"].":".$dados_agendamento["minuto"]."";
} else {

$array_dias = explode(",",$dados_agendamento["dias"]);

foreach($array_dias as $dia) {

if($dia == "1") {
$dia_nome = "Dom";
} elseif($dia == "2") {
$dia_nome = "Seg";
} elseif($dia == "4") {
$dia_nome = "Ter";
} elseif($dia == "8") {
$dia_nome = "Qua";
} elseif($dia == "16") {
$dia_nome = "Qui";
} elseif($dia == "32") {
$dia_nome = "Sex";
} elseif($dia == "64") {
$dia_nome = "S�b";
}

$lista_dias .= "".$dia_nome.", ";

}

$descricao = "Executar no(s) dia(s) ".substr($lista_dias, 0, -2)." as ".$dados_agendamento["hora"].":".$dados_agendamento["minuto"]."";
}

$repetir = ($dados_agendamento["repetir"] == 1) ? "Sim" : "N�o";

$ordem_musical = ($dados_agendamento["shuffle"] == 1) ? "Misturar" : "Seguir playlist";

$agendamento_code = code_decode($dados_agendamento["codigo"],"E");

echo "<tr>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$dados_playlist["nome"]."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$descricao."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$repetir."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>&nbsp;".$ordem_musical."</td>
<td height='25' align='left' scope='col' class='texto_padrao'>";

echo "<select style='width:100%' id='".$agendamento_code."' onchange='executar_acao_streaming(this.id,this.value);'>
  <option value='' selected='selected'>Escolha uma a��o</option>
  <option value='remover-agendamento'>Remover</option>
</select>";

echo "</td>
</tr>";

unset($lista_dias);
unset($dia_nome);
}

} else {

echo "<tr>
    <td height='23' colspan='3' align='center' class='texto_padrao'>Nenhum agendamento cadastrado.</td>
  </tr>";

}
?>
  </table>
    <table width="890" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px; background-color:#FFFF66; border:#DFDF00 1px solid">
      <tr>
        <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="820" align="left" class="texto_padrao_pequeno" scope="col">Para in&iacute;ciar os agendamentos, ap&oacute;s configura-los, ligue o AutoDJ selecionando qualquer playlist e aguarde a grade programada iniciar.</td>
      </tr>
    </table>
    <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#F4F4F7; border:#CCCCCC 1px solid; margin-top:20px;">
      <tr>
        <td width="130" height="30" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Playlist</td>
        <td width="520" align="left">
        <select name="codigo_playlist" id="codigo_playlist" style="width:250px;">
        <?php
		$query_playlists = mysql_query("SELECT * FROM playlists where codigo_stm = '".$dados_stm["codigo"]."' ORDER by codigo ASC");
		while ($dados_playlist = mysql_fetch_array($query_playlists)) {
	
		$total_musicas = mysql_num_rows(mysql_query("SELECT * FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'"));
		if($total_musicas > 0) {
		echo '<option value="'.$dados_playlist["codigo"].'">'.$dados_playlist["nome"].' ('.$total_musicas.' m�sicas)</option>';
		} else {
		echo '<option value="'.$dados_playlist["codigo"].'" disabled="disabled">'.$dados_playlist["nome"].' (sem m�sicas)</option>';
		}
		}
        ?>
        </select>        </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Frequ&ecirc;ncia</td>
        <td align="left">
        <select name="frequencia" id="frequencia" style="width:250px;" onchange="valida_opcoes_frequencia(this.value);">
          <option value="1" selected="selected">Executar uma vez(dia espec�fico)</option>
          <option value="2">Executar diariamente</option>
          <option value="3">Executar em dias espec�ficos</option>
        </select>
        </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Data de In&iacute;cio</td>
        <td align="left"><input name="data" type="text" id="data" onkeypress="return txtBoxFormat(this, '99/99/9999', event);" value="__/__/____" maxlength="10" onclick="this.value=''" style="width:75px;" /></td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Hor&aacute;rio de In&iacute;cio</td>
        <td align="left" class="texto_padrao_pequeno">
        <select name="hora" id="hora" style="width:50px;">
          <option value="01">01</option>
          <option value="02">02</option>
          <option value="03">03</option>
          <option value="04">04</option>
          <option value="05">05</option>
          <option value="06">06</option>
          <option value="07">07</option>
          <option value="08">08</option>
          <option value="09">09</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
        </select>
          <span class="texto_padrao_titulo">:</span>&nbsp;
          <select name="minuto" id="minuto" style="width:50px;">
            <?php 
			for ($minuto=0;$minuto<=59;$minuto++){

			echo '<option value="'.sprintf("%02d",$minuto).'">'.sprintf("%02d",$minuto).'</option>';
			
			}
			?>
          </select></td>
      </tr>
      <tr>
        <td height="45" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Tempo de Dura&ccedil;&atilde;o</td>
        <td align="left" class="texto_padrao_pequeno">
        <select name="duracao_hora" id="duracao_hora" style="width:50px;">
          <option value="00" selected="selected">00</option>
          <option value="01">01</option>
          <option value="02">02</option>
          <option value="03">03</option>
          <option value="04">04</option>
          <option value="05">05</option>
          <option value="06">06</option>
          <option value="07">07</option>
          <option value="08">08</option>
          <option value="09">09</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
        </select>
          <span class="texto_padrao_titulo">:</span>&nbsp;
          <select name="duracao_minuto" id="duracao_minuto" style="width:50px;">
            <?php 
			for ($minuto=0;$minuto<=59;$minuto++){

			echo '<option value="'.sprintf("%02d",$minuto).'">'.sprintf("%02d",$minuto).'</option>';
			
			}
			?>
          </select>
          <br />
          (Ex. para executar durante 5 hs escolha 05:00 ou  00:00  para executar at&eacute; o pr&oacute;ximo agendamento) </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Dias Espec�ficos</td>
        <td align="left" valign="middle" class="texto_padrao">
        <input name="dias[]" type="checkbox" value="1" id="dias" disabled="disabled" />Domingo&nbsp;
        <input name="dias[]" type="checkbox" value="2" id="dias" disabled="disabled" />Segunda&nbsp;
        <input name="dias[]" type="checkbox" value="4" id="dias" disabled="disabled" />Ter�a&nbsp;
        <input name="dias[]" type="checkbox" value="8" id="dias" disabled="disabled" />
        Quarta&nbsp;
        <input name="dias[]" type="checkbox" value="16" id="dias" disabled="disabled" />Quinta&nbsp;
        <input name="dias[]" type="checkbox" value="32" id="dias" disabled="disabled" />Sexta&nbsp;
        <input name="dias[]" type="checkbox" value="64" id="dias" disabled="disabled" />S�bado
        </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Repetir</td>
        <td align="left" valign="middle" class="texto_padrao_pequeno"><input name="repetir" type="checkbox" value="1" />
&nbsp;Repetir playlist caso execute todas as m&uacute;sicas antes de terminar o hor&aacute;rio agendado.</td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;" class="texto_padrao_destaque">Ordem Musical</td>
        <td align="left" valign="middle" class="texto_padrao_pequeno"><input name="shuffle" type="radio" value="1" />&nbsp;Misturar sequ�ncia da playlist&nbsp;
<input name="shuffle" type="radio" value="0" checked />&nbsp;Seguir sequ�ncia da playlist</td>
      </tr>
      <tr>
        <td height="40">&nbsp;</td>
        <td align="left">
          <input type="submit" class="botao" value="Adicionar Agendamento" />
          <input type="button" class="botao" value="Voltar" onclick="window.location = '/informacoes';" />
          <input name="cadastrar" type="hidden" id="cadastrar" value="sim" />          </td>
      </tr>
    </table>
    <br />
    <table width="850" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px; background-color:#FFFF66; border:#DFDF00 1px solid">
      <tr>
        <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
        <td width="890" align="left" class="texto_padrao_pequeno" scope="col">Devido h&aacute; um bug no AutoDJ(ShoutCast Transcoder 2.0) n&atilde;o &eacute; poss&iacute;vel agendar  entre 00:00 e 00:59 pois ocorre um comportamento inexperado.</td>
      </tr>
    </table>
  </form>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
</body>
</html>