<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 60000);

require_once("admin/inc/protecao-final.php");
require_once("admin/inc/classe.ftp.php");
require_once("admin/inc/classe.ssh.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');
$porta_code = code_decode($_SESSION["porta_logada"],"E");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

// Salva a Playlist
if($_POST["enviar"] == "ok") {

$musica = isset($_FILES["novas_musicas"]) ? $_FILES["novas_musicas"] : FALSE;

if(count($musica["name"]) > 0) {



// Conex�o FTP
$ftp = new FTP();
$ftp->conectar($dados_servidor["ip"]);
$ftp->autenticar($dados_stm["porta"],$dados_stm["senha"]);

for ($i = 0; $i < count($musica["name"]); $i++) {

if($musica["name"][$i]) {

if($ftp->enviar_arquivo($musica["tmp_name"][$i],$_POST["pasta_selecionada"]."/".$musica["name"][$i])) {

$resuldado_final .= "<span class='texto_status_sucesso_pequeno'>M�sica ".$musica["name"][$i]."  enviada com sucesso.</span><br>";

} else {

$resuldado_final .= "<span class='texto_status_erro_pequeno'>N�o foi poss�vel enviar a m�sica ".$musica["name"][$i]." (".round($musica["size"][$i] / 1024000, 2)." Mb).</span><br>";

}

}

}



}

}

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax-streaming-musicas.js"></script>
<script type="text/javascript">
   window.onload = function() {
    carregar_pastas('<?php echo $porta_code; ?>');
	<?php if($resuldado_final) { ?>
    document.getElementById('log-sistema-conteudo').innerHTML = "<?php echo $resuldado_final; ?>";
    document.getElementById('log-sistema-fundo').style.display = "block";
    document.getElementById('log-sistema').style.display = "block";
	<?php } ?>
   };
</script>
</head>

<body>

<div id="conteudo">
  <form method="post" action="/gerenciar-musicas" style="padding:0px; margin:0px" name="gerenciador" enctype="multipart/form-data">
    <table width="890" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="310" height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Pastas</td>
        <td width="580" height="25" align="left" class="texto_padrao_destaque" style="padding-left:9px;">M�sicas da Pasta</td>
      </tr>
      <tr>
        <td align="left" style="padding-left:5px;">
        <div style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:285px; height:250px; text-align:left; float:left; padding:5px; overflow: auto;">
        <span id="status_lista_pastas" class="texto_padrao_pequeno"></span>
		<ul id="lista-pastas">
		</ul>
		</div>
		</td>
        <td align="left">
        <div id="musicas" style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:560px; height:250px; text-align:left; float:right; padding:5px; overflow: auto;">
        <span id="msg_pasta" class="texto_padrao_pequeno">Clique na pasta ao lado para carregar as m�sicas.</span>
        <ul id="lista-musicas-pasta">
        </ul>
        </div>
        </td>
      </tr>
      <tr>
        <td height="30" align="left" style="padding-left:5px;"><img src="/admin/img/icones/img-icone-cadastrar.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:criar_pasta('<?php echo $porta_code; ?>');" class="texto_padrao">Criar Pasta</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-atualizar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="javascript:carregar_pastas('<?php echo $porta_code; ?>');" class="texto_padrao">Recarregar Pastas</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-voltar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="/informacoes" class="texto_padrao">Voltar</a></td>
        <td width="580" align="left" class="texto_padrao_destaque" style="padding-left:9px;">Enviar M�sicas(*.mp3)</td>
      </tr>
      <tr>
        <td align="center" valign="top">
        <div style="padding-top:20px;padding-left:80px;">
        </td>
        <td align="left" style="padding-left:9px;">
        <div id="uploads">
        <input name="novas_musicas[]" type="file" class="botao_padrao" id="novas_musicas[]" size="60" /><br />
        </div>
		<br />
        <span id="msg_pasta_selecionada" class="texto_padrao_pequeno">Pasta Selecionada: Nenhuma</span>
        <br />
        <img src="/admin/img/icones/img-icone-enviar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="javascript:enviar_musicas(document.getElementById('pasta_selecionada').value);" class="texto_padrao">Enviar M�sicas</a>&nbsp;
        <img src="/admin/img/icones/img-icone-cadastrar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="javascript:adicionar_campo_upload('uploads');" class="texto_padrao">Adicionar Campos</a>
        <input name="enviar" type="hidden" id="enviar" value="ok" />
        <input name="pasta_selecionada" type="hidden" id="pasta_selecionada" value="" />
        </td>
      </tr>
    </table>
  </form>
  <table width="690" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; margin-bottom:10px; background-color:#FFFF66; border:#DFDF00 1px solid">
    <tr>
      <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
      <td width="660" align="left" class="texto_pequeno_erro" scope="col">Para um melhor desempenho, recomendamos o uso de um programa de FTP em seu computador.</td>
    </tr>
  </table>
  <table width="690" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:20px; background-color:#FFFF66; border:#DFDF00 1px solid">
    <tr>
      <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
      <td width="660" align="left" class="texto_pequeno_erro" scope="col">N&atilde;o use acentos em nomes de m&uacute;sicas, pastas  para que n&atilde;o ocorra erros inexperados.</td>
    </tr>
  </table>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
<script type="text/javascript">
// Checar o status dos streamings
estatistica_uso_plano( <?php echo $dados_stm["porta"]; ?>,'ftp','nao');
</script>
</body>
</html>