<?php
require_once("admin/inc/protecao-final.php");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas WHERE codigo = '".$dados_stm["codigo_cliente"]."'"));

$porta_code = code_decode($dados_stm["porta"],"E");

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax-streaming.js"></script>
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script type="text/javascript" src="/admin/inc/sorttable.js"></script>
</head>

<body>

<div id="conteudo">
<div id="quadro">
            	<div id="quadro-topo"> <strong>API de Informa&ccedil;&otilde;es do Streaming</strong></div>
            		<div class="texto_medio" id="quadro-conteudo">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td height="25" class="texto_padrao"><p>Para facilitar o uso das informa&ccedil;&otilde;es de seu streaming, desenvolvemos esta API que exibe informa&ccedil;&otilde;es como status, quantidade de ouvintes online, limites do plano dentre outros. Desta forma voc&ecirc; pode exibir estas informa&ccedil;&otilde;es em seu site al&eacute;m de outras possibilidades.</p>
      <p>Para usar a API basta chama-la usando sua linguagem de programa&ccedil;&atilde;o preferida como PHP. Confira abaixo a URL de sua API e um exemplo em PHP de como utiliza-la:</p>
      <p><center><input type="text" value="<?php echo "http://".$_SERVER['HTTP_HOST']."/api/".$porta_code.""; ?>" style="width:90%; height:30px"  onclick="this.select()" readonly="readonly" /><br />
<br />
<br />
<textarea readonly="readonly" style="width:90%; height:470px"  onclick="this.select()">
$xml = simplexml_load_file("<?php echo "http://".$_SERVER['HTTP_HOST']."/api/".$porta_code.""; ?>");

echo $xml->status;
echo "<br>";
echo $xml->porta;
echo "<br>";
echo $xml->porta_dj;
echo "<br>";
echo $xml->ip;
echo "<br>";
echo $xml->ouvintes_conectados;
echo "<br>";
echo $xml->titulo;
echo "<br>";
echo $xml->plano_ouvintes;
echo "<br>";
echo $xml->plano_ftp;
echo "<br>";
echo $xml->plano_bitrate;
echo "<br>";
echo $xml->musica_atual;
echo "<br>";
echo $xml->shoutcast;
echo "<br>";
echo $xml->rtmp; // se tiver RTMP
echo "<br>";
echo $xml->rtsp; // se tiver RTMP
</textarea>
<br />
<br />
<br />
<input type="button" class="botao" value="Voltar" onclick="window.location = '/informacoes';" />
</center>
</p></td>
    </tr>
</table>
    </div>
      </div>
<br />
<br />
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
</body>
</html>
