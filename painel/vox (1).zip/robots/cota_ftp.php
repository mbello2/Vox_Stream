    <?php

     require_once("../admin/inc/conecta.php");
     require_once("../admin/inc/funcoes.php");
     require_once("../admin/inc/classe.ssh.php");


    // Informa��es do Stremaing
	$query_stms = mysql_query("SELECT * FROM streamings where status = '1'");
	while ($dados_stm = mysql_fetch_array($query_stms)) {
	
	$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where codigo = '".$dados_stm["codigo"]."'"));
	$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

        // Conex�o SSH
	$ssh = new SSH();
	$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
	$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
	
	// Pegar informa��o do espa�o
	$espaco_usado = $ssh->executar("du -csh /home/streaming/$dados_stm[porta] | awk {'print $1'}");
      
                $total = substr("$espaco_usado", 0, 5);
        mysql_query("Update streamings set quota = '".$total."' where codigo = '".$dados_stm["codigo"]."'");
        mysql_query("Update streamings set quota_total = '".$dados_stm["espaco"]."' where codigo = '".$dados_stm["codigo"]."'");
        mysql_query("Update streamings set espaco_usado = '".$total."' where codigo = '".$dados_stm["codigo"]."'");
        
		
        }
        $finalizacao = "Cadastrado com sucesso";
        ?>
     
	 <?php echo "$finalizacao";?> 
	 <?=$dados_stm["porta"];?>