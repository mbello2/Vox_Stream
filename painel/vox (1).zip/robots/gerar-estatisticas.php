<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 1800);

require_once("../admin/inc/conecta.php");
require_once("../admin/inc/funcoes.php");

$inicio_execucao = tempo_execucao();

list($inicial,$final) = explode("-",$_GET["registros"]);

$sql = mysql_query("SELECT * FROM streamings where status = '1' ORDER by porta ASC LIMIT ".$inicial.", ".$final."");
while ($dados_stm = mysql_fetch_array($sql)) {

$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

if($dados_servidor["status"] == "on") {

$xml_stats = simplexml_load_string(utf8_encode(estatistica_streaming($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"])));

$total_registros = count($xml_stats->LISTENERS->LISTENER);

for($i=0;$i<=$total_registros;$i++){

$ip = $xml_stats->LISTENERS->LISTENER[$i]->HOSTNAME;
$tempo_conectado = $xml_stats->LISTENERS->LISTENER[$i]->CONNECTTIME;
$pais = pais_ip($ip,"nome");

if($ip && $tempo_conectado) {

$verifica_ouvinte = mysql_num_rows(mysql_query("SELECT * FROM estatisticas where codigo_stm = '".$dados_stm["codigo"]."' AND ip = '".$ip."' AND data = '".date("Y-m-d")."'"));

if($verifica_ouvinte == 0) {

mysql_query("INSERT INTO estatisticas (codigo_stm,data,ip,pais,tempo_conectado) VALUES ('".$dados_stm["codigo"]."',NOW(),'".$ip."','".$pais."','".$tempo_conectado."')");

echo "Ouvinte: ".$ip." adicionado.<br>";

} else {

mysql_query("Update estatisticas set tempo_conectado = '".$tempo_conectado."' where codigo_stm = '".$dados_stm["codigo"]."' AND ip = '".$ip."' AND data = '".date("Y-m-d")."'");

echo "Ouvinte: ".$ip." atualizado.<br>";

}

}

}

}

}
$fim_execucao = tempo_execucao();

$tempo_execucao = number_format(($fim_execucao-$inicio_execucao),2);

echo "<br>--------------------------------------------------------------------<br>";
echo "Tempo: ".$tempo_execucao." segundo(s);";
?>