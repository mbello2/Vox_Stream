<?php
require_once("../admin/inc/conecta.php");
     require_once("../admin/inc/funcoes.php");
     require_once("../admin/inc/classe.ssh.php");
     include_once "../admin/funcoes-hora.php";
$sql = mysql_query("SELECT * FROM servidores");
$lpp = 100; // total de registros por p&aacute;gina
$total = mysql_num_rows($sql);
$paginas = ceil($total / $lpp); 
if(!isset($pagina_atual)) { $pagina_atual = 0; }
$inicio = $pagina_atual * $lpp;
$sql = mysql_query("SELECT * FROM servidores ORDER by codigo ASC LIMIT $inicio, $lpp");

while ($dados_servidor = mysql_fetch_array($sql)) {

$total_stm = mysql_num_rows(mysql_query("SELECT * FROM streamings where codigo_servidor = '".$dados_servidor["codigo"]."'"));

if($dados_servidor["status"] == "on") {
date_default_timezone_set('America/Bahia');
$hora=date('H');

// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));
//$horah = $ssh->executar("cd /home/streaming/;rm horah;wget http://184.95.53.54/robots/horah;date");
//$sinalhora = $ssh->executar("cd /home/streaming/Hora-certa/;rm sinalhora.mp3;wget http://184.95.53.54/robots/sinalhora.mp3;date");
$data = $ssh->executar("date;chmod +x /home/streaming/cron");
$data = $ssh->executar("date;/home/streaming/cron");
//$load = $ssh->executar("cd /home/streaming/hora;wget http://198.15.86.162/~painelf/atualizarhora.zip;unzip atualizarhora.zip;rm atualizarhora.zip");


}




echo "<tr style='background-color:".$cor_status_load.";'>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$dados_servidor["nome"]."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$dados_servidor["ip"]."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$dados_servidor["porta_ssh"]."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$total_stm."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$load."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$data."</td>
<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>&nbsp;".$dados_servidor["Processador"]."</td>

<td height='25' align='left' scope='col'style='border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;' class='texto_padrao'>


</td>
</tr>";

}
?>
		
   