<?php
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".query_string('1')."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));

list($player, $extensao) = explode(".",query_string('2'));

if($player == "mediaplayer") {

// Extens�o: .asx

$conteudo = '<asx version = "3.0"> 
  <Repeat Count="5">
  <Entry> 
  <ref href="http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'" />
  </Entry>
  </Repeat>
</asx>';

} elseif($player == "winamp") {

// Extens�o: .pls

$conteudo = '[playlist]
NumberOfEntries=1
File1=http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'';

} elseif($player == "realplayer") {

// Extens�o: .rm

$conteudo = 'http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'';

} elseif($player == "iphone") {

$conteudo = 'http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'';

} elseif($player == "android") {

header("Location: rtsp://".$dados_servidor_aacplus["ip"]."/".$dados_stm["porta"]."/".$dados_stm["porta"].".stream");
exit();

} else {

// Extens�o: .pls

$conteudo = '[playlist]
NumberOfEntries=1
File1=http://'.$dados_servidor["ip"].':'.$dados_stm["porta"].'';

}

header("Content-type: application/octet-stream");

echo $conteudo;

exit();
?> 