<?php
$porta = code_decode(query_string('1'),"D");
$porta_code = query_string('1');

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$porta."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Ouvintes Conectados</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/javascript.js"></script>
<script src="http://maps.googleapis.com/maps/api/js?sensor=false" type="text/javascript"></script>
<script type="text/javascript">
   window.onload = function() {
    setTimeout("window.location.reload(true);",30000);
	initialize();
   };
</script>
<style type="text/css">
<!--
body {
	overflow-x: hidden;
}
-->
</style>
</head>

<body>
<table width="820" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:5px; margin-bottom:5px; background-color:#FFFF66; border:#DFDF00 1px solid">
  <tr>
    <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
    <td width="790" align="left" class="texto_log_sistema_alerta" scope="col">Esta p&aacute;gina mostra os ouvintes conectados em tempo real.</td>
  </tr>
</table>
<table width="820" border="0" align="center" cellpadding="0" cellspacing="0" style="border-top:#D5D5D5 1px solid; border-left:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid; border-bottom:#D5D5D5 1px solid;" id="tab" class="sortable">
  <tr style="background:url(/admin/img/img-fundo-titulo-tabela.png) repeat-x; cursor:pointer">
    <td width="348" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;IP</td>
    <td width="268" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Pa&iacute;s</td>
    <td width="202" height="23" align="left" class="texto_padrao_destaque" style="border-bottom:#D5D5D5 1px solid; border-right:#D5D5D5 1px solid;">&nbsp;Tempo Conectado</td>
  </tr>
<?php
$i = 1;

if($dados_stm["aacplus"] == 'sim') {

$stats_shoutcast = estatistica_streaming_shoutcast($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);
$stats_aacplus = estatistica_streaming_aacplus($dados_servidor_aacplus["ip"],$dados_stm["porta"],$dados_servidor_aacplus["senha"]);
$estatisticas = $stats_shoutcast.$stats_aacplus;

} else {

$stats_shoutcast = estatistica_streaming_shoutcast($dados_servidor["ip"],$dados_stm["porta"],$dados_stm["senha"]);
$estatisticas = $stats_shoutcast;

}

if($stats_shoutcast) {

$estatisticas = explode("-",substr($estatisticas, 0, -1));

foreach($estatisticas as $estatistica) {

list($ip, $tempo_conectado, $pais_sigla, $pais_nome) = explode("|",$estatistica);

if($ip != $dados_servidor_aacplus["ip"]) {

echo "
  <tr>
    <td height='23' class='texto_padrao'>&nbsp;".$ip."</td>
    <td height='23' class='texto_padrao'>&nbsp;<img src='/admin/img/icones/paises/".strtolower($pais_sigla).".png' border='0' align='absmiddle' />&nbsp;".$pais_nome."</td>
    <td height='23' class='texto_padrao'>&nbsp;".$tempo_conectado."</td>
  </tr>
";

// Dados para o mapa
$dados_ip = geoip_record_by_name($ip);

if($dados_ip["latitude"] && $dados_ip["longitude"]) {

$dados_LatLng_array .= "myLatlng".$i.",";
$dados_LatLng_array_nome .= "\"Ouvinte: ".$ip."\",";
$dados_LatLng_array_info .= "\"<div class='texto_padrao' style='text-align:left'><strong>IP:</strong> ".$ip."<br><strong>Pa�s:</strong> ".$pais_nome."&nbsp;<img src='/admin/img/icones/paises/".strtolower($pais_sigla).".png' border='0' align='absmiddle' /><br><strong>Tempo Conectado:</strong> ".$tempo_conectado."</div>\",";
$dados_LatLng .= "var myLatlng".$i." = new google.maps.LatLng( ".$dados_ip["latitude"].", ".$dados_ip["longitude"].");\n";
$i++;
}

}

}

} else {

echo "
  <tr>
    <td height='30' colspan='4' align='center' class='texto_status_erro'>N�o h� ouvintes conectados neste momento.</td>
  </tr>
";

}
?>
</table>
<br />
<script type="text/javascript">
function initialize() {

<?php
		
  echo substr($dados_LatLng, 0, -1);
		
?>
  
  var locationArray = [<?php echo substr($dados_LatLng_array, 0, -1); ?>];
  var locationArrayName = [<?php echo substr($dados_LatLng_array_nome, 0, -1); ?>];
  var locationArrayInfo = [<?php echo substr($dados_LatLng_array_info, 0, -1); ?>];
  
  var myOptions = {
  zoom: 2,
  center: new google.maps.LatLng(5,-20),
  mapTypeId: google.maps.MapTypeId.ROADMAP,
  }
  
  var map = new google.maps.Map(document.getElementById("mapa_ips"), myOptions);
  
  for(var cont = 0; cont < locationArray.length; cont++) {
  
  var contentString = locationArrayInfo[cont];
  
  var infowindow = new google.maps.InfoWindow({
      content: contentString
  });
  
  var marker = new google.maps.Marker({
    position: locationArray[cont],
    title: locationArrayName[cont]
  });
  
  google.maps.event.addListener(marker, 'click', function() {
    infowindow.open(map,marker);
  });

  marker.setMap(map);
  }
}
</script>
<div id="mapa_ips" style="width: 820px; height: 400px; margin:0px auto" align="center"></div>
<table width="820" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:5px; margin-bottom:5px; background-color:#FFFF66; border:#DFDF00 1px solid">
  <tr>
    <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
    <td width="790" align="left" class="texto_log_sistema_alerta" scope="col">Se houver mais de um IP na mesma cidade, somente um deles ser&aacute; exibido no mapa.</td>
  </tr>
</table>
</body>
</html>
