<?php
ini_set("memory_limit", "128M");
ini_set("max_execution_time", 300);

require_once("admin/inc/protecao-final.php");
require_once("admin/inc/classe.ftp.php");
require_once("admin/inc/classe.ssh.php");

//$porta = code_decode(query_string('1'),"D");
//$porta_code = query_string('1');

$porta_code = code_decode($_SESSION["porta_logada"],"E");

$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".$_SESSION["porta_logada"]."'"));
$dados_revenda = mysql_fetch_array(mysql_query("SELECT * FROM revendas where codigo = '".$dados_stm["codigo_cliente"]."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));

// Salva a Playlist
if($_POST["playlist"]) {

$dados_playlist = mysql_fetch_array(mysql_query("SELECT * FROM playlists where codigo = '".$_POST["playlist"]."'"));

// Remove as m�sicas atuais da playlist para gravar as novas m�sica
mysql_query("DELETE FROM playlists_musicas where codigo_playlist = '".$dados_playlist["codigo"]."'");

// Adiciona as musicas da playlist ao banco de dados
foreach($_POST["musicas_adicionadas"] as $ordem => $musica) {

$musica_path = $musica;
$musica_nome = str_replace("/","",strstr($musica,"/"));

// Adiciona m�sica na playlist
mysql_query("INSERT INTO playlists_musicas (codigo_playlist,path_musica,musica,ordem) VALUES ('".$dados_playlist["codigo"]."','".addslashes($musica_path)."','".addslashes($musica_nome)."','".$ordem."')") or die(mysql_error());

// Adiciona a m�sica na lista para adicionar ao arquivo da playlist
$lista_musicas .= "/home/streaming/".$dados_stm["porta"]."/".$musica_path."\n";

}

// Cria o arquivo da playlist para enviar ao servidor do streaming
$handle_playlist = fopen("/home/stmradio/public_html/temp/".$dados_playlist["arquivo"]."" ,"a");
fwrite($handle_playlist, $lista_musicas);
fclose($handle_playlist);

// Envia o arquivo da playlist para o servidor do streaming
// Conex�o SSH
$ssh = new SSH();
$ssh->conectar($dados_servidor["ip"],$dados_servidor["porta_ssh"]);
$ssh->autenticar("root",code_decode($dados_servidor["senha"],"D"));

$resultado_envio = $ssh->enviar_arquivo("/home/stmradio/public_html/temp/".$dados_playlist["arquivo"]."","/home/streaming/playlists/".$dados_playlist["arquivo"]."",0777);

// Remove o arquivo tempor�rio usado para criar a playlist
unlink("temp/".$dados_playlist["arquivo"]."");

$resuldado_final = "<span class='texto_status_sucesso'>Playlist <strong>".$dados_playlist["nome"]."</strong> salva com sucesso.</span>";

}

$url_logo = ($dados_revenda["url_logo"] == "") ? "http://".$_SERVER['HTTP_HOST']."/admin/img/img-logo-painel.gif" : $dados_revenda["url_logo"];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Streaming</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<link href="admin/inc/estilo-streaming.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/admin/inc/ajax-streaming-playlists.js"></script>
<script type="text/javascript">
   window.onload = function() {
    carregar_pastas('<?php echo $porta_code; ?>');
	carregar_playlists('<?php echo $porta_code; ?>');
	<?php if($resuldado_final) { ?>
    document.getElementById('log-sistema-conteudo').innerHTML = "<?php echo $resuldado_final; ?>";
    document.getElementById('log-sistema-fundo').style.display = "block";
    document.getElementById('log-sistema').style.display = "block";
	<?php } ?>
   };
</script>
</head>

<body>

<div id="conteudo">
  <form method="post" action="/gerenciar-playlists/<?php echo query_string('1'); ?>" style="padding:0px; margin:0px" name="gerenciador" enctype="multipart/form-data">
    <table width="890" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="310" height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Pastas</td>
        <td width="580" height="25" align="left" class="texto_padrao_destaque" style="padding-left:9px;">M�sicas da Pasta</td>
      </tr>
      <tr>
        <td align="left" valign="top" style="padding-left:5px;">
        <div style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:285px; height:200px; text-align:left; float:left; padding:5px; overflow: auto;">
        <span id="status_lista_pastas" class="texto_padrao_pequeno"></span>
		<ul id="lista-pastas">
		</ul>
		</div>
        </td>
        <td align="left" valign="top">
        <div id="musicas_ftp" style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:560px; height:200px; text-align:left; float:right; padding:5px; overflow: auto;">
        <span id="msg_pasta" class="texto_padrao_pequeno">Clique na pasta ao lado para carregar as m�sicas.</span>
        <ul id="lista-musicas-pasta">
        </ul>
        </div>        </td>
      </tr>
      <tr>
        <td height="30" align="right" style="padding-left:5px;padding-right:7px;">&nbsp;<img src="/admin/img/icones/img-icone-atualizar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="javascript:carregar_pastas('<?php echo $porta_code; ?>');" class="texto_padrao">Recarregar Pastas</a></td>
        <td height="30" align="right" style="padding-left:9px;">
        <img src="/admin/img/icones/img-icone-pasta-adicionar.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:adicionar_tudo();" class="texto_padrao">Adicionar Tudo na Playlist</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-lixo.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:limpar_lista_musicas('ftp');" class="texto_padrao">Limpar Lista</a></td>
      </tr>
      <tr>
        <td width="310" height="25" align="left" class="texto_padrao_destaque" style="padding-left:5px;">Playlists</td>
        <td width="580" height="25" align="left" class="texto_padrao_destaque" style="padding-left:9px;">M�sicas da Playlist <span id="quantidade_musicas_playlist"></span></td>
      </tr>
      <tr>
        <td align="left" valign="top" style="padding-left:5px;">
        <div style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:285px; height:250px; text-align:left; float:left; padding:5px; overflow: auto;">
        <span id="status_lista_playlists" class="texto_padrao_pequeno"></span>
		<ul id="lista-playlists">
        </ul>
        </div>        </td>
        <td align="left" valign="top">
        <div id="musicas_playlist" style="background-color:#FFFFFF; border: #CCCCCC 1px solid; width:560px; height:250px; text-align:left; float:right; padding:5px; overflow: auto;">
        <span id="msg_playlist" class="texto_padrao_pequeno">Clique na playlist ao lado para carregar as m�sicas ou adicione as m�sicas de uma pasta acima.</span>
        <ul id="lista-musicas-playlist">
        </ul>
        </div>        </td>
      </tr>
      <tr>
        <td height="30" align="right" style="padding-left:5px;padding-right:7px;"><img src="/admin/img/icones/img-icone-cadastrar.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:criar_playlist('<?php echo $porta_code; ?>');" class="texto_padrao">Criar Playlist</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-atualizar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="javascript:carregar_playlists('<?php echo $porta_code; ?>');" class="texto_padrao">Recarregar Playlists</a></td>
        <td height="30" align="right" style="padding-left:9px;"><img src="/admin/img/icones/img-icone-salvar.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:salvar_playlist();" class="texto_padrao">Salvar Playlist</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-lixo.png" width="16" height="16" align="absmiddle" />&nbsp;<a href="javascript:limpar_lista_musicas('playlist');" class="texto_padrao">Limpar Lista</a>&nbsp;&nbsp;<img src="/admin/img/icones/img-icone-voltar.png" width="16" height="16" align="absmiddle" border="0" />&nbsp;<a href="/informacoes" class="texto_padrao">Voltar</a><input name="playlist" type="hidden" id="playlist" value="" />
        </td>
      </tr>
    </table>
  </form>
<table width="690" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:20px; margin-bottom:10px; background-color:#FFFF66; border:#DFDF00 1px solid">
  <tr>
    <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
    <td width="660" align="left" class="texto_pequeno_erro" scope="col">Para um melhor desempenho, recomendamos adicionar no m�ximo 1000 m�sicas em cada playlist.</td>
  </tr>
</table>
<table width="690" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:20px; background-color:#FFFF66; border:#DFDF00 1px solid">
  <tr>
    <td width="30" height="25" align="center" scope="col"><img src="/admin/img/icones/atencao.png" width="16" height="16" /></td>
    <td width="660" align="left" class="texto_pequeno_erro" scope="col">N&atilde;o use acentos em nomes de m&uacute;sicas, pastas e playlists para que n&atilde;o ocorra erros inexperados.</td>
  </tr>
</table>
</div>
<!-- In�cio div log do sistema -->
<div id="log-sistema-fundo"></div>
<div id="log-sistema">
<div id="log-sistema-botao"><img src="/admin/img/icones/img-icone-fechar.png" onclick="document.getElementById('log-sistema-fundo').style.display = 'none';document.getElementById('log-sistema').style.display = 'none';" style="cursor:pointer" title="Fechar" /></div>
<div id="log-sistema-conteudo"></div>
</div>
<!-- Fim div log do sistema -->
</body>
</html>