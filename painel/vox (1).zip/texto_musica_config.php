<span style="color:#006400;font-family:Arial;font-size:12px;"><strong>
<?php
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".query_string('1')."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$status_streaming = status_streaming($dados_servidor["ip"],$dados_stm["porta"]);
if($status_streaming == "ligado"){
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, "http://".$dados_servidor["ip"].":".$dados_stm["porta"]."/admin.cgi?sid=1&pass=dj".$dados_stm["senha"]."&mode=viewxml");
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)');
 curl_setopt($ch, CURLOPT_TIMEOUT, 5);
 $resultado = curl_exec($ch);
 curl_close($ch);
 $xml = @simplexml_load_string(utf8_encode($resultado));
 $musica_atual = $xml->SONGTITLE;
 $texto = "$musica_atual";
 echo substr($texto,0, 70);
 exit;
}else{
 echo "Sem m&uacute;sica";
 exit;
}
?></strong>