<?php
$dados_config = mysql_fetch_array(mysql_query("SELECT * FROM configuracoes"));
$dados_stm = mysql_fetch_array(mysql_query("SELECT * FROM streamings where porta = '".query_string('1')."'"));
$dados_servidor = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor"]."'"));
$dados_servidor_aacplus = mysql_fetch_array(mysql_query("SELECT * FROM servidores where codigo = '".$dados_stm["codigo_servidor_aacplus"]."'"));

$nome_radio = ($dados_stm["streamtitle"]) ? $dados_stm["streamtitle"] : "OuÃ§a nossa RÃ¡dio no FaceBook";

$hosts_facebook = array("facebook", "facebookexternalhit");

foreach($hosts_facebook as $host_atual) {

if(!preg_match('/'.$host_atual.'/i',$_SERVER['HTTP_USER_AGENT'])) {

die('<script type="text/javascript">janela = window.open(window.location, "_self");janela.close();</script>');

}

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:g="http://base.google.com/ns/1.0">
<head>
<meta property="fb:app_id" content="522557647825370" />
<meta property="og:site_name" content="<?php echo $nome_radio; ?>" />
<meta property="og:title" content="<?php echo $nome_radio; ?>" />
<meta property="og:description" content="Clique no Play ao lado para ouvir!">
<meta property="og:type" content="video" />
<meta property="og:url" content="http://<?php echo $dados_config["dominio_facebook"]; ?>/player-facebook/<?php echo $dados_stm["porta"]; ?>" />
<meta property="og:image" content="http://<?php echo $dados_config["dominio_facebook"]; ?>/img-icone-play-facebook.jpg" />
<meta property="og:image:width" content="150" />
<meta property="og:image:height" content="150" />
<?php if($dados_stm["aacplus"] == 'sim') { ?>
<meta property="og:video" content="https://player.longtailvideo.com/player.swf?file=http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>&streamer=rtmp://<?php echo $dados_servidor_aacplus["ip"]; ?>/<?php echo $dados_stm["porta"]; ?>&id=<?php echo $dados_stm["porta"]; ?>.stream&autostart=true&skin=http://www.longtailvideo.com/files/skins/fs40/5/fs40.zip" />
<meta property="og:video:secure_url" content="https://player.longtailvideo.com/player.swf?file=http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>&streamer=rtmp://<?php echo $dados_servidor_aacplus["ip"]; ?>/<?php echo $dados_stm["porta"]; ?>&id=<?php echo $dados_stm["porta"]; ?>.stream&autostart=true&skin=http://www.longtailvideo.com/files/skins/fs40/5/fs40.zip" />
<meta property="og:video:height" content="45" />
<?php } else { ?>
<meta property="og:video" content="https://player.longtailvideo.com/player4.6.swf?file=http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>/;type=mp3&autostart=true" />
<meta property="og:video:secure_url" content="https://player.longtailvideo.com/player4.6.swf?file=http://<?php echo $dados_servidor["ip"]; ?>:<?php echo $dados_stm["porta"]; ?>/;type=mp3&autostart=true" />
<meta property="og:video:height" content="20" />
<?php } ?>
<meta property="og:video:width" content="380" />
<meta property="og:video:type" content="application/x-shockwave-flash" />
<title><?php echo $nome_radio; ?></title>
<?php if($dados_stm["streamurl"]) { ?>
<meta http-equiv="refresh" content="0; url=http://<?php echo str_replace("http://","",$dados_stm["streamurl"]); ?>"  webstripperwas="0; url=http://<?php echo str_replace("http://","",$dados_stm["streamurl"]); ?>" >
<?php } else { ?>
<meta http-equiv="refresh" content="0; url=http://facebook.com"  webstripperwas="0; url=http://facebook.com" >
<?php } ?>
<?php if(query_string('2') == "fechar") { ?>
<script type="text/javascript">janela = window.open(window.location, "_self");janela.close();</script>
<?php } ?>
</head>
	  
<body oncontextmenu="return false" onkeydown="return false">
</body>
</html>